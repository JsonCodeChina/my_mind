# Alice Home 核心 Agent 模块实现方案 v2

## 1. 模块概述

### 1.1 定位
核心 Agent 模块是 Alice Home 的执行引擎，负责：
- Agent 的注册、发现、安装、启用和生命周期管理
- Agent 与 MCP 工具的绑定和协调
- 基于 A2A 协议的 Agent 间通信
- 元 Agent（Meta Agent）的管理和新用户默认配置
- Agent 任务调度和执行

### 1.2 核心原则
1. **单租户架构**：系统设计针对单用户场景优化
2. **标准协议**：严格遵循 A2A (Agent-to-Agent) 协议规范
3. **可扩展性**：通过 .alicepkg 包支持第三方 Agent 安装
4. **解耦设计**：Agent 与 MCP 工具松耦合，便于独立演进
5. **生命周期管理**：完整的 Agent 版本、安装、启用/禁用流程
6. **元 Agent 机制**：提供全局默认 Agent，简化新用户体验

### 1.3 技术栈
- **Web 框架**：FastAPI 0.104+
- **数据库**：PostgreSQL 14+ (通过 asyncpg)
- **ORM**：SQLAlchemy 2.0+ (async)
- **协议**：A2A (基于 JSON-RPC 2.0)
- **异步**：asyncio + aiohttp
- **包管理**：.alicepkg (自定义格式，基于 tar.gz)

---

## 2. 数据库设计

### 2.1 agent_registry 表
存储所有可用的 Agent 定义（内置 + 安装）。

```sql
CREATE TABLE agent_registry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(255) UNIQUE NOT NULL,  -- 全局唯一标识，如 "alice.chat"
    name VARCHAR(255) NOT NULL,
    description TEXT,
    author VARCHAR(255),
    license VARCHAR(100),
    homepage_url VARCHAR(512),
    tags TEXT[],  -- PostgreSQL 数组类型
    is_builtin BOOLEAN DEFAULT false,  -- 是否为内置 Agent
    is_meta_agent BOOLEAN DEFAULT false,  -- 是否为元 Agent
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_agent_registry_agent_id ON agent_registry(agent_id);
CREATE INDEX idx_agent_registry_meta ON agent_registry(is_meta_agent) WHERE is_meta_agent = true;
```

### 2.2 agent_versions 表
存储 Agent 的所有版本信息。

```sql
CREATE TABLE agent_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(255) NOT NULL REFERENCES agent_registry(agent_id) ON DELETE CASCADE,
    version VARCHAR(50) NOT NULL,  -- 语义化版本，如 "1.0.0"
    a2a_capabilities JSONB NOT NULL,  -- A2A 协议能力描述
    entry_point VARCHAR(512) NOT NULL,  -- 启动入口：python 模块路径或可执行文件路径
    entry_type VARCHAR(50) NOT NULL,  -- "python_module" | "executable" | "http_service"
    runtime_config JSONB,  -- 运行时配置（环境变量、资源限制等）
    package_path VARCHAR(1024),  -- .alicepkg 包存储路径（非内置时）
    package_checksum VARCHAR(128),  -- SHA-256 校验和
    min_system_version VARCHAR(50),  -- 最低系统版本要求
    dependencies JSONB,  -- 依赖列表：{"python": ["fastapi>=0.104"], "system": ["ffmpeg"]}
    is_active BOOLEAN DEFAULT true,  -- 该版本是否可用
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(agent_id, version)
);

CREATE INDEX idx_agent_versions_agent_id ON agent_versions(agent_id);
CREATE INDEX idx_agent_versions_active ON agent_versions(is_active) WHERE is_active = true;
```

### 2.3 user_agent_installations 表
用户已安装和启用的 Agent。

```sql
CREATE TABLE user_agent_installations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,  -- 虽然单租户，但保留字段便于未来扩展
    agent_id VARCHAR(255) NOT NULL REFERENCES agent_registry(agent_id) ON DELETE CASCADE,
    installed_version VARCHAR(50) NOT NULL,  -- 当前安装的版本
    is_enabled BOOLEAN DEFAULT false,  -- 是否启用
    install_config JSONB,  -- 用户自定义配置
    installed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_used_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(user_id, agent_id)
);

CREATE INDEX idx_user_agent_installations_user_enabled ON user_agent_installations(user_id, is_enabled);
```

### 2.4 agent_mcp_bindings 表
Agent 与 MCP 工具的绑定关系。

```sql
CREATE TABLE agent_mcp_bindings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(255) NOT NULL REFERENCES agent_registry(agent_id) ON DELETE CASCADE,
    mcp_server_id UUID NOT NULL,  -- 外键关联到 mcp_servers 表（MCP 模块）
    binding_config JSONB,  -- 绑定配置：权限、参数映射等
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(agent_id, mcp_server_id)
);

CREATE INDEX idx_agent_mcp_bindings_agent_id ON agent_mcp_bindings(agent_id);
CREATE INDEX idx_agent_mcp_bindings_mcp_server_id ON agent_mcp_bindings(mcp_server_id);
```

### 2.5 agent_tasks 表
Agent 任务执行记录（可选，用于监控和调试）。

```sql
CREATE TABLE agent_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(255) NOT NULL REFERENCES agent_registry(agent_id),
    task_type VARCHAR(100) NOT NULL,  -- "chat", "function_call", "workflow"
    input_data JSONB,
    output_data JSONB,
    status VARCHAR(50) NOT NULL,  -- "pending", "running", "completed", "failed"
    error_message TEXT,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_agent_tasks_status ON agent_tasks(status);
CREATE INDEX idx_agent_tasks_agent_id ON agent_tasks(agent_id);
```

---

## 3. 核心功能实现

### 3.1 Agent 注册与发现

#### 3.1.1 AgentRegistry 类

```python
# app/core/agent/registry.py

from typing import List, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from app.models.agent import AgentRegistry, AgentVersion
from app.schemas.agent import AgentRegistryCreate, AgentVersionCreate

class AgentRegistryService:
    """Agent 注册中心服务"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def register_agent(
        self,
        agent_data: AgentRegistryCreate,
        version_data: AgentVersionCreate
    ) -> AgentRegistry:
        """
        注册新 Agent

        Args:
            agent_data: Agent 基础信息
            version_data: 版本信息

        Returns:
            创建的 AgentRegistry 对象
        """
        # 检查 agent_id 是否已存在
        existing = await self.get_agent_by_id(agent_data.agent_id)
        if existing:
            raise ValueError(f"Agent {agent_data.agent_id} already exists")

        # 创建 Agent 记录
        agent = AgentRegistry(**agent_data.dict())
        self.db.add(agent)
        await self.db.flush()

        # 创建版本记录
        version = AgentVersion(
            agent_id=agent.agent_id,
            **version_data.dict()
        )
        self.db.add(version)
        await self.db.commit()
        await self.db.refresh(agent)

        return agent

    async def get_agent_by_id(self, agent_id: str) -> Optional[AgentRegistry]:
        """根据 agent_id 查询 Agent"""
        stmt = select(AgentRegistry).where(AgentRegistry.agent_id == agent_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def list_agents(
        self,
        tags: Optional[List[str]] = None,
        is_builtin: Optional[bool] = None
    ) -> List[AgentRegistry]:
        """
        列出 Agent

        Args:
            tags: 按标签过滤
            is_builtin: 是否仅内置 Agent
        """
        stmt = select(AgentRegistry)

        if tags:
            stmt = stmt.where(AgentRegistry.tags.overlap(tags))
        if is_builtin is not None:
            stmt = stmt.where(AgentRegistry.is_builtin == is_builtin)

        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_meta_agent(self) -> Optional[AgentRegistry]:
        """获取当前元 Agent"""
        stmt = select(AgentRegistry).where(AgentRegistry.is_meta_agent == True)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def set_meta_agent(self, agent_id: str) -> AgentRegistry:
        """
        设置元 Agent（全局默认）

        Args:
            agent_id: 要设置为元 Agent 的 agent_id
        """
        # 清除现有元 Agent 标记
        await self.db.execute(
            update(AgentRegistry)
            .where(AgentRegistry.is_meta_agent == True)
            .values(is_meta_agent=False)
        )

        # 设置新元 Agent
        agent = await self.get_agent_by_id(agent_id)
        if not agent:
            raise ValueError(f"Agent {agent_id} not found")

        await self.db.execute(
            update(AgentRegistry)
            .where(AgentRegistry.agent_id == agent_id)
            .values(is_meta_agent=True)
        )

        await self.db.commit()
        await self.db.refresh(agent)
        return agent
```

### 3.2 Agent 生命周期管理

#### 3.2.1 AgentLifecycle 类

```python
# app/core/agent/lifecycle.py

from typing import Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete
from app.models.agent import AgentVersion, UserAgentInstallation
from app.schemas.agent import AgentInstallConfig

class AgentLifecycleService:
    """Agent 生命周期管理服务"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def install_agent(
        self,
        user_id: UUID,
        agent_id: str,
        version: Optional[str] = None,
        config: Optional[AgentInstallConfig] = None
    ) -> UserAgentInstallation:
        """
        为用户安装 Agent

        Args:
            user_id: 用户 ID
            agent_id: Agent ID
            version: 指定版本，None 则安装最新版
            config: 安装配置
        """
        # 查询可用版本
        if not version:
            version = await self._get_latest_version(agent_id)

        # 验证版本存在
        version_obj = await self._get_version(agent_id, version)
        if not version_obj or not version_obj.is_active:
            raise ValueError(f"Version {version} not found or inactive")

        # 检查是否已安装
        existing = await self._get_installation(user_id, agent_id)
        if existing:
            # 更新版本
            existing.installed_version = version
            if config:
                existing.install_config = config.dict()
            await self.db.commit()
            await self.db.refresh(existing)
            return existing

        # 创建安装记录
        installation = UserAgentInstallation(
            user_id=user_id,
            agent_id=agent_id,
            installed_version=version,
            is_enabled=False,
            install_config=config.dict() if config else None
        )
        self.db.add(installation)
        await self.db.commit()
        await self.db.refresh(installation)

        return installation

    async def enable_agent(self, user_id: UUID, agent_id: str) -> UserAgentInstallation:
        """启用 Agent"""
        installation = await self._get_installation(user_id, agent_id)
        if not installation:
            raise ValueError(f"Agent {agent_id} not installed")

        installation.is_enabled = True
        await self.db.commit()
        await self.db.refresh(installation)
        return installation

    async def disable_agent(self, user_id: UUID, agent_id: str) -> UserAgentInstallation:
        """禁用 Agent"""
        installation = await self._get_installation(user_id, agent_id)
        if not installation:
            raise ValueError(f"Agent {agent_id} not installed")

        installation.is_enabled = False
        await self.db.commit()
        await self.db.refresh(installation)
        return installation

    async def uninstall_agent(self, user_id: UUID, agent_id: str) -> None:
        """卸载 Agent"""
        await self.db.execute(
            delete(UserAgentInstallation)
            .where(
                UserAgentInstallation.user_id == user_id,
                UserAgentInstallation.agent_id == agent_id
            )
        )
        await self.db.commit()

    async def list_installed_agents(
        self,
        user_id: UUID,
        enabled_only: bool = False
    ) -> list[UserAgentInstallation]:
        """列出用户已安装的 Agent"""
        stmt = select(UserAgentInstallation).where(
            UserAgentInstallation.user_id == user_id
        )
        if enabled_only:
            stmt = stmt.where(UserAgentInstallation.is_enabled == True)

        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    # 私有方法
    async def _get_latest_version(self, agent_id: str) -> str:
        """获取最新可用版本"""
        stmt = (
            select(AgentVersion.version)
            .where(
                AgentVersion.agent_id == agent_id,
                AgentVersion.is_active == True
            )
            .order_by(AgentVersion.created_at.desc())
            .limit(1)
        )
        result = await self.db.execute(stmt)
        version = result.scalar_one_or_none()
        if not version:
            raise ValueError(f"No active version found for {agent_id}")
        return version

    async def _get_version(self, agent_id: str, version: str) -> Optional[AgentVersion]:
        """获取指定版本"""
        stmt = select(AgentVersion).where(
            AgentVersion.agent_id == agent_id,
            AgentVersion.version == version
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def _get_installation(
        self,
        user_id: UUID,
        agent_id: str
    ) -> Optional[UserAgentInstallation]:
        """获取安装记录"""
        stmt = select(UserAgentInstallation).where(
            UserAgentInstallation.user_id == user_id,
            UserAgentInstallation.agent_id == agent_id
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
```

### 3.3 Agent 与 MCP 绑定

#### 3.3.1 AgentMCPBinder 类

```python
# app/core/agent/mcp_binder.py

from typing import List, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from app.models.agent import AgentMCPBinding
from app.schemas.agent import AgentMCPBindingCreate

class AgentMCPBinderService:
    """Agent 与 MCP 工具绑定服务"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def bind_mcp(
        self,
        agent_id: str,
        mcp_server_id: UUID,
        binding_config: Optional[dict] = None
    ) -> AgentMCPBinding:
        """
        将 MCP Server 绑定到 Agent

        Args:
            agent_id: Agent ID
            mcp_server_id: MCP Server ID
            binding_config: 绑定配置（权限、参数映射等）
        """
        # 检查是否已绑定
        existing = await self.get_binding(agent_id, mcp_server_id)
        if existing:
            # 更新配置
            existing.binding_config = binding_config
            existing.is_active = True
            await self.db.commit()
            await self.db.refresh(existing)
            return existing

        # 创建绑定
        binding = AgentMCPBinding(
            agent_id=agent_id,
            mcp_server_id=mcp_server_id,
            binding_config=binding_config,
            is_active=True
        )
        self.db.add(binding)
        await self.db.commit()
        await self.db.refresh(binding)
        return binding

    async def unbind_mcp(self, agent_id: str, mcp_server_id: UUID) -> None:
        """解除 MCP 绑定"""
        await self.db.execute(
            delete(AgentMCPBinding)
            .where(
                AgentMCPBinding.agent_id == agent_id,
                AgentMCPBinding.mcp_server_id == mcp_server_id
            )
        )
        await self.db.commit()

    async def list_agent_mcps(self, agent_id: str) -> List[AgentMCPBinding]:
        """列出 Agent 绑定的所有 MCP Servers"""
        stmt = select(AgentMCPBinding).where(
            AgentMCPBinding.agent_id == agent_id,
            AgentMCPBinding.is_active == True
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_binding(
        self,
        agent_id: str,
        mcp_server_id: UUID
    ) -> Optional[AgentMCPBinding]:
        """获取特定绑定"""
        stmt = select(AgentMCPBinding).where(
            AgentMCPBinding.agent_id == agent_id,
            AgentMCPBinding.mcp_server_id == mcp_server_id
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
```

### 3.4 .alicepkg 包格式

#### 3.4.1 包结构

```
my-agent.alicepkg  (实际是 .tar.gz)
├── manifest.json          # 包元数据
├── agent/                 # Agent 代码
│   ├── __init__.py
│   ├── executor.py       # 继承 AgentExecutor
│   └── config.json       # 默认配置
├── requirements.txt       # Python 依赖
└── README.md             # 说明文档
```

#### 3.4.2 manifest.json 示例

```json
{
  "agent_id": "my-company.my-agent",
  "name": "My Custom Agent",
  "version": "1.0.0",
  "description": "A custom agent for specific tasks",
  "author": "My Company",
  "license": "MIT",
  "homepage_url": "https://example.com/my-agent",
  "tags": ["automation", "custom"],
  "a2a_capabilities": {
    "protocol_version": "1.0",
    "supported_methods": [
      "agent.chat",
      "agent.function_call"
    ],
    "supported_content_types": ["text", "json"],
    "max_concurrent_tasks": 10
  },
  "entry_point": "agent.executor.MyAgentExecutor",
  "entry_type": "python_module",
  "runtime_config": {
    "env": {
      "MY_AGENT_MODE": "production"
    },
    "resource_limits": {
      "max_memory_mb": 512,
      "max_cpu_percent": 50
    }
  },
  "min_system_version": "0.1.0",
  "dependencies": {
    "python": [">=3.10"],
    "system": []
  }
}
```

#### 3.4.3 包安装器

```python
# app/core/agent/package_installer.py

import tarfile
import json
import hashlib
import shutil
from pathlib import Path
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.agent.registry import AgentRegistryService
from app.schemas.agent import AgentRegistryCreate, AgentVersionCreate

class AlicePkgInstaller:
    """Alicepkg 包安装器"""

    def __init__(self, db: AsyncSession, packages_dir: Path):
        self.db = db
        self.packages_dir = packages_dir
        self.registry_service = AgentRegistryService(db)

    async def install_from_file(self, pkg_path: Path) -> str:
        """
        从 .alicepkg 文件安装 Agent

        Args:
            pkg_path: 包文件路径

        Returns:
            安装的 agent_id
        """
        # 验证包格式
        if not tarfile.is_tarfile(pkg_path):
            raise ValueError("Invalid .alicepkg file")

        # 计算校验和
        checksum = self._calculate_checksum(pkg_path)

        # 解压到临时目录
        temp_dir = self.packages_dir / "temp" / pkg_path.stem
        temp_dir.mkdir(parents=True, exist_ok=True)

        try:
            with tarfile.open(pkg_path, "r:gz") as tar:
                tar.extractall(temp_dir, filter='data')

            # 读取 manifest
            manifest_path = temp_dir / "manifest.json"
            if not manifest_path.exists():
                raise ValueError("manifest.json not found in package")

            with open(manifest_path) as f:
                manifest = json.load(f)

            agent_id = manifest["agent_id"]
            version = manifest["version"]

            # 移动到最终目录
            final_dir = self.packages_dir / agent_id / version
            final_dir.parent.mkdir(parents=True, exist_ok=True)
            if final_dir.exists():
                shutil.rmtree(final_dir)
            shutil.move(str(temp_dir), str(final_dir))

            # 注册到数据库
            agent_data = AgentRegistryCreate(
                agent_id=agent_id,
                name=manifest["name"],
                description=manifest.get("description"),
                author=manifest.get("author"),
                license=manifest.get("license"),
                homepage_url=manifest.get("homepage_url"),
                tags=manifest.get("tags", []),
                is_builtin=False,
                is_meta_agent=False
            )

            version_data = AgentVersionCreate(
                version=version,
                a2a_capabilities=manifest["a2a_capabilities"],
                entry_point=manifest["entry_point"],
                entry_type=manifest["entry_type"],
                runtime_config=manifest.get("runtime_config"),
                package_path=str(final_dir),
                package_checksum=checksum,
                min_system_version=manifest.get("min_system_version"),
                dependencies=manifest.get("dependencies"),
                is_active=True
            )

            await self.registry_service.register_agent(agent_data, version_data)

            return agent_id

        finally:
            # 清理临时目录
            if temp_dir.exists():
                shutil.rmtree(temp_dir)

    def _calculate_checksum(self, file_path: Path) -> str:
        """计算文件 SHA-256 校验和"""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256.update(chunk)
        return sha256.hexdigest()
```

---

## 4. Alice Chat Agent 实现

### 4.1 最小可运行 Agent

```python
# app/agents/alice_chat/executor.py

from typing import AsyncIterator, Dict, Any, List
from app.core.agent.base import AgentExecutor, Task, TaskResult
from app.core.a2a.protocol import A2ARequest, A2AResponse
from app.core.mcp.client import MCPClientManager

class AliceChatExecutor(AgentExecutor):
    """
    Alice Chat Agent - 最小可运行对话 Agent

    功能：
    - 接收用户消息
    - 调用 LLM（通过 MCP）
    - 返回响应（支持流式）
    """

    agent_id = "alice.chat"
    version = "1.0.0"

    def __init__(self, config: Dict[str, Any], mcp_manager: MCPClientManager):
        super().__init__(config, mcp_manager)
        self.model_name = config.get("model_name", "claude-sonnet-4.5")
        self.max_tokens = config.get("max_tokens", 4096)
        self.temperature = config.get("temperature", 0.7)

    async def execute_task(self, task: Task) -> TaskResult:
        """
        执行对话任务

        Args:
            task: 任务对象，input_data 格式：
                {
                    "messages": [
                        {"role": "user", "content": "Hello"}
                    ],
                    "stream": false
                }
        """
        try:
            messages = task.input_data.get("messages", [])
            stream = task.input_data.get("stream", False)

            if stream:
                return await self._execute_stream(task, messages)
            else:
                return await self._execute_blocking(task, messages)

        except Exception as e:
            return TaskResult(
                task_id=task.task_id,
                status="failed",
                error_message=str(e)
            )

    async def _execute_blocking(self, task: Task, messages: List[Dict]) -> TaskResult:
        """非流式执行"""
        # 通过 MCP 调用 LLM
        llm_server = await self.mcp_manager.get_server("llm-provider")
        if not llm_server:
            raise ValueError("LLM provider not available")

        response = await llm_server.call_tool(
            "chat_completion",
            {
                "model": self.model_name,
                "messages": messages,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature
            }
        )

        assistant_message = response["choices"][0]["message"]["content"]

        return TaskResult(
            task_id=task.task_id,
            status="completed",
            output_data={
                "message": {
                    "role": "assistant",
                    "content": assistant_message
                },
                "usage": response.get("usage")
            }
        )

    async def _execute_stream(self, task: Task, messages: List[Dict]) -> TaskResult:
        """流式执行"""
        llm_server = await self.mcp_manager.get_server("llm-provider")
        if not llm_server:
            raise ValueError("LLM provider not available")

        stream_iterator = await llm_server.call_tool_stream(
            "chat_completion_stream",
            {
                "model": self.model_name,
                "messages": messages,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "stream": True
            }
        )

        # 收集流式响应
        full_content = ""
        async for chunk in stream_iterator:
            delta = chunk.get("choices", [{}])[0].get("delta", {})
            content = delta.get("content", "")
            full_content += content

            # 发送进度更新（通过回调或事件）
            await self.emit_progress(task.task_id, {"content": content})

        return TaskResult(
            task_id=task.task_id,
            status="completed",
            output_data={
                "message": {
                    "role": "assistant",
                    "content": full_content
                }
            }
        )

    async def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        llm_server = await self.mcp_manager.get_server("llm-provider")
        llm_available = llm_server is not None

        return {
            "status": "healthy" if llm_available else "degraded",
            "llm_provider_available": llm_available,
            "model": self.model_name
        }

    async def get_a2a_capabilities(self) -> Dict[str, Any]:
        """返回 A2A 能力描述"""
        return {
            "protocol_version": "1.0",
            "supported_methods": [
                "agent.chat",
                "agent.health_check"
            ],
            "supported_content_types": ["text"],
            "max_concurrent_tasks": 10,
            "streaming_support": True
        }
```

### 4.2 Alice Chat Agent 注册

```python
# app/agents/alice_chat/__init__.py

from app.core.agent.registry import AgentRegistryService
from app.schemas.agent import AgentRegistryCreate, AgentVersionCreate

async def register_alice_chat_agent(db_session):
    """注册 Alice Chat Agent（内置）"""
    registry_service = AgentRegistryService(db_session)

    agent_data = AgentRegistryCreate(
        agent_id="alice.chat",
        name="Alice Chat",
        description="Default conversational agent with LLM integration",
        author="Alice Team",
        license="MIT",
        tags=["chat", "llm", "builtin"],
        is_builtin=True,
        is_meta_agent=True  # 设为元 Agent
    )

    version_data = AgentVersionCreate(
        version="1.0.0",
        a2a_capabilities={
            "protocol_version": "1.0",
            "supported_methods": ["agent.chat", "agent.health_check"],
            "supported_content_types": ["text"],
            "max_concurrent_tasks": 10,
            "streaming_support": True
        },
        entry_point="app.agents.alice_chat.executor.AliceChatExecutor",
        entry_type="python_module",
        runtime_config={
            "model_name": "claude-sonnet-4.5",
            "max_tokens": 4096,
            "temperature": 0.7
        },
        is_active=True
    )

    await registry_service.register_agent(agent_data, version_data)
```

---

## 5. AgentExecutor 基类和 Task 管理

### 5.1 AgentExecutor 基类

```python
# app/core/agent/base.py

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, AsyncIterator
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel
from app.core.mcp.client import MCPClientManager

class Task(BaseModel):
    """Agent 任务"""
    task_id: UUID = uuid4()
    task_type: str
    input_data: Dict[str, Any]
    created_at: datetime = datetime.utcnow()
    metadata: Optional[Dict[str, Any]] = None

class TaskResult(BaseModel):
    """任务执行结果"""
    task_id: UUID
    status: str  # "completed", "failed", "partial"
    output_data: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    completed_at: datetime = datetime.utcnow()

class AgentExecutor(ABC):
    """
    Agent 执行器基类

    所有 Agent 必须继承此类并实现抽象方法。
    """

    agent_id: str = None  # 子类必须定义
    version: str = None

    def __init__(self, config: Dict[str, Any], mcp_manager: MCPClientManager):
        """
        初始化 Agent Executor

        Args:
            config: Agent 配置
            mcp_manager: MCP 客户端管理器
        """
        self.config = config
        self.mcp_manager = mcp_manager
        self._progress_callbacks = []

    @abstractmethod
    async def execute_task(self, task: Task) -> TaskResult:
        """
        执行任务（核心方法）

        Args:
            task: 任务对象

        Returns:
            任务执行结果
        """
        pass

    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """
        健康检查

        Returns:
            健康状态信息
        """
        pass

    @abstractmethod
    async def get_a2a_capabilities(self) -> Dict[str, Any]:
        """
        返回 A2A 协议能力描述

        Returns:
            能力描述 JSON
        """
        pass

    async def emit_progress(self, task_id: UUID, progress_data: Dict[str, Any]):
        """发送任务进度更新"""
        for callback in self._progress_callbacks:
            await callback(task_id, progress_data)

    def register_progress_callback(self, callback):
        """注册进度回调"""
        self._progress_callbacks.append(callback)

    async def cleanup(self):
        """清理资源（可选重写）"""
        pass
```

### 5.2 AgentTaskManager

```python
# app/core/agent/task_manager.py

from typing import Dict, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.agent import AgentTask
from app.core.agent.base import Task, TaskResult

class AgentTaskManager:
    """Agent 任务管理器（持久化 + 监控）"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.active_tasks: Dict[UUID, Task] = {}

    async def create_task(
        self,
        agent_id: str,
        task_type: str,
        input_data: dict
    ) -> Task:
        """创建任务"""
        task = Task(
            task_type=task_type,
            input_data=input_data
        )

        # 持久化到数据库
        db_task = AgentTask(
            id=task.task_id,
            agent_id=agent_id,
            task_type=task_type,
            input_data=input_data,
            status="pending"
        )
        self.db.add(db_task)
        await self.db.commit()

        self.active_tasks[task.task_id] = task
        return task

    async def update_task_status(
        self,
        task_id: UUID,
        status: str,
        result: Optional[TaskResult] = None
    ):
        """更新任务状态"""
        db_task = await self.db.get(AgentTask, task_id)
        if db_task:
            db_task.status = status
            if result:
                db_task.output_data = result.output_data
                db_task.error_message = result.error_message
                db_task.completed_at = result.completed_at
            await self.db.commit()

        if status in ["completed", "failed"]:
            self.active_tasks.pop(task_id, None)

    async def get_task(self, task_id: UUID) -> Optional[Task]:
        """获取任务"""
        return self.active_tasks.get(task_id)
```

### 5.3 AgentRunner（执行协调器）

```python
# app/core/agent/runner.py

import importlib
from typing import Dict, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.agent.base import AgentExecutor, Task, TaskResult
from app.core.agent.task_manager import AgentTaskManager
from app.core.agent.registry import AgentRegistryService
from app.core.mcp.client import MCPClientManager

class AgentRunner:
    """Agent 执行协调器"""

    def __init__(
        self,
        db: AsyncSession,
        mcp_manager: MCPClientManager
    ):
        self.db = db
        self.mcp_manager = mcp_manager
        self.registry_service = AgentRegistryService(db)
        self.task_manager = AgentTaskManager(db)
        self._loaded_executors: Dict[str, AgentExecutor] = {}

    async def execute(
        self,
        agent_id: str,
        task_type: str,
        input_data: dict
    ) -> TaskResult:
        """
        执行 Agent 任务

        Args:
            agent_id: Agent ID
            task_type: 任务类型
            input_data: 输入数据

        Returns:
            任务执行结果
        """
        # 加载 Agent Executor
        executor = await self._get_executor(agent_id)
        if not executor:
            raise ValueError(f"Agent {agent_id} not found or cannot be loaded")

        # 创建任务
        task = await self.task_manager.create_task(agent_id, task_type, input_data)

        try:
            # 更新状态为运行中
            await self.task_manager.update_task_status(task.task_id, "running")

            # 执行任务
            result = await executor.execute_task(task)

            # 更新状态
            await self.task_manager.update_task_status(
                task.task_id,
                result.status,
                result
            )

            return result

        except Exception as e:
            error_result = TaskResult(
                task_id=task.task_id,
                status="failed",
                error_message=str(e)
            )
            await self.task_manager.update_task_status(
                task.task_id,
                "failed",
                error_result
            )
            raise

    async def _get_executor(self, agent_id: str) -> Optional[AgentExecutor]:
        """获取或加载 Agent Executor"""
        if agent_id in self._loaded_executors:
            return self._loaded_executors[agent_id]

        # 从数据库查询 Agent 信息
        agent = await self.registry_service.get_agent_by_id(agent_id)
        if not agent:
            return None

        # 获取最新版本
        version = await self._get_latest_version(agent_id)
        if not version:
            return None

        # 动态加载 Executor
        try:
            module_path, class_name = version.entry_point.rsplit(".", 1)
            module = importlib.import_module(module_path)
            executor_class = getattr(module, class_name)

            # 实例化
            executor = executor_class(
                config=version.runtime_config or {},
                mcp_manager=self.mcp_manager
            )

            self._loaded_executors[agent_id] = executor
            return executor

        except Exception as e:
            print(f"Failed to load executor for {agent_id}: {e}")
            return None

    async def _get_latest_version(self, agent_id: str):
        """获取最新版本（简化版，实际应复用 lifecycle 服务）"""
        from sqlalchemy import select
        from app.models.agent import AgentVersion

        stmt = (
            select(AgentVersion)
            .where(
                AgentVersion.agent_id == agent_id,
                AgentVersion.is_active == True
            )
            .order_by(AgentVersion.created_at.desc())
            .limit(1)
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
```

---

## 6. API 接口清单

### 6.1 Admin API（管理员）

```python
# app/api/admin/agents.py

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID
from app.core.database import get_db
from app.core.agent.registry import AgentRegistryService
from app.core.agent.lifecycle import AgentLifecycleService
from app.core.agent.mcp_binder import AgentMCPBinderService
from app.core.agent.package_installer import AlicePkgInstaller
from app.schemas.agent import *

router = APIRouter(prefix="/admin/agents", tags=["Admin - Agents"])

@router.get("/", response_model=list[AgentRegistryResponse])
async def list_agents(db: AsyncSession = Depends(get_db)):
    """列出所有 Agent"""
    service = AgentRegistryService(db)
    agents = await service.list_agents()
    return agents

@router.post("/install", response_model=AgentInstallResponse)
async def install_agent_package(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db)
):
    """从 .alicepkg 文件安装 Agent"""
    # 保存上传文件
    temp_path = Path(f"/tmp/{file.filename}")
    with open(temp_path, "wb") as f:
        f.write(await file.read())

    try:
        installer = AlicePkgInstaller(db, Path("/var/lib/alice/packages"))
        agent_id = await installer.install_from_file(temp_path)
        return {"agent_id": agent_id, "status": "installed"}
    finally:
        temp_path.unlink()

@router.post("/{agent_id}/set-meta")
async def set_meta_agent(
    agent_id: str,
    db: AsyncSession = Depends(get_db)
):
    """设置元 Agent"""
    service = AgentRegistryService(db)
    agent = await service.set_meta_agent(agent_id)
    return {"agent_id": agent.agent_id, "is_meta_agent": agent.is_meta_agent}

@router.post("/{agent_id}/mcp/{mcp_server_id}")
async def bind_mcp_to_agent(
    agent_id: str,
    mcp_server_id: UUID,
    binding_config: dict = None,
    db: AsyncSession = Depends(get_db)
):
    """绑定 MCP Server 到 Agent"""
    service = AgentMCPBinderService(db)
    binding = await service.bind_mcp(agent_id, mcp_server_id, binding_config)
    return binding

@router.delete("/{agent_id}/mcp/{mcp_server_id}")
async def unbind_mcp_from_agent(
    agent_id: str,
    mcp_server_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """解绑 MCP Server"""
    service = AgentMCPBinderService(db)
    await service.unbind_mcp(agent_id, mcp_server_id)
    return {"status": "unbound"}

@router.get("/{agent_id}/mcps")
async def list_agent_mcps(
    agent_id: str,
    db: AsyncSession = Depends(get_db)
):
    """列出 Agent 绑定的 MCP Servers"""
    service = AgentMCPBinderService(db)
    bindings = await service.list_agent_mcps(agent_id)
    return bindings
```

### 6.2 User API（普通用户）

```python
# app/api/user/agents.py

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID
from app.core.database import get_db
from app.core.agent.lifecycle import AgentLifecycleService
from app.core.auth import get_current_user

router = APIRouter(prefix="/agents", tags=["User - Agents"])

@router.get("/available")
async def list_available_agents(
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """列出可安装的 Agent"""
    from app.core.agent.registry import AgentRegistryService
    service = AgentRegistryService(db)
    return await service.list_agents()

@router.post("/{agent_id}/install")
async def install_agent(
    agent_id: str,
    version: str = None,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """安装 Agent"""
    service = AgentLifecycleService(db)
    installation = await service.install_agent(
        user_id=current_user.id,
        agent_id=agent_id,
        version=version
    )
    return installation

@router.post("/{agent_id}/enable")
async def enable_agent(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """启用 Agent"""
    service = AgentLifecycleService(db)
    return await service.enable_agent(current_user.id, agent_id)

@router.post("/{agent_id}/disable")
async def disable_agent(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """禁用 Agent"""
    service = AgentLifecycleService(db)
    return await service.disable_agent(current_user.id, agent_id)

@router.get("/installed")
async def list_installed_agents(
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """列出已安装的 Agent"""
    service = AgentLifecycleService(db)
    return await service.list_installed_agents(current_user.id)

@router.delete("/{agent_id}")
async def uninstall_agent(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """卸载 Agent"""
    service = AgentLifecycleService(db)
    await service.uninstall_agent(current_user.id, agent_id)
    return {"status": "uninstalled"}
```

### 6.3 Execution API（执行）

```python
# app/api/agent/execution.py

from fastapi import APIRouter, Depends, WebSocket
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.agent.runner import AgentRunner
from app.core.mcp.client import MCPClientManager
from app.core.auth import get_current_user
from app.schemas.agent import TaskExecuteRequest

router = APIRouter(prefix="/agent/execute", tags=["Agent Execution"])

@router.post("/{agent_id}")
async def execute_agent_task(
    agent_id: str,
    request: TaskExecuteRequest,
    db: AsyncSession = Depends(get_db),
    mcp_manager: MCPClientManager = Depends(),
    current_user = Depends(get_current_user)
):
    """执行 Agent 任务（非流式）"""
    runner = AgentRunner(db, mcp_manager)
    result = await runner.execute(
        agent_id=agent_id,
        task_type=request.task_type,
        input_data=request.input_data
    )
    return result

@router.websocket("/{agent_id}/stream")
async def execute_agent_task_stream(
    websocket: WebSocket,
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    mcp_manager: MCPClientManager = Depends()
):
    """执行 Agent 任务（流式，WebSocket）"""
    await websocket.accept()

    try:
        # 接收任务请求
        request_data = await websocket.receive_json()

        runner = AgentRunner(db, mcp_manager)

        # 注册进度回调
        async def progress_callback(task_id, progress_data):
            await websocket.send_json({
                "type": "progress",
                "task_id": str(task_id),
                "data": progress_data
            })

        executor = await runner._get_executor(agent_id)
        executor.register_progress_callback(progress_callback)

        # 执行任务
        result = await runner.execute(
            agent_id=agent_id,
            task_type=request_data["task_type"],
            input_data=request_data["input_data"]
        )

        # 发送最终结果
        await websocket.send_json({
            "type": "result",
            "data": result.dict()
        })

    except Exception as e:
        await websocket.send_json({
            "type": "error",
            "message": str(e)
        })
    finally:
        await websocket.close()
```

---

## 7. 最小运行配置

### 7.1 启动脚本

```python
# scripts/init_agents.py

"""初始化内置 Agent"""

import asyncio
from app.core.database import get_async_session
from app.agents.alice_chat import register_alice_chat_agent

async def main():
    async with get_async_session() as db:
        print("Registering Alice Chat Agent...")
        await register_alice_chat_agent(db)
        print("Done!")

if __name__ == "__main__":
    asyncio.run(main())
```

### 7.2 配置文件

```yaml
# config/agents.yaml

agents:
  packages_dir: /var/lib/alice/packages
  max_concurrent_tasks: 50
  task_timeout_seconds: 300

builtin_agents:
  - agent_id: alice.chat
    enabled: true
    config:
      model_name: claude-sonnet-4.5
      max_tokens: 4096
      temperature: 0.7
```

### 7.3 Docker Compose 配置

```yaml
# docker-compose.yml

services:
  alice-home:
    image: alice-home:latest
    environment:
      - DATABASE_URL=postgresql+asyncpg://user:pass@postgres:5432/alice
      - AGENTS_PACKAGES_DIR=/var/lib/alice/packages
    volumes:
      - agent-packages:/var/lib/alice/packages
    depends_on:
      - postgres

  postgres:
    image: postgres:14
    environment:
      - POSTGRES_DB=alice
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
    volumes:
      - pg-data:/var/lib/postgresql/data

volumes:
  agent-packages:
  pg-data:
```

---

## 8. 开发计划

### 第一阶段：基础框架（2周）

**目标**：建立核心数据模型和基础服务

**任务**：
1. 数据库表设计和迁移脚本
   - 创建所有表结构
   - 编写 Alembic 迁移
2. 实现 AgentRegistry Service
   - Agent 注册、查询、元 Agent 设置
3. 实现 AgentLifecycle Service
   - 安装、启用、禁用、卸载
4. 实现 AgentMCPBinder Service
   - MCP 绑定管理
5. 编写单元测试（覆盖率 >80%）

**交付物**：
- 完整的数据库架构
- 核心服务代码
- 单元测试套件

---

### 第二阶段：Agent 执行引擎（2周）

**目标**：实现 Agent 任务调度和执行

**任务**：
1. 实现 AgentExecutor 基类
   - Task 和 TaskResult 模型
   - 抽象方法定义
2. 实现 AgentTaskManager
   - 任务持久化
   - 任务状态追踪
3. 实现 AgentRunner
   - 动态 Executor 加载
   - 任务执行协调
4. 实现 Alice Chat Agent
   - 最小可运行对话 Agent
   - 与 MCP LLM 集成
5. 编写集成测试

**交付物**：
- 完整执行引擎
- Alice Chat Agent
- 集成测试

---

### 第三阶段：包管理和 API（2周）

**目标**：支持第三方 Agent 安装和 REST API

**任务**：
1. 实现 AlicePkgInstaller
   - 包解析和验证
   - 安装流程
2. 实现 Admin API
   - Agent 管理接口
   - MCP 绑定接口
3. 实现 User API
   - Agent 安装/启用接口
   - 查询接口
4. 实现 Execution API
   - 同步和异步执行
   - WebSocket 流式接口
5. 编写 API 文档（OpenAPI）

**交付物**：
- .alicepkg 包管理器
- 完整 REST API
- API 文档

---

### 第四阶段：生产就绪（1周）

**目标**：性能优化、监控、部署

**任务**：
1. 性能优化
   - 数据库查询优化
   - 连接池配置
2. 监控和日志
   - 结构化日志
   - Prometheus 指标
3. 部署配置
   - Docker 镜像优化
   - Kubernetes Helm Chart
4. 文档完善
   - 用户手册
   - 开发者指南
5. 端到端测试

**交付物**：
- 生产就绪代码
- 部署配置
- 完整文档

---

## 9. 测试用例

### 9.1 单元测试

```python
# tests/unit/test_agent_registry.py

import pytest
from app.core.agent.registry import AgentRegistryService
from app.schemas.agent import AgentRegistryCreate, AgentVersionCreate

@pytest.mark.asyncio
async def test_register_agent(db_session):
    """测试 Agent 注册"""
    service = AgentRegistryService(db_session)

    agent_data = AgentRegistryCreate(
        agent_id="test.agent",
        name="Test Agent",
        description="Test",
        is_builtin=False
    )

    version_data = AgentVersionCreate(
        version="1.0.0",
        a2a_capabilities={"protocol_version": "1.0"},
        entry_point="test.executor.TestExecutor",
        entry_type="python_module",
        is_active=True
    )

    agent = await service.register_agent(agent_data, version_data)

    assert agent.agent_id == "test.agent"
    assert agent.name == "Test Agent"

@pytest.mark.asyncio
async def test_set_meta_agent(db_session):
    """测试设置元 Agent"""
    service = AgentRegistryService(db_session)

    # 先注册一个 Agent
    agent_data = AgentRegistryCreate(
        agent_id="test.meta",
        name="Test Meta",
        is_builtin=True
    )
    version_data = AgentVersionCreate(
        version="1.0.0",
        a2a_capabilities={},
        entry_point="test",
        entry_type="python_module"
    )
    await service.register_agent(agent_data, version_data)

    # 设置为元 Agent
    meta_agent = await service.set_meta_agent("test.meta")
    assert meta_agent.is_meta_agent is True

    # 验证只有一个元 Agent
    all_meta = await service.list_agents()
    meta_count = sum(1 for a in all_meta if a.is_meta_agent)
    assert meta_count == 1
```

### 9.2 集成测试

```python
# tests/integration/test_agent_execution.py

import pytest
from app.core.agent.runner import AgentRunner
from app.core.agent.base import Task

@pytest.mark.asyncio
async def test_execute_alice_chat(db_session, mcp_manager):
    """测试执行 Alice Chat Agent"""
    runner = AgentRunner(db_session, mcp_manager)

    result = await runner.execute(
        agent_id="alice.chat",
        task_type="chat",
        input_data={
            "messages": [
                {"role": "user", "content": "Hello!"}
            ]
        }
    )

    assert result.status == "completed"
    assert result.output_data is not None
    assert "message" in result.output_data
```

### 9.3 端到端测试

```python
# tests/e2e/test_agent_workflow.py

import pytest
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_full_agent_workflow(api_client: AsyncClient, admin_token):
    """测试完整 Agent 工作流"""

    # 1. 管理员查看可用 Agent
    response = await api_client.get(
        "/admin/agents/",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200
    agents = response.json()
    assert len(agents) > 0

    # 2. 设置元 Agent
    response = await api_client.post(
        "/admin/agents/alice.chat/set-meta",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert response.status_code == 200

    # 3. 用户安装 Agent
    response = await api_client.post(
        "/agents/alice.chat/install",
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200

    # 4. 启用 Agent
    response = await api_client.post(
        "/agents/alice.chat/enable",
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200

    # 5. 执行任务
    response = await api_client.post(
        "/agent/execute/alice.chat",
        json={
            "task_type": "chat",
            "input_data": {
                "messages": [{"role": "user", "content": "Hello"}]
            }
        },
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200
    result = response.json()
    assert result["status"] == "completed"
```

---

## 10. 总结

### 10.1 核心价值

本实现方案提供：

1. **完整的 Agent 生命周期管理**
   - 注册、安装、启用、禁用、卸载
   - 版本管理和升级
   - 元 Agent 全局默认机制

2. **标准化协议支持**
   - 严格遵循 A2A 协议
   - 支持同步和流式执行
   - 完整的能力发现机制

3. **可扩展架构**
   - AgentExecutor 基类易于扩展
   - .alicepkg 包格式支持第三方 Agent
   - MCP 工具松耦合绑定

4. **生产就绪**
   - 完整的错误处理
   - 任务状态持久化
   - 监控和日志支持

### 10.2 技术亮点

- **异步优先**：全面采用 asyncio，高并发性能
- **类型安全**：Pydantic 模型，静态类型检查
- **数据库优化**：索引设计、查询优化
- **动态加载**：运行时加载 Agent，无需重启
- **流式支持**：WebSocket 实时数据传输

### 10.3 未来扩展方向

1. **多租户支持**：当前为单租户，可扩展为多租户
2. **Agent 市场**：第三方 Agent 发布和下载平台
3. **工作流编排**：多 Agent 协作和流程编排
4. **资源隔离**：基于容器的 Agent 沙箱执行
5. **A2A 高级特性**：Agent 间通信、能力协商、分布式执行

### 10.4 开发建议

1. **分阶段迭代**：严格按开发计划执行，确保每阶段可交付
2. **测试驱动**：TDD 方法，先写测试再实现
3. **代码审查**：所有 PR 必须审查
4. **文档同步**：代码和文档同步更新
5. **性能监控**：早期引入性能监控，避免后期优化

---

**文档版本**：v2.0
**最后更新**：2025-12-03
**作者**：Alice Team
**状态**：待评审
