# Alice Home LLM 模型管理模块 V2 实现方案

## 1. 模块概述

### 1.1 设计理念

Alice Home LLM 模型管理模块是一个统一的语言模型管理系统，旨在为管理员提供灵活的多 LLM 提供商配置能力，同时向普通用户隐藏复杂的技术细节。核心设计原则包括：

- **提供商中立**：支持多个 LLM 提供商（OpenAI、Anthropic、Azure、Ollama），统一调用接口
- **权限分离**：管理员负责配置，普通用户无感知使用
- **成本可控**：实时监控 API 调用量和成本
- **高可用性**：支持多模型负载均衡和故障转移
- **易扩展**：模块化设计，方便接入新的 LLM 提供商

### 1.2 技术栈

| 组件 | 技术选型 | 用途 |
|------|---------|------|
| Web 框架 | FastAPI | RESTful API 服务 |
| 数据库 | PostgreSQL | 持久化存储 |
| LLM 统一接口 | LiteLLM | 统一多提供商调用接口 |
| OpenAI SDK | openai-python | OpenAI 官方 SDK |
| Anthropic SDK | anthropic-python | Claude 官方 SDK |
| 本地模型 | Ollama | 本地开源模型部署 |
| ORM | SQLAlchemy | 数据库对象关系映射 |
| 数据验证 | Pydantic | 请求/响应数据验证 |

### 1.3 核心功能

1. **LLM 提供商管理**：添加、编辑、删除、测试提供商配置
2. **模型配置**：为每个提供商配置可用模型及参数
3. **Agent 绑定**：将 Agent 绑定到特定模型
4. **统一调用**：通过统一接口调用不同提供商的模型
5. **使用统计**：记录 API 调用量、Token 消耗、成本
6. **负载均衡**：多模型间自动负载分配（可选）

## 2. 数据库设计

### 2.1 llm_providers 表（LLM 提供商配置）

```sql
CREATE TABLE llm_providers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,  -- 提供商名称（如 openai-main, anthropic-prod）
    provider_type VARCHAR(50) NOT NULL, -- 提供商类型：openai, anthropic, azure, ollama
    api_key TEXT,                       -- API 密钥（加密存储）
    api_base_url TEXT,                  -- 自定义 API 地址（Ollama/Azure）
    api_version VARCHAR(50),            -- API 版本（Azure）
    organization_id TEXT,               -- 组织 ID（OpenAI）
    extra_config JSONB,                 -- 其他配置参数
    is_active BOOLEAN DEFAULT true,     -- 是否启用
    priority INTEGER DEFAULT 0,         -- 优先级（用于负载均衡）
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 索引
CREATE INDEX idx_providers_type ON llm_providers(provider_type);
CREATE INDEX idx_providers_active ON llm_providers(is_active);
```

### 2.2 llm_models 表（模型配置）

```sql
CREATE TABLE llm_models (
    id SERIAL PRIMARY KEY,
    provider_id INTEGER NOT NULL REFERENCES llm_providers(id) ON DELETE CASCADE,
    model_name VARCHAR(100) NOT NULL,   -- 模型名称（如 gpt-4, claude-3-opus）
    display_name VARCHAR(200),          -- 显示名称
    model_type VARCHAR(50),             -- 模型类型：text, chat, embedding
    max_tokens INTEGER,                 -- 最大 Token 数
    default_temperature FLOAT DEFAULT 0.7,
    default_max_tokens INTEGER,
    cost_per_1k_input_tokens DECIMAL(10, 6), -- 每 1K 输入 Token 成本（美元）
    cost_per_1k_output_tokens DECIMAL(10, 6), -- 每 1K 输出 Token 成本（美元）
    is_active BOOLEAN DEFAULT true,
    config JSONB,                       -- 模型特定配置
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(provider_id, model_name)
);

-- 索引
CREATE INDEX idx_models_provider ON llm_models(provider_id);
CREATE INDEX idx_models_active ON llm_models(is_active);
```

### 2.3 agent_model_bindings 表（Agent 与模型绑定）

```sql
CREATE TABLE agent_model_bindings (
    id SERIAL PRIMARY KEY,
    agent_id INTEGER NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    model_id INTEGER NOT NULL REFERENCES llm_models(id) ON DELETE RESTRICT,
    temperature FLOAT,                  -- 覆盖默认 Temperature
    max_tokens INTEGER,                 -- 覆盖默认 Max Tokens
    custom_config JSONB,                -- 自定义配置
    is_primary BOOLEAN DEFAULT true,    -- 是否为主模型
    fallback_model_id INTEGER REFERENCES llm_models(id), -- 故障转移模型
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(agent_id, model_id)
);

-- 索引
CREATE INDEX idx_bindings_agent ON agent_model_bindings(agent_id);
CREATE INDEX idx_bindings_model ON agent_model_bindings(model_id);
```

### 2.4 api_usage_logs 表（API 使用日志）

```sql
CREATE TABLE api_usage_logs (
    id BIGSERIAL PRIMARY KEY,
    agent_id INTEGER REFERENCES agents(id) ON DELETE SET NULL,
    model_id INTEGER REFERENCES llm_models(id) ON DELETE SET NULL,
    provider_id INTEGER REFERENCES llm_providers(id) ON DELETE SET NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    request_id VARCHAR(100),            -- 请求唯一 ID
    prompt_tokens INTEGER,              -- 输入 Token 数
    completion_tokens INTEGER,          -- 输出 Token 数
    total_tokens INTEGER,               -- 总 Token 数
    cost DECIMAL(10, 6),                -- 本次调用成本（美元）
    response_time_ms INTEGER,           -- 响应时间（毫秒）
    status VARCHAR(50),                 -- success, error, timeout
    error_message TEXT,                 -- 错误信息
    metadata JSONB,                     -- 其他元数据
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 索引（用于统计和查询）
CREATE INDEX idx_usage_agent ON api_usage_logs(agent_id);
CREATE INDEX idx_usage_model ON api_usage_logs(model_id);
CREATE INDEX idx_usage_user ON api_usage_logs(user_id);
CREATE INDEX idx_usage_created ON api_usage_logs(created_at);
CREATE INDEX idx_usage_status ON api_usage_logs(status);
```

### 2.5 数据库初始化脚本

```python
# db/init_llm_tables.py
from sqlalchemy import create_engine, text

def init_llm_tables(database_url: str):
    """初始化 LLM 管理相关表"""
    engine = create_engine(database_url)

    with engine.connect() as conn:
        # 执行上述 SQL 语句
        # ... (省略具体 SQL)

        # 插入默认 Alice 模型配置
        conn.execute(text("""
            INSERT INTO llm_providers (name, provider_type, api_key, is_active, priority)
            VALUES ('default-openai', 'openai', 'sk-default-key', true, 100);
        """))

        conn.execute(text("""
            INSERT INTO llm_models (provider_id, model_name, display_name, model_type, max_tokens, cost_per_1k_input_tokens, cost_per_1k_output_tokens)
            SELECT id, 'gpt-3.5-turbo', 'GPT-3.5 Turbo', 'chat', 4096, 0.0015, 0.002
            FROM llm_providers WHERE name = 'default-openai';
        """))

        conn.commit()
```

## 3. 核心功能实现

### 3.1 数据模型定义

```python
# models/llm.py
from sqlalchemy import Column, Integer, String, Boolean, DECIMAL, Text, TIMESTAMP, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class LLMProvider(Base):
    __tablename__ = 'llm_providers'

    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)
    provider_type = Column(String(50), nullable=False)
    api_key = Column(Text)
    api_base_url = Column(Text)
    api_version = Column(String(50))
    organization_id = Column(Text)
    extra_config = Column(JSONB)
    is_active = Column(Boolean, default=True)
    priority = Column(Integer, default=0)
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

class LLMModel(Base):
    __tablename__ = 'llm_models'

    id = Column(Integer, primary_key=True)
    provider_id = Column(Integer, ForeignKey('llm_providers.id', ondelete='CASCADE'), nullable=False)
    model_name = Column(String(100), nullable=False)
    display_name = Column(String(200))
    model_type = Column(String(50))
    max_tokens = Column(Integer)
    default_temperature = Column(DECIMAL(3, 2), default=0.7)
    default_max_tokens = Column(Integer)
    cost_per_1k_input_tokens = Column(DECIMAL(10, 6))
    cost_per_1k_output_tokens = Column(DECIMAL(10, 6))
    is_active = Column(Boolean, default=True)
    config = Column(JSONB)
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

class AgentModelBinding(Base):
    __tablename__ = 'agent_model_bindings'

    id = Column(Integer, primary_key=True)
    agent_id = Column(Integer, ForeignKey('agents.id', ondelete='CASCADE'), nullable=False)
    model_id = Column(Integer, ForeignKey('llm_models.id', ondelete='RESTRICT'), nullable=False)
    temperature = Column(DECIMAL(3, 2))
    max_tokens = Column(Integer)
    custom_config = Column(JSONB)
    is_primary = Column(Boolean, default=True)
    fallback_model_id = Column(Integer, ForeignKey('llm_models.id'))
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

class APIUsageLog(Base):
    __tablename__ = 'api_usage_logs'

    id = Column(Integer, primary_key=True)
    agent_id = Column(Integer, ForeignKey('agents.id', ondelete='SET NULL'))
    model_id = Column(Integer, ForeignKey('llm_models.id', ondelete='SET NULL'))
    provider_id = Column(Integer, ForeignKey('llm_providers.id', ondelete='SET NULL'))
    user_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    request_id = Column(String(100))
    prompt_tokens = Column(Integer)
    completion_tokens = Column(Integer)
    total_tokens = Column(Integer)
    cost = Column(DECIMAL(10, 6))
    response_time_ms = Column(Integer)
    status = Column(String(50))
    error_message = Column(Text)
    metadata = Column(JSONB)
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
```

### 3.2 Pydantic 模式定义

```python
# schemas/llm.py
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime

class LLMProviderCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    provider_type: str = Field(..., regex="^(openai|anthropic|azure|ollama)$")
    api_key: Optional[str] = None
    api_base_url: Optional[str] = None
    api_version: Optional[str] = None
    organization_id: Optional[str] = None
    extra_config: Optional[Dict[str, Any]] = None
    is_active: bool = True
    priority: int = 0

class LLMProviderResponse(BaseModel):
    id: int
    name: str
    provider_type: str
    api_base_url: Optional[str]
    api_version: Optional[str]
    is_active: bool
    priority: int
    created_at: datetime

    class Config:
        from_attributes = True

class LLMModelCreate(BaseModel):
    provider_id: int
    model_name: str
    display_name: Optional[str] = None
    model_type: str = "chat"
    max_tokens: Optional[int] = None
    default_temperature: float = 0.7
    default_max_tokens: Optional[int] = None
    cost_per_1k_input_tokens: Optional[float] = None
    cost_per_1k_output_tokens: Optional[float] = None
    is_active: bool = True
    config: Optional[Dict[str, Any]] = None

class LLMModelResponse(BaseModel):
    id: int
    provider_id: int
    model_name: str
    display_name: Optional[str]
    model_type: str
    max_tokens: Optional[int]
    default_temperature: float
    cost_per_1k_input_tokens: Optional[float]
    cost_per_1k_output_tokens: Optional[float]
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

class AgentModelBindingCreate(BaseModel):
    agent_id: int
    model_id: int
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    custom_config: Optional[Dict[str, Any]] = None
    is_primary: bool = True
    fallback_model_id: Optional[int] = None

class ChatRequest(BaseModel):
    agent_id: int
    messages: list[Dict[str, str]]  # [{"role": "user", "content": "..."}]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    stream: bool = False

class UsageStats(BaseModel):
    total_requests: int
    total_tokens: int
    total_cost: float
    average_response_time_ms: float
    success_rate: float
```

### 3.3 LLM 提供商管理服务

```python
# services/llm_provider_service.py
from sqlalchemy.orm import Session
from models.llm import LLMProvider, LLMModel
from schemas.llm import LLMProviderCreate, LLMModelCreate
from typing import List, Optional
import litellm
from cryptography.fernet import Fernet

class LLMProviderService:
    def __init__(self, db: Session, encryption_key: str):
        self.db = db
        self.cipher = Fernet(encryption_key.encode())

    def _encrypt_api_key(self, api_key: str) -> str:
        """加密 API 密钥"""
        return self.cipher.encrypt(api_key.encode()).decode()

    def _decrypt_api_key(self, encrypted_key: str) -> str:
        """解密 API 密钥"""
        return self.cipher.decrypt(encrypted_key.encode()).decode()

    def create_provider(self, provider_data: LLMProviderCreate) -> LLMProvider:
        """创建 LLM 提供商"""
        encrypted_key = None
        if provider_data.api_key:
            encrypted_key = self._encrypt_api_key(provider_data.api_key)

        provider = LLMProvider(
            name=provider_data.name,
            provider_type=provider_data.provider_type,
            api_key=encrypted_key,
            api_base_url=provider_data.api_base_url,
            api_version=provider_data.api_version,
            organization_id=provider_data.organization_id,
            extra_config=provider_data.extra_config,
            is_active=provider_data.is_active,
            priority=provider_data.priority
        )

        self.db.add(provider)
        self.db.commit()
        self.db.refresh(provider)
        return provider

    def get_provider(self, provider_id: int) -> Optional[LLMProvider]:
        """获取提供商信息"""
        return self.db.query(LLMProvider).filter(LLMProvider.id == provider_id).first()

    def list_providers(self, active_only: bool = False) -> List[LLMProvider]:
        """列出所有提供商"""
        query = self.db.query(LLMProvider)
        if active_only:
            query = query.filter(LLMProvider.is_active == True)
        return query.order_by(LLMProvider.priority.desc()).all()

    def update_provider(self, provider_id: int, provider_data: LLMProviderCreate) -> Optional[LLMProvider]:
        """更新提供商配置"""
        provider = self.get_provider(provider_id)
        if not provider:
            return None

        for key, value in provider_data.dict(exclude_unset=True).items():
            if key == 'api_key' and value:
                value = self._encrypt_api_key(value)
            setattr(provider, key, value)

        self.db.commit()
        self.db.refresh(provider)
        return provider

    def delete_provider(self, provider_id: int) -> bool:
        """删除提供商"""
        provider = self.get_provider(provider_id)
        if not provider:
            return False

        self.db.delete(provider)
        self.db.commit()
        return True

    def test_provider_connection(self, provider_id: int) -> dict:
        """测试提供商连接"""
        provider = self.get_provider(provider_id)
        if not provider:
            return {"success": False, "error": "Provider not found"}

        try:
            # 使用 LiteLLM 测试连接
            api_key = self._decrypt_api_key(provider.api_key) if provider.api_key else None

            test_params = {
                "model": self._get_test_model_name(provider.provider_type),
                "messages": [{"role": "user", "content": "Hi"}],
                "max_tokens": 10
            }

            if provider.provider_type == "openai":
                test_params["api_key"] = api_key
            elif provider.provider_type == "anthropic":
                test_params["api_key"] = api_key
            elif provider.provider_type == "azure":
                test_params["api_key"] = api_key
                test_params["api_base"] = provider.api_base_url
                test_params["api_version"] = provider.api_version
            elif provider.provider_type == "ollama":
                test_params["api_base"] = provider.api_base_url or "http://localhost:11434"

            response = litellm.completion(**test_params)
            return {"success": True, "message": "Connection successful"}

        except Exception as e:
            return {"success": False, "error": str(e)}

    def _get_test_model_name(self, provider_type: str) -> str:
        """获取测试用的模型名称"""
        test_models = {
            "openai": "gpt-3.5-turbo",
            "anthropic": "claude-3-haiku-20240307",
            "azure": "gpt-35-turbo",
            "ollama": "llama2"
        }
        return test_models.get(provider_type, "gpt-3.5-turbo")

    def create_model(self, model_data: LLMModelCreate) -> LLMModel:
        """为提供商创建模型配置"""
        model = LLMModel(**model_data.dict())
        self.db.add(model)
        self.db.commit()
        self.db.refresh(model)
        return model

    def list_models(self, provider_id: Optional[int] = None, active_only: bool = False) -> List[LLMModel]:
        """列出模型"""
        query = self.db.query(LLMModel)
        if provider_id:
            query = query.filter(LLMModel.provider_id == provider_id)
        if active_only:
            query = query.filter(LLMModel.is_active == True)
        return query.all()
```

### 3.4 统一 LLM 调用服务

```python
# services/llm_service.py
from sqlalchemy.orm import Session
from models.llm import AgentModelBinding, LLMModel, LLMProvider, APIUsageLog
from schemas.llm import ChatRequest
from typing import Optional, Dict, Any, AsyncIterator
import litellm
import time
import uuid
from datetime import datetime

class LLMService:
    def __init__(self, db: Session, provider_service):
        self.db = db
        self.provider_service = provider_service

    def get_agent_model_binding(self, agent_id: int) -> Optional[AgentModelBinding]:
        """获取 Agent 的主模型绑定"""
        return self.db.query(AgentModelBinding).filter(
            AgentModelBinding.agent_id == agent_id,
            AgentModelBinding.is_primary == True
        ).first()

    def bind_agent_to_model(self, agent_id: int, model_id: int, **kwargs) -> AgentModelBinding:
        """绑定 Agent 到模型"""
        # 取消当前主模型
        self.db.query(AgentModelBinding).filter(
            AgentModelBinding.agent_id == agent_id,
            AgentModelBinding.is_primary == True
        ).update({"is_primary": False})

        binding = AgentModelBinding(
            agent_id=agent_id,
            model_id=model_id,
            is_primary=True,
            **kwargs
        )
        self.db.add(binding)
        self.db.commit()
        self.db.refresh(binding)
        return binding

    async def chat_completion(self, request: ChatRequest, user_id: Optional[int] = None) -> Dict[str, Any]:
        """统一聊天完成接口"""
        start_time = time.time()
        request_id = str(uuid.uuid4())

        # 获取 Agent 绑定的模型
        binding = self.get_agent_model_binding(request.agent_id)
        if not binding:
            raise ValueError(f"Agent {request.agent_id} has no model binding")

        # 获取模型和提供商信息
        model = self.db.query(LLMModel).filter(LLMModel.id == binding.model_id).first()
        provider = self.db.query(LLMProvider).filter(LLMProvider.id == model.provider_id).first()

        if not model or not provider or not provider.is_active:
            raise ValueError("Model or provider not available")

        # 准备调用参数
        temperature = request.temperature or binding.temperature or model.default_temperature
        max_tokens = request.max_tokens or binding.max_tokens or model.default_max_tokens

        api_key = self.provider_service._decrypt_api_key(provider.api_key) if provider.api_key else None

        # 构建 LiteLLM 调用参数
        litellm_params = {
            "model": self._get_litellm_model_name(provider.provider_type, model.model_name),
            "messages": request.messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": request.stream
        }

        # 根据提供商类型添加特定配置
        if provider.provider_type == "openai":
            litellm_params["api_key"] = api_key
            if provider.organization_id:
                litellm_params["organization"] = provider.organization_id
        elif provider.provider_type == "anthropic":
            litellm_params["api_key"] = api_key
        elif provider.provider_type == "azure":
            litellm_params["api_key"] = api_key
            litellm_params["api_base"] = provider.api_base_url
            litellm_params["api_version"] = provider.api_version
        elif provider.provider_type == "ollama":
            litellm_params["api_base"] = provider.api_base_url or "http://localhost:11434"

        try:
            # 调用 LLM
            if request.stream:
                return await self._stream_completion(
                    litellm_params, request_id, request.agent_id,
                    model.id, provider.id, user_id, start_time
                )
            else:
                response = await litellm.acompletion(**litellm_params)

                # 记录使用日志
                response_time = int((time.time() - start_time) * 1000)
                usage = response.get('usage', {})

                self._log_usage(
                    agent_id=request.agent_id,
                    model_id=model.id,
                    provider_id=provider.id,
                    user_id=user_id,
                    request_id=request_id,
                    prompt_tokens=usage.get('prompt_tokens', 0),
                    completion_tokens=usage.get('completion_tokens', 0),
                    total_tokens=usage.get('total_tokens', 0),
                    cost=self._calculate_cost(model, usage),
                    response_time_ms=response_time,
                    status="success"
                )

                return {
                    "request_id": request_id,
                    "response": response.choices[0].message.content,
                    "usage": usage,
                    "model": model.model_name,
                    "provider": provider.provider_type
                }

        except Exception as e:
            # 记录错误
            response_time = int((time.time() - start_time) * 1000)
            self._log_usage(
                agent_id=request.agent_id,
                model_id=model.id,
                provider_id=provider.id,
                user_id=user_id,
                request_id=request_id,
                status="error",
                error_message=str(e),
                response_time_ms=response_time
            )

            # 尝试故障转移
            if binding.fallback_model_id:
                return await self._try_fallback(request, binding.fallback_model_id, user_id)

            raise

    async def _stream_completion(self, params: dict, request_id: str, agent_id: int,
                                 model_id: int, provider_id: int, user_id: Optional[int],
                                 start_time: float) -> AsyncIterator[str]:
        """流式响应处理"""
        total_tokens = 0
        completion_text = ""

        try:
            async for chunk in await litellm.acompletion(**params):
                if chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    completion_text += content
                    yield content

            # 流结束后记录日志
            response_time = int((time.time() - start_time) * 1000)
            self._log_usage(
                agent_id=agent_id,
                model_id=model_id,
                provider_id=provider_id,
                user_id=user_id,
                request_id=request_id,
                completion_tokens=len(completion_text.split()),  # 简化计算
                response_time_ms=response_time,
                status="success"
            )

        except Exception as e:
            response_time = int((time.time() - start_time) * 1000)
            self._log_usage(
                agent_id=agent_id,
                model_id=model_id,
                provider_id=provider_id,
                user_id=user_id,
                request_id=request_id,
                status="error",
                error_message=str(e),
                response_time_ms=response_time
            )
            raise

    def _get_litellm_model_name(self, provider_type: str, model_name: str) -> str:
        """转换为 LiteLLM 格式的模型名称"""
        if provider_type == "openai":
            return model_name
        elif provider_type == "anthropic":
            return f"anthropic/{model_name}"
        elif provider_type == "azure":
            return f"azure/{model_name}"
        elif provider_type == "ollama":
            return f"ollama/{model_name}"
        return model_name

    def _calculate_cost(self, model: LLMModel, usage: dict) -> float:
        """计算调用成本"""
        if not model.cost_per_1k_input_tokens or not model.cost_per_1k_output_tokens:
            return 0.0

        input_cost = (usage.get('prompt_tokens', 0) / 1000) * float(model.cost_per_1k_input_tokens)
        output_cost = (usage.get('completion_tokens', 0) / 1000) * float(model.cost_per_1k_output_tokens)
        return round(input_cost + output_cost, 6)

    def _log_usage(self, **kwargs):
        """记录 API 使用日志"""
        log = APIUsageLog(**kwargs)
        self.db.add(log)
        self.db.commit()

    async def _try_fallback(self, request: ChatRequest, fallback_model_id: int, user_id: Optional[int]):
        """故障转移到备用模型"""
        # 创建临时绑定并重试
        original_binding = self.get_agent_model_binding(request.agent_id)

        # 临时更新绑定
        temp_binding = AgentModelBinding(
            agent_id=request.agent_id,
            model_id=fallback_model_id,
            is_primary=False
        )
        self.db.add(temp_binding)
        self.db.flush()

        try:
            response = await self.chat_completion(request, user_id)
            return response
        finally:
            # 清理临时绑定
            self.db.delete(temp_binding)
            self.db.commit()
```

### 3.5 统计分析服务

```python
# services/analytics_service.py
from sqlalchemy.orm import Session
from sqlalchemy import func
from models.llm import APIUsageLog
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

class AnalyticsService:
    def __init__(self, db: Session):
        self.db = db

    def get_usage_stats(
        self,
        agent_id: Optional[int] = None,
        user_id: Optional[int] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """获取使用统计"""
        query = self.db.query(APIUsageLog)

        if agent_id:
            query = query.filter(APIUsageLog.agent_id == agent_id)
        if user_id:
            query = query.filter(APIUsageLog.user_id == user_id)
        if start_date:
            query = query.filter(APIUsageLog.created_at >= start_date)
        if end_date:
            query = query.filter(APIUsageLog.created_at <= end_date)

        total_requests = query.count()

        stats = query.with_entities(
            func.sum(APIUsageLog.total_tokens).label('total_tokens'),
            func.sum(APIUsageLog.cost).label('total_cost'),
            func.avg(APIUsageLog.response_time_ms).label('avg_response_time'),
            func.count().filter(APIUsageLog.status == 'success').label('success_count')
        ).first()

        return {
            "total_requests": total_requests,
            "total_tokens": int(stats.total_tokens or 0),
            "total_cost": float(stats.total_cost or 0),
            "average_response_time_ms": float(stats.avg_response_time or 0),
            "success_rate": (stats.success_count / total_requests * 100) if total_requests > 0 else 0
        }

    def get_cost_by_model(self, start_date: Optional[datetime] = None) -> list:
        """按模型统计成本"""
        query = self.db.query(
            APIUsageLog.model_id,
            func.sum(APIUsageLog.cost).label('total_cost'),
            func.count().label('request_count')
        )

        if start_date:
            query = query.filter(APIUsageLog.created_at >= start_date)

        return query.group_by(APIUsageLog.model_id).all()

    def get_daily_usage(self, days: int = 30) -> list:
        """获取每日使用量"""
        start_date = datetime.utcnow() - timedelta(days=days)

        return self.db.query(
            func.date(APIUsageLog.created_at).label('date'),
            func.count().label('requests'),
            func.sum(APIUsageLog.total_tokens).label('tokens'),
            func.sum(APIUsageLog.cost).label('cost')
        ).filter(
            APIUsageLog.created_at >= start_date
        ).group_by(
            func.date(APIUsageLog.created_at)
        ).order_by('date').all()
```

## 4. 支持的 LLM 提供商

### 4.1 OpenAI

**支持模型：**
- GPT-4 Turbo (`gpt-4-turbo-preview`)
- GPT-4 (`gpt-4`)
- GPT-3.5 Turbo (`gpt-3.5-turbo`)

**配置示例：**
```json
{
  "name": "openai-main",
  "provider_type": "openai",
  "api_key": "sk-xxx",
  "organization_id": "org-xxx",
  "is_active": true,
  "priority": 100
}
```

**定价（截至 2024）：**
- GPT-4 Turbo: $0.01 / 1K input tokens, $0.03 / 1K output tokens
- GPT-3.5 Turbo: $0.0015 / 1K input tokens, $0.002 / 1K output tokens

### 4.2 Anthropic Claude

**支持模型：**
- Claude 3.5 Sonnet (`claude-3-5-sonnet-20240620`)
- Claude 3 Opus (`claude-3-opus-20240229`)
- Claude 3 Haiku (`claude-3-haiku-20240307`)

**配置示例：**
```json
{
  "name": "anthropic-main",
  "provider_type": "anthropic",
  "api_key": "sk-ant-xxx",
  "is_active": true,
  "priority": 90
}
```

**定价：**
- Claude 3.5 Sonnet: $0.003 / 1K input tokens, $0.015 / 1K output tokens
- Claude 3 Opus: $0.015 / 1K input tokens, $0.075 / 1K output tokens
- Claude 3 Haiku: $0.00025 / 1K input tokens, $0.00125 / 1K output tokens

### 4.3 Azure OpenAI

**支持模型：**
- GPT-4 (`gpt-4`)
- GPT-3.5 Turbo (`gpt-35-turbo`)

**配置示例：**
```json
{
  "name": "azure-openai",
  "provider_type": "azure",
  "api_key": "xxx",
  "api_base_url": "https://your-resource.openai.azure.com/",
  "api_version": "2024-02-15-preview",
  "is_active": true,
  "priority": 80
}
```

### 4.4 Ollama（本地模型）

**支持模型：**
- Llama 2 (`llama2`)
- Mistral (`mistral`)
- CodeLlama (`codellama`)
- 其他开源模型

**配置示例：**
```json
{
  "name": "ollama-local",
  "provider_type": "ollama",
  "api_base_url": "http://localhost:11434",
  "is_active": true,
  "priority": 50
}
```

**优势：**
- 无 API 成本
- 数据隐私保护
- 离线可用

## 5. API 接口清单

### 5.1 提供商管理接口

```python
# routes/llm_provider.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from schemas.llm import LLMProviderCreate, LLMProviderResponse
from services.llm_provider_service import LLMProviderService
from typing import List

router = APIRouter(prefix="/api/admin/llm-providers", tags=["LLM Providers"])

@router.post("/", response_model=LLMProviderResponse, status_code=201)
async def create_provider(
    provider: LLMProviderCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """创建 LLM 提供商（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    return service.create_provider(provider)

@router.get("/", response_model=List[LLMProviderResponse])
async def list_providers(
    active_only: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """列出所有提供商（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    return service.list_providers(active_only)

@router.get("/{provider_id}", response_model=LLMProviderResponse)
async def get_provider(
    provider_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """获取提供商详情（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    provider = service.get_provider(provider_id)
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    return provider

@router.put("/{provider_id}", response_model=LLMProviderResponse)
async def update_provider(
    provider_id: int,
    provider: LLMProviderCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """更新提供商配置（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    updated = service.update_provider(provider_id, provider)
    if not updated:
        raise HTTPException(status_code=404, detail="Provider not found")
    return updated

@router.delete("/{provider_id}", status_code=204)
async def delete_provider(
    provider_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """删除提供商（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    if not service.delete_provider(provider_id):
        raise HTTPException(status_code=404, detail="Provider not found")

@router.post("/{provider_id}/test")
async def test_provider(
    provider_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """测试提供商连接（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    result = service.test_provider_connection(provider_id)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
    return result
```

### 5.2 模型管理接口

```python
# routes/llm_model.py
from fastapi import APIRouter, Depends
from schemas.llm import LLMModelCreate, LLMModelResponse
from typing import List

router = APIRouter(prefix="/api/admin/llm-models", tags=["LLM Models"])

@router.post("/", response_model=LLMModelResponse, status_code=201)
async def create_model(
    model: LLMModelCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """创建模型配置（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    return service.create_model(model)

@router.get("/", response_model=List[LLMModelResponse])
async def list_models(
    provider_id: Optional[int] = None,
    active_only: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """列出模型（仅管理员）"""
    service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    return service.list_models(provider_id, active_only)
```

### 5.3 Agent 模型绑定接口

```python
# routes/agent_binding.py
from fastapi import APIRouter, Depends
from schemas.llm import AgentModelBindingCreate

router = APIRouter(prefix="/api/admin/agent-bindings", tags=["Agent Bindings"])

@router.post("/", status_code=201)
async def bind_agent_to_model(
    binding: AgentModelBindingCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """绑定 Agent 到模型（仅管理员）"""
    service = LLMService(db, LLMProviderService(db, settings.ENCRYPTION_KEY))
    return service.bind_agent_to_model(
        agent_id=binding.agent_id,
        model_id=binding.model_id,
        temperature=binding.temperature,
        max_tokens=binding.max_tokens,
        custom_config=binding.custom_config,
        fallback_model_id=binding.fallback_model_id
    )
```

### 5.4 统一聊天接口（普通用户可用）

```python
# routes/chat.py
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from schemas.llm import ChatRequest

router = APIRouter(prefix="/api/chat", tags=["Chat"])

@router.post("/completions")
async def chat_completion(
    request: ChatRequest,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """聊天完成接口（所有用户可用）"""
    provider_service = LLMProviderService(db, settings.ENCRYPTION_KEY)
    llm_service = LLMService(db, provider_service)

    if request.stream:
        async def generate():
            async for chunk in await llm_service.chat_completion(request, current_user.id):
                yield chunk

        return StreamingResponse(generate(), media_type="text/event-stream")
    else:
        return await llm_service.chat_completion(request, current_user.id)
```

### 5.5 统计分析接口

```python
# routes/analytics.py
from fastapi import APIRouter, Depends, Query
from datetime import datetime, timedelta
from typing import Optional

router = APIRouter(prefix="/api/admin/analytics", tags=["Analytics"])

@router.get("/usage")
async def get_usage_stats(
    agent_id: Optional[int] = None,
    user_id: Optional[int] = None,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """获取使用统计（仅管理员）"""
    service = AnalyticsService(db)
    start_date = datetime.utcnow() - timedelta(days=days)
    return service.get_usage_stats(agent_id, user_id, start_date)

@router.get("/cost-by-model")
async def get_cost_by_model(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """按模型统计成本（仅管理员）"""
    service = AnalyticsService(db)
    start_date = datetime.utcnow() - timedelta(days=days)
    return service.get_cost_by_model(start_date)

@router.get("/daily-usage")
async def get_daily_usage(
    days: int = Query(30, ge=1, le=90),
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    """获取每日使用量（仅管理员）"""
    service = AnalyticsService(db)
    return service.get_daily_usage(days)
```

## 6. 最小运行配置

### 6.1 预置配置脚本

```python
# scripts/setup_default_llm.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from services.llm_provider_service import LLMProviderService
from schemas.llm import LLMProviderCreate, LLMModelCreate

def setup_default_llm():
    """设置默认 LLM 配置"""
    DATABASE_URL = os.getenv("DATABASE_URL")
    ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-default-key")

    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    db = Session()

    try:
        service = LLMProviderService(db, ENCRYPTION_KEY)

        # 1. 创建 OpenAI 提供商
        provider = service.create_provider(LLMProviderCreate(
            name="default-openai",
            provider_type="openai",
            api_key=OPENAI_API_KEY,
            is_active=True,
            priority=100
        ))

        print(f"Created provider: {provider.name} (ID: {provider.id})")

        # 2. 创建 GPT-3.5 Turbo 模型
        model = service.create_model(LLMModelCreate(
            provider_id=provider.id,
            model_name="gpt-3.5-turbo",
            display_name="GPT-3.5 Turbo (Default Alice)",
            model_type="chat",
            max_tokens=4096,
            default_temperature=0.7,
            default_max_tokens=2000,
            cost_per_1k_input_tokens=0.0015,
            cost_per_1k_output_tokens=0.002,
            is_active=True
        ))

        print(f"Created model: {model.model_name} (ID: {model.id})")

        # 3. 测试连接
        test_result = service.test_provider_connection(provider.id)
        if test_result["success"]:
            print("Provider connection test: SUCCESS")
        else:
            print(f"Provider connection test: FAILED - {test_result['error']}")

        db.commit()
        print("\nDefault LLM setup completed!")
        print(f"Provider ID: {provider.id}, Model ID: {model.id}")

    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    setup_default_llm()
```

### 6.2 环境变量配置

```bash
# .env
DATABASE_URL=postgresql://user:password@localhost:5432/alice_home
ENCRYPTION_KEY=your-32-byte-encryption-key-here
OPENAI_API_KEY=sk-your-openai-api-key
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key
```

### 6.3 Docker Compose 配置（含 Ollama）

```yaml
# docker-compose.yml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: alice_home
      POSTGRES_USER: alice
      POSTGRES_PASSWORD: alice123
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  ollama:
    image: ollama/ollama:latest
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    # 可选：预下载模型
    # command: ["ollama", "pull", "llama2"]

  alice-api:
    build: .
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: postgresql://alice:alice123@postgres:5432/alice_home
      ENCRYPTION_KEY: ${ENCRYPTION_KEY}
      OPENAI_API_KEY: ${OPENAI_API_KEY}
      ANTHROPIC_API_KEY: ${ANTHROPIC_API_KEY}
    depends_on:
      - postgres
      - ollama

volumes:
  postgres_data:
  ollama_data:
```

## 7. 开发计划

### 7.1 Phase 1: 核心功能（2 周）

**Week 1:**
- [ ] 数据库表结构设计与创建
- [ ] LLM Provider 基础模型实现
- [ ] 加密服务实现（API Key 安全存储）
- [ ] LLMProviderService 实现
- [ ] 提供商管理 API（CRUD）

**Week 2:**
- [ ] LLM Model 配置管理
- [ ] Agent 模型绑定功能
- [ ] LiteLLM 集成
- [ ] 统一聊天完成接口实现
- [ ] 基础单元测试

### 7.2 Phase 2: 多提供商支持（1 周）

- [ ] OpenAI 提供商适配
- [ ] Anthropic Claude 适配
- [ ] Azure OpenAI 适配
- [ ] Ollama 本地模型适配
- [ ] 提供商连接测试功能
- [ ] 各提供商集成测试

### 7.3 Phase 3: 监控与统计（1 周）

- [ ] API 使用日志记录
- [ ] 成本计算逻辑
- [ ] 使用统计查询接口
- [ ] 按模型/用户/时间维度统计
- [ ] 每日使用趋势分析
- [ ] 管理后台统计图表

### 7.4 Phase 4: 高级功能（1 周）

- [ ] 故障转移机制
- [ ] 多模型负载均衡
- [ ] 流式响应支持
- [ ] API 限流和配额管理
- [ ] 模型性能监控
- [ ] 告警通知（成本超标、错误率高）

### 7.5 Phase 5: 优化与文档（1 周）

- [ ] 性能优化（数据库索引、缓存）
- [ ] API 文档完善
- [ ] 部署文档编写
- [ ] 运维手册
- [ ] 最佳实践指南
- [ ] 安全审计

## 8. 测试用例

### 8.1 单元测试

```python
# tests/test_llm_provider_service.py
import pytest
from services.llm_provider_service import LLMProviderService
from schemas.llm import LLMProviderCreate

def test_create_provider(db_session, encryption_key):
    """测试创建提供商"""
    service = LLMProviderService(db_session, encryption_key)

    provider_data = LLMProviderCreate(
        name="test-openai",
        provider_type="openai",
        api_key="sk-test-key",
        is_active=True,
        priority=100
    )

    provider = service.create_provider(provider_data)

    assert provider.id is not None
    assert provider.name == "test-openai"
    assert provider.provider_type == "openai"
    assert provider.api_key != "sk-test-key"  # 应该被加密

def test_encrypt_decrypt_api_key(db_session, encryption_key):
    """测试 API Key 加密解密"""
    service = LLMProviderService(db_session, encryption_key)

    original_key = "sk-test-key-12345"
    encrypted = service._encrypt_api_key(original_key)
    decrypted = service._decrypt_api_key(encrypted)

    assert encrypted != original_key
    assert decrypted == original_key

def test_list_providers(db_session, encryption_key):
    """测试列出提供商"""
    service = LLMProviderService(db_session, encryption_key)

    # 创建两个提供商
    service.create_provider(LLMProviderCreate(
        name="provider-1",
        provider_type="openai",
        is_active=True
    ))

    service.create_provider(LLMProviderCreate(
        name="provider-2",
        provider_type="anthropic",
        is_active=False
    ))

    all_providers = service.list_providers(active_only=False)
    active_providers = service.list_providers(active_only=True)

    assert len(all_providers) == 2
    assert len(active_providers) == 1
```

### 8.2 集成测试

```python
# tests/test_llm_service_integration.py
import pytest
from services.llm_service import LLMService
from schemas.llm import ChatRequest

@pytest.mark.asyncio
async def test_chat_completion_openai(db_session, provider_service):
    """测试 OpenAI 聊天完成"""
    llm_service = LLMService(db_session, provider_service)

    # 假设已有 agent 和 model 绑定
    request = ChatRequest(
        agent_id=1,
        messages=[{"role": "user", "content": "Hello"}],
        temperature=0.7,
        max_tokens=100,
        stream=False
    )

    response = await llm_service.chat_completion(request, user_id=1)

    assert "request_id" in response
    assert "response" in response
    assert "usage" in response
    assert response["model"] == "gpt-3.5-turbo"

@pytest.mark.asyncio
async def test_fallback_on_error(db_session, provider_service):
    """测试故障转移"""
    llm_service = LLMService(db_session, provider_service)

    # 配置主模型（故意使用无效 API Key）和备用模型
    # 验证在主模型失败时自动切换到备用模型
    # ... 测试逻辑
```

### 8.3 API 测试

```python
# tests/test_api_endpoints.py
from fastapi.testclient import TestClient

def test_create_provider_endpoint(client: TestClient, admin_token):
    """测试创建提供商 API"""
    response = client.post(
        "/api/admin/llm-providers/",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "name": "test-provider",
            "provider_type": "openai",
            "api_key": "sk-test",
            "is_active": True,
            "priority": 100
        }
    )

    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "test-provider"
    assert "api_key" not in data  # 不应返回密钥

def test_unauthorized_access(client: TestClient, user_token):
    """测试普通用户无法访问管理接口"""
    response = client.get(
        "/api/admin/llm-providers/",
        headers={"Authorization": f"Bearer {user_token}"}
    )

    assert response.status_code == 403

def test_chat_completion_endpoint(client: TestClient, user_token):
    """测试聊天完成 API（普通用户可用）"""
    response = client.post(
        "/api/chat/completions",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "agent_id": 1,
            "messages": [{"role": "user", "content": "Hello"}],
            "stream": False
        }
    )

    assert response.status_code == 200
    data = response.json()
    assert "response" in data
```

### 8.4 成本计算测试

```python
# tests/test_cost_calculation.py
def test_calculate_cost(db_session):
    """测试成本计算"""
    from services.llm_service import LLMService
    from models.llm import LLMModel

    model = LLMModel(
        model_name="gpt-4",
        cost_per_1k_input_tokens=0.03,
        cost_per_1k_output_tokens=0.06
    )

    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 500
    }

    cost = LLMService._calculate_cost(None, model, usage)

    # 1000 * 0.03 / 1000 + 500 * 0.06 / 1000 = 0.03 + 0.03 = 0.06
    assert cost == 0.06
```

## 9. 安全考虑

### 9.1 API Key 安全

```python
# utils/encryption.py
from cryptography.fernet import Fernet
import os

def generate_encryption_key() -> str:
    """生成加密密钥"""
    return Fernet.generate_key().decode()

def get_encryption_key() -> str:
    """从环境变量获取加密密钥"""
    key = os.getenv("ENCRYPTION_KEY")
    if not key:
        raise ValueError("ENCRYPTION_KEY not set in environment")
    return key
```

### 9.2 权限控制

```python
# dependencies/auth.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """获取当前用户"""
    # JWT 验证逻辑
    # ...
    return user

async def require_admin(current_user = Depends(get_current_user)):
    """要求管理员权限"""
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required"
        )
    return current_user
```

### 9.3 敏感信息脱敏

```python
# schemas/llm.py (补充)
class LLMProviderResponse(BaseModel):
    # ... 其他字段

    @validator('api_key', always=True)
    def hide_api_key(cls, v):
        """隐藏 API Key"""
        return None  # 永不返回 API Key

    class Config:
        from_attributes = True
```

## 10. 性能优化

### 10.1 数据库连接池

```python
# db/database.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import QueuePool

engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,
    max_overflow=40,
    pool_pre_ping=True
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
```

### 10.2 缓存提供商配置

```python
# services/llm_provider_service.py (增强版)
from functools import lru_cache
from datetime import datetime, timedelta

class LLMProviderService:
    def __init__(self, db: Session, encryption_key: str):
        self.db = db
        self.cipher = Fernet(encryption_key.encode())
        self._cache = {}
        self._cache_ttl = timedelta(minutes=5)

    def get_provider_cached(self, provider_id: int) -> Optional[LLMProvider]:
        """带缓存的提供商获取"""
        cache_key = f"provider_{provider_id}"

        if cache_key in self._cache:
            cached_time, provider = self._cache[cache_key]
            if datetime.utcnow() - cached_time < self._cache_ttl:
                return provider

        provider = self.get_provider(provider_id)
        if provider:
            self._cache[cache_key] = (datetime.utcnow(), provider)

        return provider
```

### 10.3 异步批量日志写入

```python
# services/llm_service.py (优化版)
import asyncio
from collections import deque

class LLMService:
    def __init__(self, db: Session, provider_service):
        self.db = db
        self.provider_service = provider_service
        self._log_queue = deque()
        self._batch_size = 100

    async def _batch_log_usage(self):
        """批量写入日志"""
        while True:
            if len(self._log_queue) >= self._batch_size:
                batch = [self._log_queue.popleft() for _ in range(self._batch_size)]
                self.db.bulk_insert_mappings(APIUsageLog, batch)
                self.db.commit()

            await asyncio.sleep(1)

    def _log_usage(self, **kwargs):
        """添加到日志队列"""
        self._log_queue.append(kwargs)
```

## 11. 总结

### 11.1 核心价值

Alice Home LLM 模型管理模块提供了一个**统一、灵活、可扩展**的语言模型管理解决方案：

1. **统一接口**：通过 LiteLLM 统一多个 LLM 提供商的调用方式
2. **权限分离**：管理员配置，普通用户无感知使用
3. **成本可控**：实时监控 API 调用和成本
4. **高可用**：支持故障转移和负载均衡
5. **易扩展**：模块化设计，方便添加新提供商

### 11.2 技术亮点

- **多提供商支持**：OpenAI、Anthropic、Azure、Ollama
- **安全性**：API Key 加密存储，基于角色的权限控制
- **可观测性**：完整的使用日志和成本统计
- **高性能**：数据库连接池、缓存优化、批量写入
- **开发友好**：完整的 Pydantic 模式、OpenAPI 文档

### 11.3 后续演进

1. **智能路由**：基于成本、延迟、可用性的智能模型选择
2. **预算控制**：为用户/Agent 设置 API 调用预算
3. **A/B 测试**：支持同一 Agent 使用不同模型对比效果
4. **模型微调**：集成模型微调和部署流程
5. **多模态支持**：支持图像、音频等多模态模型

### 11.4 部署建议

**最小生产环境：**
- 1 个 OpenAI 提供商（GPT-3.5 Turbo）
- PostgreSQL 数据库
- FastAPI 服务（2 副本）

**完整生产环境：**
- 多个提供商（OpenAI + Anthropic + Ollama）
- PostgreSQL 主从架构
- FastAPI 服务（多副本 + 负载均衡）
- Redis 缓存
- 日志聚合（ELK/Grafana）
- 监控告警（Prometheus + AlertManager）

---

**文档版本：** V2.0
**最后更新：** 2025-12-03
**作者：** Alice Home Team
**状态：** Ready for Implementation
