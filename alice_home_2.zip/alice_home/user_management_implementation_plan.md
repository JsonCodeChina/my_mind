# Alice Home - 用户管理模块开发方案

## 1. 项目概述

### 1.1 模块定位
用户管理模块是Alice Home的基础核心模块，负责用户身份认证、权限管理、组织架构等功能，采用开源+企业版双模式运营。

### 1.2 技术栈
- **后端框架**：Django 4.2+
- **数据库**：PostgreSQL 14+
- **API框架**：Django REST Framework 3.14+
- **认证**：Django内置Auth + JWT
- **权限**：Django Permissions + django-guardian（企业版）
- **异步任务**：Celery + Redis
- **测试**：pytest + pytest-django

### 1.3 功能划分

#### 开源版（免费）
- ✅ 用户认证（本地用户名密码登录）
- ✅ 角色管理（预置角色：Admin/User/Viewer）
- ✅ 权限控制（基于RBAC的粗粒度权限）
- ✅ 用户导入（单个用户手动创建）
- ✅ 用户画像（基本信息管理）
- ✅ 配置管理（基础系统配置）

#### 企业版（付费）
- 💰 企业认证集成（SSO/LDAP/SAML - 后期）
- 💰 组织架构（部门树形结构）
- 💰 权限控制（RBAC + 对象级权限）
- 💰 批量导入（CSV/Excel批量导入用户）
- 💰 多租户隔离（租户级数据隔离 - 可选）
- 💰 配置管理（高级配置、审计日志）
- 💰 模块设置（企业级安全策略、2FA）

---

## 2. 数据库设计

### 2.1 核心表结构

#### User表（继承Django AbstractUser）
```python
from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    """扩展用户模型"""

    # 基础字段（开源版）
    phone = models.CharField('手机号', max_length=20, blank=True, db_index=True)
    avatar = models.CharField('头像URL', max_length=500, blank=True)
    nickname = models.CharField('昵称', max_length=50, blank=True)
    is_enabled = models.BooleanField('启用状态', default=True)

    # 企业版字段
    department = models.ForeignKey(
        'Department',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='所属部门'
    )
    employee_id = models.CharField('工号', max_length=50, blank=True, db_index=True)
    position = models.CharField('职位', max_length=100, blank=True)

    # 审计字段
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)
    last_login_ip = models.GenericIPAddressField('最后登录IP', null=True, blank=True)

    class Meta:
        db_table = 'auth_user'
        verbose_name = '用户'
        verbose_name_plural = '用户列表'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.username} ({self.nickname or self.email})"
```

#### Role表（扩展Django Group）
```python
from django.contrib.auth.models import Group

class Role(Group):
    """角色模型（扩展Django Group）"""

    description = models.TextField('角色描述', blank=True)
    is_system = models.BooleanField('系统预置角色', default=False)
    priority = models.IntegerField('优先级', default=0)

    # 企业版字段
    is_enterprise = models.BooleanField('企业版角色', default=False)

    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 'auth_role'
        verbose_name = '角色'
        verbose_name_plural = '角色列表'
```

#### Department表（企业版）
```python
from mptt.models import MPTTModel, TreeForeignKey

class Department(MPTTModel):
    """部门模型（树形结构）"""

    name = models.CharField('部门名称', max_length=100)
    code = models.CharField('部门编码', max_length=50, unique=True)
    parent = TreeForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='children',
        verbose_name='上级部门'
    )

    manager = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='managed_departments',
        verbose_name='部门负责人'
    )

    description = models.TextField('部门描述', blank=True)
    is_active = models.BooleanField('启用状态', default=True)

    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class MPTTMeta:
        order_insertion_by = ['name']

    class Meta:
        db_table = 'department'
        verbose_name = '部门'
        verbose_name_plural = '部门列表'

    def __str__(self):
        return self.name
```

#### AuditLog表（企业版）
```python
class AuditLog(models.Model):
    """审计日志"""

    ACTION_CHOICES = [
        ('CREATE', '创建'),
        ('UPDATE', '更新'),
        ('DELETE', '删除'),
        ('LOGIN', '登录'),
        ('LOGOUT', '登出'),
    ]

    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, verbose_name='操作用户')
    action = models.CharField('操作类型', max_length=20, choices=ACTION_CHOICES)
    resource_type = models.CharField('资源类型', max_length=50)
    resource_id = models.IntegerField('资源ID', null=True)
    resource_name = models.CharField('资源名称', max_length=200, blank=True)

    ip_address = models.GenericIPAddressField('IP地址', null=True)
    user_agent = models.CharField('用户代理', max_length=500, blank=True)

    changes = models.JSONField('变更内容', null=True, blank=True)
    result = models.CharField('操作结果', max_length=20, default='SUCCESS')

    created_at = models.DateTimeField('操作时间', auto_now_add=True, db_index=True)

    class Meta:
        db_table = 'audit_log'
        verbose_name = '审计日志'
        verbose_name_plural = '审计日志列表'
        ordering = ['-created_at']
```

#### SystemConfig表（配置管理）
```python
class SystemConfig(models.Model):
    """系统配置"""

    key = models.CharField('配置键', max_length=100, unique=True)
    value = models.JSONField('配置值')
    description = models.TextField('配置描述', blank=True)

    is_enterprise = models.BooleanField('企业版配置', default=False)
    is_secret = models.BooleanField('敏感配置', default=False)

    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 'system_config'
        verbose_name = '系统配置'
        verbose_name_plural = '系统配置列表'
```

### 2.2 数据库索引优化

```sql
-- 用户表索引
CREATE INDEX idx_user_phone ON auth_user(phone);
CREATE INDEX idx_user_employee_id ON auth_user(employee_id);
CREATE INDEX idx_user_department_id ON auth_user(department_id);
CREATE INDEX idx_user_is_enabled ON auth_user(is_enabled);

-- 审计日志索引
CREATE INDEX idx_audit_user_id ON audit_log(user_id);
CREATE INDEX idx_audit_created_at ON audit_log(created_at);
CREATE INDEX idx_audit_resource ON audit_log(resource_type, resource_id);
```

---

## 3. API接口设计

### 3.1 RESTful API规范

基础URL: `/api/v1/users/`

#### 用户管理API

| 方法 | 路径 | 说明 | 权限 | 版本 |
|------|------|------|------|------|
| POST | `/auth/login/` | 用户登录 | 匿名 | 开源 |
| POST | `/auth/logout/` | 用户登出 | 已认证 | 开源 |
| POST | `/auth/register/` | 用户注册 | 匿名 | 开源 |
| POST | `/auth/refresh/` | 刷新Token | 已认证 | 开源 |
| GET | `/users/` | 用户列表 | Admin | 开源 |
| POST | `/users/` | 创建用户 | Admin | 开源 |
| GET | `/users/{id}/` | 用户详情 | Admin/Self | 开源 |
| PUT | `/users/{id}/` | 更新用户 | Admin/Self | 开源 |
| DELETE | `/users/{id}/` | 删除用户 | Admin | 开源 |
| POST | `/users/bulk-import/` | 批量导入 | Admin | 企业 |
| GET | `/users/me/` | 当前用户信息 | 已认证 | 开源 |
| PUT | `/users/me/` | 更新个人信息 | 已认证 | 开源 |

#### 角色管理API

| 方法 | 路径 | 说明 | 权限 | 版本 |
|------|------|------|------|------|
| GET | `/roles/` | 角色列表 | Admin | 开源 |
| POST | `/roles/` | 创建角色 | Admin | 企业 |
| GET | `/roles/{id}/` | 角色详情 | Admin | 开源 |
| PUT | `/roles/{id}/` | 更新角色 | Admin | 企业 |
| DELETE | `/roles/{id}/` | 删除角色 | Admin | 企业 |
| GET | `/roles/{id}/permissions/` | 角色权限 | Admin | 开源 |
| PUT | `/roles/{id}/permissions/` | 设置权限 | Admin | 企业 |

#### 部门管理API（企业版）

| 方法 | 路径 | 说明 | 权限 | 版本 |
|------|------|------|------|------|
| GET | `/departments/` | 部门列表 | Admin | 企业 |
| GET | `/departments/tree/` | 部门树 | Admin | 企业 |
| POST | `/departments/` | 创建部门 | Admin | 企业 |
| GET | `/departments/{id}/` | 部门详情 | Admin | 企业 |
| PUT | `/departments/{id}/` | 更新部门 | Admin | 企业 |
| DELETE | `/departments/{id}/` | 删除部门 | Admin | 企业 |

### 3.2 API请求/响应示例

#### 登录
```http
POST /api/v1/auth/login/
Content-Type: application/json

{
  "username": "admin",
  "password": "password123"
}

# 响应
{
  "code": 0,
  "message": "success",
  "data": {
    "access_token": "eyJhbGci...",
    "refresh_token": "eyJhbGci...",
    "user": {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "roles": ["admin"]
    }
  }
}
```

#### 用户列表
```http
GET /api/v1/users/?page=1&page_size=20&department=1&search=张三
Authorization: Bearer eyJhbGci...

# 响应
{
  "code": 0,
  "message": "success",
  "data": {
    "count": 100,
    "next": "http://...",
    "previous": null,
    "results": [
      {
        "id": 1,
        "username": "zhangsan",
        "email": "zhangsan@example.com",
        "nickname": "张三",
        "phone": "13800138000",
        "department": {
          "id": 1,
          "name": "技术部"
        },
        "roles": ["user"],
        "is_enabled": true,
        "created_at": "2024-01-01T00:00:00Z"
      }
    ]
  }
}
```

#### 批量导入（企业版）
```http
POST /api/v1/users/bulk-import/
Content-Type: multipart/form-data
Authorization: Bearer eyJhbGci...

file: users.csv

# 响应
{
  "code": 0,
  "message": "success",
  "data": {
    "task_id": "abc123",
    "total": 100,
    "success": 95,
    "failed": 5,
    "errors": [
      {
        "row": 10,
        "error": "用户名已存在"
      }
    ]
  }
}
```

---

## 4. 核心功能实现

### 4.1 用户认证

#### JWT Token认证
```python
# apps/users/authentication.py
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken

class CustomJWTAuthentication(JWTAuthentication):
    """自定义JWT认证"""

    def authenticate(self, request):
        header = self.get_header(request)
        if header is None:
            return None

        raw_token = self.get_raw_token(header)
        if raw_token is None:
            return None

        validated_token = self.get_validated_token(raw_token)
        user = self.get_user(validated_token)

        # 检查用户是否启用
        if not user.is_enabled:
            raise AuthenticationFailed('用户已被禁用')

        return user, validated_token

def get_tokens_for_user(user):
    """生成Token"""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }
```

#### 登录视图
```python
# apps/users/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth import authenticate

class LoginView(APIView):
    """用户登录"""
    permission_classes = []

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(username=username, password=password)
        if user is None:
            return Response({
                'code': 400,
                'message': '用户名或密码错误'
            }, status=400)

        if not user.is_enabled:
            return Response({
                'code': 403,
                'message': '用户已被禁用'
            }, status=403)

        # 生成Token
        tokens = get_tokens_for_user(user)

        # 记录登录日志
        AuditLog.objects.create(
            user=user,
            action='LOGIN',
            resource_type='User',
            resource_id=user.id,
            ip_address=get_client_ip(request),
            user_agent=request.META.get('HTTP_USER_AGENT', '')
        )

        return Response({
            'code': 0,
            'message': 'success',
            'data': {
                'access_token': tokens['access'],
                'refresh_token': tokens['refresh'],
                'user': UserSerializer(user).data
            }
        })
```

### 4.2 权限控制

#### 基于RBAC的权限检查
```python
# apps/users/permissions.py
from rest_framework import permissions

class IsAdminUser(permissions.BasePermission):
    """仅管理员可访问"""

    def has_permission(self, request, view):
        return request.user and request.user.is_staff

class IsSelfOrAdmin(permissions.BasePermission):
    """本人或管理员可访问"""

    def has_object_permission(self, request, view, obj):
        return obj == request.user or request.user.is_staff

class HasPermission(permissions.BasePermission):
    """检查指定权限"""

    def __init__(self, permission_name):
        self.permission_name = permission_name

    def has_permission(self, request, view):
        return request.user.has_perm(self.permission_name)
```

#### 企业版：对象级权限（django-guardian）
```python
# apps/users/permissions.py (企业版)
from guardian.shortcuts import assign_perm, get_objects_for_user

class ObjectPermissionMixin:
    """对象级权限Mixin（企业版）"""

    def get_queryset(self):
        queryset = super().get_queryset()

        if settings.ALICE_HOME_EDITION == 'enterprise':
            # 只返回用户有权限的对象
            return get_objects_for_user(
                self.request.user,
                f'{self.model._meta.app_label}.view_{self.model._meta.model_name}',
                queryset
            )

        return queryset
```

### 4.3 组织架构（企业版）

#### 部门树视图
```python
# apps/users/views.py
from rest_framework.decorators import action

class DepartmentViewSet(viewsets.ModelViewSet):
    """部门管理（企业版）"""
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [IsAdminUser]

    @action(detail=False, methods=['get'])
    def tree(self, request):
        """获取部门树"""
        root_departments = Department.objects.root_nodes()
        serializer = DepartmentTreeSerializer(root_departments, many=True)
        return Response({
            'code': 0,
            'data': serializer.data
        })
```

#### 序列化器
```python
# apps/users/serializers.py
from rest_framework import serializers

class DepartmentTreeSerializer(serializers.ModelSerializer):
    """部门树序列化器"""
    children = serializers.SerializerMethodField()
    user_count = serializers.IntegerField(source='user_set.count', read_only=True)

    class Meta:
        model = Department
        fields = ['id', 'name', 'code', 'manager', 'user_count', 'children']

    def get_children(self, obj):
        children = obj.get_children()
        return DepartmentTreeSerializer(children, many=True).data
```

### 4.4 批量导入（企业版）

#### Celery异步任务
```python
# apps/users/tasks.py
from celery import shared_task
import pandas as pd

@shared_task
def bulk_import_users(file_path, created_by_id):
    """批量导入用户"""

    # 读取CSV
    df = pd.read_csv(file_path)

    results = {
        'total': len(df),
        'success': 0,
        'failed': 0,
        'errors': []
    }

    for index, row in df.iterrows():
        try:
            user = User.objects.create_user(
                username=row['username'],
                email=row['email'],
                password=row.get('password', 'default123'),
                phone=row.get('phone', ''),
                department_id=row.get('department_id')
            )
            results['success'] += 1
        except Exception as e:
            results['failed'] += 1
            results['errors'].append({
                'row': index + 2,
                'error': str(e)
            })

    return results
```

#### 视图
```python
# apps/users/views.py
class UserViewSet(viewsets.ModelViewSet):

    @action(detail=False, methods=['post'])
    def bulk_import(self, request):
        """批量导入用户（企业版）"""
        if settings.ALICE_HOME_EDITION != 'enterprise':
            return Response({
                'code': 403,
                'message': '此功能仅企业版可用'
            }, status=403)

        file = request.FILES['file']

        # 保存文件
        file_path = default_storage.save(f'imports/{file.name}', file)

        # 异步执行导入
        task = bulk_import_users.delay(file_path, request.user.id)

        return Response({
            'code': 0,
            'message': '导入任务已提交',
            'data': {
                'task_id': task.id
            }
        })
```

### 4.5 审计日志（企业版）

#### Django信号自动记录
```python
# apps/audit/signals.py
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

@receiver(post_save, sender=User)
def log_user_change(sender, instance, created, **kwargs):
    """记录用户变更"""
    if settings.ALICE_HOME_EDITION != 'enterprise':
        return

    action = 'CREATE' if created else 'UPDATE'

    AuditLog.objects.create(
        user=get_current_user(),  # 从中间件获取当前用户
        action=action,
        resource_type='User',
        resource_id=instance.id,
        resource_name=instance.username,
        ip_address=get_current_ip(),
        changes=get_model_changes(instance) if not created else None
    )
```

---

## 5. 开发计划

### 5.1 阶段1：MVP开源版（1周）

**Day 1-2: 基础架构**
- ✅ 创建Django项目结构
- ✅ 配置数据库（PostgreSQL）
- ✅ 设计User模型（继承AbstractUser）
- ✅ 配置Django REST Framework
- ✅ 配置JWT认证

**Day 3-4: 用户认证**
- ✅ 实现登录/登出API
- ✅ 实现用户注册API
- ✅ 实现Token刷新API
- ✅ 编写认证中间件
- ✅ 单元测试

**Day 5-6: 用户管理**
- ✅ 实现用户CRUD API
- ✅ 实现用户列表/搜索/分页
- ✅ 实现个人信息管理
- ✅ 单元测试

**Day 7: 权限控制**
- ✅ 配置预置角色（Admin/User）
- ✅ 实现权限检查装饰器
- ✅ 编写权限测试用例
- ✅ 集成测试

### 5.2 阶段2：企业版1.0（1.5周）

**Day 8-10: 组织架构**
- 安装django-mptt
- 实现Department模型
- 实现部门树API
- 实现部门管理界面

**Day 11-12: 批量导入**
- 配置Celery
- 实现CSV解析
- 实现异步导入任务
- 实现任务状态查询

**Day 13-14: 审计日志**
- 实现AuditLog模型
- 配置Django信号
- 实现日志查询API
- 实现日志导出功能

**Day 15: 配置管理**
- 实现SystemConfig模型
- 实现配置CRUD API
- 实现版本区分逻辑

### 5.3 阶段3：企业版2.0（2周）

**Day 16-19: 对象级权限**
- 集成django-guardian
- 实现对象权限分配
- 修改API添加权限检查
- 编写权限测试

**Day 20-22: 自定义角色**
- 扩展Role模型
- 实现角色CRUD API
- 实现权限分配界面
- 测试

**Day 23-25: 2FA/MFA**
- 集成django-otp
- 实现TOTP生成
- 实现二次验证API
- 测试

**Day 26-27: 安全策略**
- 实现密码策略验证器
- 实现IP白名单中间件
- 实现登录失败锁定
- 测试

---

## 6. 测试策略

### 6.1 单元测试

```python
# tests/test_user_api.py
import pytest
from django.urls import reverse
from rest_framework.test import APIClient

@pytest.mark.django_db
class TestUserAPI:

    def test_login_success(self):
        """测试登录成功"""
        client = APIClient()
        user = User.objects.create_user(
            username='testuser',
            password='testpass123'
        )

        response = client.post(reverse('login'), {
            'username': 'testuser',
            'password': 'testpass123'
        })

        assert response.status_code == 200
        assert 'access_token' in response.data['data']

    def test_create_user_requires_admin(self):
        """测试创建用户需要管理员权限"""
        client = APIClient()
        user = User.objects.create_user(username='user', password='pass')
        client.force_authenticate(user=user)

        response = client.post(reverse('user-list'), {
            'username': 'newuser',
            'email': 'new@example.com'
        })

        assert response.status_code == 403
```

### 6.2 性能测试

- 用户列表查询：<100ms（1000用户）
- 权限检查：<10ms
- 部门树查询：<50ms（100个部门）

---

## 7. 部署方案

### 7.1 Docker部署

```yaml
# docker-compose.yml
version: '3.8'

services:
  db:
    image: postgres:14
    environment:
      POSTGRES_DB: alice_home
      POSTGRES_USER: alice
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

  web:
    build: .
    command: gunicorn alice_home.wsgi:application --bind 0.0.0.0:8000
    environment:
      - ALICE_HOME_EDITION=opensource  # 或 enterprise
      - DATABASE_URL=postgresql://alice:password@db:5432/alice_home
      - REDIS_URL=redis://redis:6379/0
    ports:
      - "8000:8000"
    depends_on:
      - db
      - redis

  celery:
    build: .
    command: celery -A alice_home worker -l info
    environment:
      - ALICE_HOME_EDITION=enterprise
      - DATABASE_URL=postgresql://alice:password@db:5432/alice_home
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - db
      - redis

volumes:
  postgres_data:
```

### 7.2 环境变量

```bash
# .env.opensource
ALICE_HOME_EDITION=opensource
DATABASE_URL=postgresql://user:pass@localhost:5432/alice_home
SECRET_KEY=your-secret-key
DEBUG=False

# .env.enterprise
ALICE_HOME_EDITION=enterprise
DATABASE_URL=postgresql://user:pass@localhost:5432/alice_home
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key
DEBUG=False
```

---

## 8. 交付物

### 8.1 代码交付
- ✅ Django应用代码
- ✅ 数据库迁移文件
- ✅ 单元测试代码
- ✅ API文档（Swagger/OpenAPI）
- ✅ README部署文档

### 8.2 文档交付
- ✅ 用户管理模块开发方案（本文档）
- ✅ API接口文档
- ✅ 数据库设计文档
- ✅ 部署运维文档
- ✅ 用户使用手册

---

## 9. 风险与对策

| 风险 | 影响 | 对策 |
|------|------|------|
| 性能问题（用户量大） | 高 | 添加Redis缓存、数据库索引优化 |
| 安全漏洞 | 高 | 代码审计、依赖扫描、渗透测试 |
| 企业版功能泄漏 | 中 | 代码混淆、License验证 |
| 第三方依赖风险 | 中 | 锁定版本、定期更新 |

---

## 10. 总结

本方案采用渐进式开发策略，从MVP开源版开始，逐步演进到企业版，确保：
1. **快速上线**：1周完成MVP
2. **可扩展性**：分层架构便于扩展
3. **商业化**：清晰的开源/企业功能划分
4. **可维护性**：遵循Django最佳实践
