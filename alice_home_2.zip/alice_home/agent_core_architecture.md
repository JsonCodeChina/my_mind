# Alice Home Agent 核心架构方案

## 1. 系统概述

### 1.1 设计理念

基于 **A2A (Agent-to-Agent) 协议**构建 Alice Home 的 Agent 生态系统，实现"**开箱即用·伴随成长**"的核心理念：

- **开箱即用**：提供最小可运行的 Alice Chat Agent（内置免费）
- **伴随成长**：用户可通过 Agent SDK 开发自定义 Agent，并在 Agent 市场无缝替换更优质的 Agent

### 1.2 核心组件

```
┌─────────────────────────────────────────────────────────────┐
│                     Alice Home 平台                          │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ Alice Chat   │  │  Agent SDK   │  │ Agent 市场   │      │
│  │  (内置Agent) │  │  (基于A2A)   │  │ (注册发现)   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         │                  │                  │             │
│         └──────────────────┴──────────────────┘             │
│                            │                                │
│                 ┌──────────▼──────────┐                     │
│                 │  A2A 协议层         │                     │
│                 │  - Task Management  │                     │
│                 │  - Message Routing  │                     │
│                 │  - Agent Discovery  │                     │
│                 └─────────────────────┘                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Alice Home Agent SDK 设计

### 2.1 SDK 架构（基于 A2A 协议）

#### 核心设计原则

1. **完全兼容 A2A 协议标准**：遵循 Linux Foundation 的 A2A 规范
2. **三层架构**：数据层 → 能力层 → 协议层
3. **多传输协议支持**：优先支持 JSON-RPC 2.0，可扩展 gRPC/REST
4. **企业级安全**：OAuth 2.0, JWT, API Key 多种认证方式

#### SDK 分层架构

```python
alice_home_agent_sdk/
├── core/                          # 核心层
│   ├── agent.py                   # AgentExecutor 基类
│   ├── task.py                    # Task 生命周期管理
│   ├── message.py                 # Message 处理（text/file/data parts）
│   ├── context.py                 # Context 和多轮对话管理
│   └── memory.py                  # 记忆管理接口
│
├── protocols/                     # 协议层
│   ├── jsonrpc/                   # JSON-RPC 2.0 实现
│   │   ├── server.py              # JSON-RPC 服务器
│   │   ├── client.py              # JSON-RPC 客户端
│   │   └── handlers.py            # 请求处理器
│   ├── grpc/                      # gRPC 实现（可选）
│   └── rest/                      # REST API 实现（可选）
│
├── discovery/                     # 服务发现
│   ├── agent_card.py              # Agent Card 生成和解析
│   ├── registry.py                # 注册中心客户端
│   └── well_known.py              # .well-known URI 处理
│
├── streaming/                     # 流式处理
│   ├── sse.py                     # Server-Sent Events
│   ├── events.py                  # TaskStatusUpdate/TaskArtifactUpdate
│   └── chunked.py                 # 大文件分块处理
│
├── security/                      # 安全模块
│   ├── auth.py                    # 认证中间件
│   ├── oauth.py                   # OAuth 2.0 实现
│   └── jwt.py                     # JWT Token 处理
│
├── integrations/                  # 集成模块
│   ├── llm/                       # LLM 集成
│   │   ├── openai.py
│   │   ├── anthropic.py
│   │   └── base.py
│   ├── memory/                    # 记忆存储集成
│   │   ├── mongodb.py             # 短期记忆
│   │   ├── postgres.py            # 长期记忆
│   │   └── redis.py               # 缓存
│   └── rag/                       # RAG 集成
│       └── vector_store.py
│
└── utils/                         # 工具模块
    ├── logger.py                  # 日志
    ├── metrics.py                 # 指标收集
    └── testing.py                 # 测试工具
```

### 2.2 核心接口定义

#### AgentExecutor 基类

```python
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, AsyncIterator
from alice_home_agent_sdk.core.message import Message
from alice_home_agent_sdk.core.task import Task, TaskState

class AgentExecutor(ABC):
    """
    Alice Home Agent 执行器基类
    所有自定义 Agent 必须继承此类
    """

    def __init__(self, agent_card: Dict):
        """
        初始化 Agent

        Args:
            agent_card: Agent Card 配置
        """
        self.agent_card = agent_card
        self.task_manager = TaskManager()

    @abstractmethod
    async def execute(
        self,
        message: Message,
        context_id: Optional[str] = None,
        task_id: Optional[str] = None
    ) -> Task:
        """
        执行 Agent 任务（核心方法）

        Args:
            message: 用户输入消息
            context_id: 会话上下文 ID（多轮对话）
            task_id: 任务 ID（继续之前的任务）

        Returns:
            Task: 任务对象，包含状态和响应消息
        """
        pass

    @abstractmethod
    async def cancel(self, task_id: str) -> bool:
        """
        取消任务

        Args:
            task_id: 要取消的任务 ID

        Returns:
            bool: 是否成功取消
        """
        pass

    async def stream_execute(
        self,
        message: Message,
        context_id: Optional[str] = None
    ) -> AsyncIterator[TaskStatusUpdateEvent]:
        """
        流式执行（可选实现）

        Yields:
            TaskStatusUpdateEvent: 任务状态更新事件
        """
        raise NotImplementedError("Streaming not supported")

    def get_agent_card(self) -> Dict:
        """
        获取 Agent Card

        Returns:
            Dict: Agent Card JSON
        """
        return self.agent_card
```

#### Task 生命周期管理

```python
from enum import Enum
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, List

class TaskState(Enum):
    """A2A 协议定义的任务状态"""
    # 非终止状态
    SUBMITTED = "submitted"
    WORKING = "working"

    # 中断状态
    INPUT_REQUIRED = "input-required"
    AUTH_REQUIRED = "auth-required"

    # 终止状态
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"
    REJECTED = "rejected"
    UNKNOWN = "unknown"

@dataclass
class Task:
    """任务对象"""
    task_id: str
    state: TaskState
    message: Optional[Message] = None
    error: Optional[Dict] = None
    context_id: Optional[str] = None
    created_at: datetime = datetime.utcnow()
    updated_at: datetime = datetime.utcnow()
    metadata: Dict = None

    def is_terminal(self) -> bool:
        """判断是否为终止状态"""
        return self.state in [
            TaskState.COMPLETED,
            TaskState.FAILED,
            TaskState.CANCELED,
            TaskState.REJECTED,
            TaskState.UNKNOWN
        ]

    def transition_to(self, new_state: TaskState) -> bool:
        """
        状态转换（带验证）

        Args:
            new_state: 新状态

        Returns:
            bool: 是否允许转换
        """
        # 终止状态不能再转换
        if self.is_terminal():
            return False

        self.state = new_state
        self.updated_at = datetime.utcnow()
        return True
```

#### Message 结构

```python
from dataclasses import dataclass
from typing import List, Union, Optional

@dataclass
class TextPart:
    """文本消息部分"""
    text: str

@dataclass
class FilePart:
    """文件消息部分"""
    name: str
    mime_type: str
    data: Optional[str] = None  # Base64 编码
    uri: Optional[str] = None   # 文件 URI

@dataclass
class DataPart:
    """结构化数据部分"""
    data: Dict

MessagePart = Union[TextPart, FilePart, DataPart]

@dataclass
class Message:
    """消息对象"""
    role: str  # "user" or "agent"
    parts: List[MessagePart]
    message_id: Optional[str] = None
    timestamp: datetime = datetime.utcnow()
```

#### Agent Card 定义

```python
def generate_agent_card(
    name: str,
    description: str,
    url: str,
    version: str,
    capabilities: Dict,
    skills: List[Dict],
    security_schemes: Dict
) -> Dict:
    """
    生成 Agent Card

    Args:
        name: Agent 名称
        description: Agent 描述
        url: Agent 服务地址
        version: Agent 版本
        capabilities: 能力声明（streaming, pushNotifications）
        skills: 技能列表
        security_schemes: 安全认证方式

    Returns:
        Dict: Agent Card JSON
    """
    return {
        "name": name,
        "description": description,
        "url": url,
        "version": version,
        "protocolVersion": "v1",
        "capabilities": capabilities,
        "preferredTransport": "jsonrpc",
        "skills": skills,
        "security_schemes": security_schemes
    }
```

### 2.3 对话和记忆协议

#### 对话管理接口

```python
class ConversationManager:
    """对话管理器"""

    async def create_context(self, user_id: str, metadata: Dict = None) -> str:
        """
        创建新的对话上下文

        Args:
            user_id: 用户 ID
            metadata: 元数据

        Returns:
            str: context_id
        """
        pass

    async def add_message(
        self,
        context_id: str,
        message: Message
    ) -> bool:
        """
        添加消息到上下文

        Args:
            context_id: 上下文 ID
            message: 消息对象

        Returns:
            bool: 是否成功
        """
        pass

    async def get_history(
        self,
        context_id: str,
        limit: int = 10
    ) -> List[Message]:
        """
        获取对话历史

        Args:
            context_id: 上下文 ID
            limit: 返回消息数量

        Returns:
            List[Message]: 消息列表
        """
        pass
```

#### 记忆管理接口

```python
from enum import Enum

class MemoryType(Enum):
    """记忆类型"""
    SHORT_TERM = "short_term"   # 短期记忆（当前会话）
    LONG_TERM = "long_term"     # 长期记忆（跨会话）
    KNOWLEDGE = "knowledge"      # 知识图谱（企业版）

class MemoryManager:
    """记忆管理器"""

    async def store(
        self,
        user_id: str,
        memory_type: MemoryType,
        key: str,
        value: Dict,
        ttl: Optional[int] = None
    ) -> bool:
        """
        存储记忆

        Args:
            user_id: 用户 ID
            memory_type: 记忆类型
            key: 记忆键
            value: 记忆值
            ttl: 过期时间（秒）

        Returns:
            bool: 是否成功
        """
        pass

    async def retrieve(
        self,
        user_id: str,
        memory_type: MemoryType,
        key: str
    ) -> Optional[Dict]:
        """
        检索记忆

        Args:
            user_id: 用户 ID
            memory_type: 记忆类型
            key: 记忆键

        Returns:
            Optional[Dict]: 记忆值
        """
        pass

    async def search(
        self,
        user_id: str,
        memory_type: MemoryType,
        query: str,
        limit: int = 10
    ) -> List[Dict]:
        """
        搜索记忆（向量检索）

        Args:
            user_id: 用户 ID
            memory_type: 记忆类型
            query: 查询文本
            limit: 返回数量

        Returns:
            List[Dict]: 匹配的记忆列表
        """
        pass
```

---

## 3. 最小可运行 Alice Chat Agent

### 3.1 功能定义

**核心能力**：
1. **对话管理**：支持多轮对话，维护上下文
2. **模型选择**：支持多个 LLM 提供商（OpenAI, Anthropic, 本地模型等）
3. **基础记忆**：短期记忆（MongoDB 存储对话历史）
4. **A2A 协议**：完全基于 SDK 实现，符合 A2A 标准

**开源版功能**：
- 单用户对话
- LLM 调用（用户自配 API Key）
- 会话历史（最近 10 条）
- 基础 Prompt 模板

**企业版功能**（可选升级）：
- 多用户隔离
- 长期记忆和知识图谱
- 高级 Prompt 优化
- 流式响应
- Agent 市场集成

### 3.2 实现示例

```python
from alice_home_agent_sdk import AgentExecutor, Message, Task, TaskState
from alice_home_agent_sdk.integrations.llm import OpenAIClient
from alice_home_agent_sdk.core.memory import MemoryManager, MemoryType

class AliceChatAgent(AgentExecutor):
    """Alice Chat - 最小可运行 Agent"""

    def __init__(self):
        agent_card = {
            "name": "Alice Chat",
            "description": "Alice Home 内置对话 Agent，开箱即用",
            "url": "http://localhost:8000",
            "version": "1.0.0",
            "protocolVersion": "v1",
            "capabilities": {
                "streaming": False,
                "pushNotifications": False
            },
            "preferredTransport": "jsonrpc",
            "skills": [
                {
                    "name": "conversation",
                    "description": "多轮对话能力"
                },
                {
                    "name": "llm-integration",
                    "description": "支持多种 LLM 模型"
                }
            ],
            "security_schemes": {
                "bearer": {
                    "type": "http",
                    "scheme": "bearer"
                }
            }
        }
        super().__init__(agent_card)

        # 初始化 LLM 客户端
        self.llm_client = OpenAIClient(
            api_key=os.getenv("OPENAI_API_KEY")
        )

        # 初始化记忆管理器
        self.memory = MemoryManager()

    async def execute(
        self,
        message: Message,
        context_id: Optional[str] = None,
        task_id: Optional[str] = None
    ) -> Task:
        """执行对话任务"""

        # 创建新任务
        task = self.task_manager.create_task(
            message=message,
            context_id=context_id
        )

        try:
            # 更新状态为 working
            task.transition_to(TaskState.WORKING)

            # 获取对话历史
            history = []
            if context_id:
                history = await self.memory.retrieve(
                    user_id="default",
                    memory_type=MemoryType.SHORT_TERM,
                    key=f"history:{context_id}"
                ) or []

            # 构建消息列表
            messages = history + [
                {"role": "user", "content": message.parts[0].text}
            ]

            # 调用 LLM
            response = await self.llm_client.chat_completion(
                messages=messages,
                model="gpt-4o-mini"
            )

            # 存储对话历史
            if context_id:
                history.append({"role": "user", "content": message.parts[0].text})
                history.append({"role": "assistant", "content": response})
                await self.memory.store(
                    user_id="default",
                    memory_type=MemoryType.SHORT_TERM,
                    key=f"history:{context_id}",
                    value=history[-20:]  # 保留最近 20 条
                )

            # 构建响应消息
            response_message = Message(
                role="agent",
                parts=[TextPart(text=response)]
            )

            # 更新任务状态为完成
            task.message = response_message
            task.transition_to(TaskState.COMPLETED)

        except Exception as e:
            # 错误处理
            task.error = {
                "code": -32000,
                "message": str(e)
            }
            task.transition_to(TaskState.FAILED)

        return task

    async def cancel(self, task_id: str) -> bool:
        """取消任务"""
        task = self.task_manager.get_task(task_id)
        if task and not task.is_terminal():
            task.transition_to(TaskState.CANCELED)
            return True
        return False
```

### 3.3 启动服务

```python
from alice_home_agent_sdk.protocols.jsonrpc import JSONRPCServer

# 创建 Agent 实例
agent = AliceChatAgent()

# 创建 JSON-RPC 服务器
server = JSONRPCServer(agent)

# 启动服务（默认端口 8000）
if __name__ == "__main__":
    server.run(host="0.0.0.0", port=8000)
```

---

## 4. Agent 注册发现平台

### 4.1 系统架构（参考 Dify Marketplace）

```
┌─────────────────────────────────────────────────────────────┐
│                    Agent 市场（Marketplace）                 │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  Agent 注册  │  │  Agent 发现  │  │  版本管理    │     │
│  │  Registry    │  │  Discovery   │  │  Versioning  │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  权限管理    │  │  审核流程    │  │  统计分析    │     │
│  │  Permission  │  │  Review      │  │  Analytics   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                            │
                ┌───────────┴───────────┐
                │                       │
        ┌───────▼───────┐       ┌──────▼──────┐
        │ Agent 仓库     │       │ 企业私有    │
        │ (GitHub)       │       │ Agent 仓库  │
        └────────────────┘       └─────────────┘
```

### 4.2 Agent 包格式（.alicepkg）

类似 Dify 的 `.difypkg`，定义 Alice Home 的 `.alicepkg` 格式：

#### 目录结构

```
my-agent.alicepkg
├── manifest.yaml          # Agent 元数据
├── agent_card.json        # A2A Agent Card
├── src/                   # Agent 源代码
│   ├── main.py
│   └── requirements.txt
├── config/                # 配置文件
│   └── default.yaml
├── privacy.md             # 隐私政策（必需）
└── README.md              # 使用文档
```

#### manifest.yaml 定义

```yaml
# Agent 基本信息
version: "1.0.0"
type: "agent"
name: "my-custom-agent"
author: "YourName"
label:
  en_US: "My Custom Agent"
  zh_CN: "我的自定义 Agent"

# 创建时间
created_at: "2025-12-03T00:00:00Z"

# 图标
icon: "icon.svg"

# 资源限制
resource:
  memory: 1048576  # 1MB
  cpu: 1000        # 1 CPU 核心

# 权限声明
permission:
  llm:
    enabled: true
    providers: ["openai", "anthropic", "azure"]
  memory:
    enabled: true
    types: ["short_term", "long_term"]
  rag:
    enabled: false
  mcp:
    enabled: false
  storage:
    enabled: true
    size: 10485760  # 10MB

# A2A 协议配置
protocol:
  version: "v1"
  transport: "jsonrpc"
  capabilities:
    streaming: true
    pushNotifications: false

# 运行时配置
runtime:
  language: "python"
  version: "3.11"
  entrypoint: "main.py"
  arch: ["amd64", "arm64"]

# 依赖项
dependencies:
  - "openai>=1.0.0"
  - "anthropic>=0.8.0"

# 分类和标签
category: "conversation"
tags: ["chat", "llm", "general-purpose"]

# 版本兼容性
compatibility:
  alice_home_version: ">=1.0.0"

# 隐私政策
privacy: "./privacy.md"

# 许可证
license: "MIT"

# 仓库链接
repository: "https://github.com/username/my-agent"
```

### 4.3 注册和发现流程

#### 注册流程

```
开发者                  GitHub                Alice Marketplace
  │                      │                          │
  │  1. 开发 Agent        │                          │
  │──────────────────────>│                          │
  │                      │                          │
  │  2. 打包 .alicepkg    │                          │
  │──────────────────────>│                          │
  │                      │                          │
  │  3. 创建 Release       │                          │
  │──────────────────────>│                          │
  │                      │                          │
  │  4. 提交 PR           │                          │
  │──────────────────────────────────────────────────>│
  │                      │                          │
  │                      │  5. 自动审核（CI/CD）    │
  │                      │<──────────────────────────│
  │                      │                          │
  │                      │  6. 人工审核             │
  │                      │<──────────────────────────│
  │                      │                          │
  │  7. 审核通过，自动发布 │                          │
  │<─────────────────────────────────────────────────│
  │                      │                          │
  │  8. Agent 上架市场    │                          │
  │<─────────────────────────────────────────────────│
```

#### 发现机制

**三种发现方式**：

1. **Marketplace 发现**（推荐）
   - 用户在 Alice Home 平台浏览 Agent 市场
   - 分类浏览：对话类、任务类、专业领域类
   - 搜索功能：按名称、标签、作者搜索
   - 排序：热度、评分、下载量、最新

2. **Well-Known URI 发现**
   - Agent 服务暴露 `/.well-known/agent.json`
   - 返回 A2A Agent Card
   - 用户输入 Agent URL 直接添加

3. **GitHub 直接安装**
   - 用户提供 GitHub 仓库链接
   - 自动拉取 Release 中的 `.alicepkg` 文件
   - 本地安装和验证

### 4.4 数据库设计

#### Agent Registry 表

```sql
CREATE TABLE agent_registry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    display_name JSONB NOT NULL,  -- {"en_US": "...", "zh_CN": "..."}
    description TEXT,
    author VARCHAR(255) NOT NULL,
    author_email VARCHAR(255),

    -- 版本信息
    version VARCHAR(50) NOT NULL,
    protocol_version VARCHAR(20) DEFAULT 'v1',

    -- Agent Card
    agent_card JSONB NOT NULL,

    -- 包信息
    package_url TEXT NOT NULL,  -- .alicepkg 下载地址
    repository_url TEXT,

    -- 分类和标签
    category VARCHAR(100),
    tags TEXT[],

    -- 权限和资源
    permissions JSONB,
    resource_limits JSONB,

    -- 状态
    status VARCHAR(50) DEFAULT 'pending',  -- pending, approved, rejected, deprecated
    is_official BOOLEAN DEFAULT FALSE,
    is_enterprise BOOLEAN DEFAULT FALSE,

    -- 统计信息
    download_count INTEGER DEFAULT 0,
    rating_score DECIMAL(3, 2) DEFAULT 0.0,
    rating_count INTEGER DEFAULT 0,

    -- 审核信息
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP,
    review_notes TEXT,

    -- 时间戳
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    published_at TIMESTAMP,

    -- 索引
    CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'rejected', 'deprecated'))
);

CREATE INDEX idx_agent_name ON agent_registry(name);
CREATE INDEX idx_agent_category ON agent_registry(category);
CREATE INDEX idx_agent_status ON agent_registry(status);
CREATE INDEX idx_agent_author ON agent_registry(author);
CREATE INDEX idx_agent_tags ON agent_registry USING GIN(tags);
```

#### Agent Versions 表（版本管理）

```sql
CREATE TABLE agent_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agent_registry(id) ON DELETE CASCADE,
    version VARCHAR(50) NOT NULL,
    package_url TEXT NOT NULL,
    changelog TEXT,
    is_latest BOOLEAN DEFAULT FALSE,
    compatibility JSONB,  -- {"alice_home_version": ">=1.0.0"}
    created_at TIMESTAMP DEFAULT NOW(),

    UNIQUE(agent_id, version)
);

CREATE INDEX idx_version_agent ON agent_versions(agent_id);
CREATE INDEX idx_version_latest ON agent_versions(is_latest) WHERE is_latest = TRUE;
```

#### User Agent Installations 表（用户安装记录）

```sql
CREATE TABLE user_agent_installations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL REFERENCES agent_registry(id) ON DELETE CASCADE,
    version VARCHAR(50) NOT NULL,

    -- 配置
    config JSONB,  -- 用户自定义配置
    is_enabled BOOLEAN DEFAULT TRUE,

    -- 统计
    usage_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP,

    -- 时间戳
    installed_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),

    UNIQUE(user_id, agent_id)
);

CREATE INDEX idx_installation_user ON user_agent_installations(user_id);
CREATE INDEX idx_installation_agent ON user_agent_installations(agent_id);
```

### 4.5 API 设计

#### RESTful API

```
# Agent 发现
GET    /api/v1/agents                     # 列出所有 Agent
GET    /api/v1/agents/:id                 # 获取 Agent 详情
GET    /api/v1/agents/:id/card            # 获取 Agent Card
GET    /api/v1/agents/search?q=keyword    # 搜索 Agent
GET    /api/v1/agents/categories          # 获取分类列表

# Agent 安装
POST   /api/v1/agents/:id/install         # 安装 Agent
DELETE /api/v1/agents/:id/uninstall       # 卸载 Agent
PUT    /api/v1/agents/:id/config          # 更新配置
GET    /api/v1/agents/installed           # 获取已安装列表

# Agent 注册（开发者）
POST   /api/v1/agents/register            # 注册新 Agent
PUT    /api/v1/agents/:id                 # 更新 Agent
POST   /api/v1/agents/:id/versions        # 发布新版本
DELETE /api/v1/agents/:id                 # 下架 Agent

# 审核流程（管理员）
GET    /api/v1/admin/agents/pending       # 待审核列表
POST   /api/v1/admin/agents/:id/approve   # 批准
POST   /api/v1/admin/agents/:id/reject    # 拒绝

# 统计和评价
POST   /api/v1/agents/:id/rate            # 评分
GET    /api/v1/agents/:id/stats           # 获取统计信息
POST   /api/v1/agents/:id/report          # 举报问题
```

---

## 5. Agent 无缝替换机制

### 5.1 替换原理

**核心思想**：所有 Agent 都遵循相同的 A2A 协议接口，因此可以无缝替换。

```
用户对话
   │
   ▼
┌──────────────────────┐
│  Alice Home 编排引擎  │
│  (Orchestrator)      │
└──────────────────────┘
   │
   ▼
┌──────────────────────┐
│   当前激活的 Agent    │  <───  用户可以一键切换
│                      │
│  选项：              │
│  ○ Alice Chat (内置)  │
│  ● CustomAgent       │
│  ○ EnterpriseAgent   │
└──────────────────────┘
```

### 5.2 替换流程

#### 用户界面流程

```
用户                     Alice Home 平台              Agent Registry
 │                            │                            │
 │  1. 浏览 Agent 市场         │                            │
 │───────────────────────────>│                            │
 │                            │  2. 查询可用 Agent          │
 │                            │───────────────────────────>│
 │                            │<───────────────────────────│
 │  3. 选择目标 Agent          │                            │
 │───────────────────────────>│                            │
 │                            │  4. 下载 .alicepkg         │
 │                            │───────────────────────────>│
 │                            │<───────────────────────────│
 │  5. 安装和配置              │                            │
 │<───────────────────────────│                            │
 │                            │                            │
 │  6. 切换到新 Agent          │                            │
 │───────────────────────────>│                            │
 │                            │  7. 验证 Agent Card         │
 │                            │───────────────────────────>│
 │                            │<───────────────────────────│
 │  8. 切换成功                │                            │
 │<───────────────────────────│                            │
 │                            │                            │
 │  9. 使用新 Agent 对话       │                            │
 │───────────────────────────>│                            │
```

#### 技术实现

```python
class AgentManager:
    """Agent 管理器"""

    def __init__(self):
        self.registry = AgentRegistry()
        self.active_agents = {}  # user_id -> agent_instance

    async def install_agent(
        self,
        user_id: str,
        agent_id: str,
        config: Dict = None
    ) -> bool:
        """
        安装 Agent

        Args:
            user_id: 用户 ID
            agent_id: Agent ID
            config: 配置参数

        Returns:
            bool: 是否成功
        """
        # 1. 从 Registry 获取 Agent 信息
        agent_info = await self.registry.get_agent(agent_id)

        # 2. 下载 .alicepkg 包
        package_path = await self.download_package(
            agent_info['package_url']
        )

        # 3. 验证包签名和权限
        is_valid = await self.verify_package(package_path)
        if not is_valid:
            raise SecurityError("Invalid package")

        # 4. 解压并安装
        agent_dir = await self.install_package(package_path, user_id)

        # 5. 加载 Agent Card 并验证 A2A 协议兼容性
        agent_card = await self.load_agent_card(agent_dir)
        if agent_card['protocolVersion'] != 'v1':
            raise CompatibilityError("Unsupported protocol version")

        # 6. 创建 Agent 实例（沙箱环境）
        agent_instance = await self.create_agent_instance(
            agent_dir,
            config
        )

        # 7. 记录安装信息
        await self.db.insert_installation(
            user_id=user_id,
            agent_id=agent_id,
            version=agent_info['version'],
            config=config
        )

        return True

    async def switch_agent(
        self,
        user_id: str,
        agent_id: str
    ) -> bool:
        """
        切换当前激活的 Agent

        Args:
            user_id: 用户 ID
            agent_id: 目标 Agent ID

        Returns:
            bool: 是否成功
        """
        # 1. 检查是否已安装
        installation = await self.db.get_installation(user_id, agent_id)
        if not installation:
            raise NotInstalledError("Agent not installed")

        # 2. 加载 Agent 实例
        agent_instance = await self.load_agent_instance(
            user_id,
            agent_id
        )

        # 3. 验证 Agent 健康状态
        is_healthy = await self.health_check(agent_instance)
        if not is_healthy:
            raise AgentUnavailableError("Agent is not responding")

        # 4. 切换激活的 Agent
        old_agent = self.active_agents.get(user_id)
        if old_agent:
            await self.deactivate_agent(old_agent)

        self.active_agents[user_id] = agent_instance

        # 5. 更新用户配置
        await self.db.update_user_active_agent(user_id, agent_id)

        return True

    async def send_message(
        self,
        user_id: str,
        message: Message,
        context_id: Optional[str] = None
    ) -> Task:
        """
        发送消息给当前激活的 Agent

        Args:
            user_id: 用户 ID
            message: 消息对象
            context_id: 上下文 ID

        Returns:
            Task: 任务对象
        """
        # 1. 获取当前激活的 Agent
        agent = self.active_agents.get(user_id)
        if not agent:
            # 如果没有激活的 Agent，使用默认的 Alice Chat
            agent = await self.load_default_agent(user_id)
            self.active_agents[user_id] = agent

        # 2. 调用 Agent 的 execute 方法（A2A 协议）
        task = await agent.execute(message, context_id)

        # 3. 更新使用统计
        await self.db.increment_usage_count(user_id, agent.agent_id)

        return task
```

### 5.3 兼容性保证

#### Agent 接口契约

所有 Agent 必须实现以下接口，确保可互换：

```python
# 必需方法（来自 AgentExecutor 基类）
async def execute(message, context_id, task_id) -> Task
async def cancel(task_id) -> bool
def get_agent_card() -> Dict

# 可选方法
async def stream_execute(message, context_id) -> AsyncIterator[Event]
async def health_check() -> bool
```

#### 状态迁移

切换 Agent 时，需要处理上下文和记忆的迁移：

```python
class AgentSwitcher:
    """Agent 切换助手"""

    async def migrate_context(
        self,
        user_id: str,
        from_agent: str,
        to_agent: str,
        context_ids: List[str]
    ) -> bool:
        """
        迁移对话上下文

        Args:
            user_id: 用户 ID
            from_agent: 原 Agent ID
            to_agent: 目标 Agent ID
            context_ids: 要迁移的上下文 ID 列表

        Returns:
            bool: 是否成功
        """
        for context_id in context_ids:
            # 1. 从原 Agent 导出对话历史
            history = await self.export_history(
                user_id,
                from_agent,
                context_id
            )

            # 2. 转换为标准格式（A2A Message 格式）
            standard_history = self.convert_to_standard(history)

            # 3. 导入到新 Agent
            await self.import_history(
                user_id,
                to_agent,
                context_id,
                standard_history
            )

        return True
```

---

## 6. 开发者工具和 CLI

### 6.1 Alice Home CLI

```bash
# 安装 CLI
pip install alice-home-cli

# 初始化新 Agent 项目
alice-home init my-agent

# 本地开发和测试
alice-home dev

# 打包 Agent
alice-home package

# 发布到市场
alice-home publish
```

### 6.2 项目模板

```bash
alice-home init my-agent
```

生成项目结构：

```
my-agent/
├── manifest.yaml
├── agent_card.json
├── src/
│   ├── main.py
│   └── requirements.txt
├── config/
│   └── default.yaml
├── tests/
│   ├── test_basic.py
│   └── test_integration.py
├── privacy.md
├── README.md
└── .env.example
```

自动生成的 `main.py`：

```python
from alice_home_agent_sdk import AgentExecutor, Message, Task

class MyCustomAgent(AgentExecutor):
    """My Custom Agent"""

    async def execute(self, message, context_id=None, task_id=None):
        # TODO: 实现你的 Agent 逻辑
        pass

    async def cancel(self, task_id):
        # TODO: 实现取消逻辑
        pass

# 启动服务
if __name__ == "__main__":
    from alice_home_agent_sdk.protocols.jsonrpc import JSONRPCServer

    agent = MyCustomAgent()
    server = JSONRPCServer(agent)
    server.run()
```

---

## 7. 企业功能和商业化

### 7.1 开源版 vs 企业版

| 功能 | 开源版 | 企业版 |
|------|--------|--------|
| Alice Chat Agent（内置） | ✅ 免费 | ✅ 增强版 |
| Agent SDK（基于 A2A） | ✅ 完整功能 | ✅ + 企业支持 |
| Agent 市场（社区 Agent） | ✅ 免费下载 | ✅ + 企业专属 |
| Agent 注册中心 | ✅ 公共注册中心 | ✅ + 私有注册中心 |
| 流式响应 | ❌ | ✅ SSE 流式 |
| 长期记忆 | ❌ | ✅ 跨会话记忆 |
| 知识图谱 | ❌ | ✅ Neo4j 集成 |
| Agent 协作（多 Agent） | ❌ | ✅ A2A 协议协作 |
| 企业私有 Agent 市场 | ❌ | ✅ 自建市场 |
| SLA 和技术支持 | ❌ 社区支持 | ✅ 7x24 支持 |

### 7.2 企业私有 Agent 市场

企业可以部署自己的私有 Agent 注册中心：

```yaml
# docker-compose.yml
version: '3.8'
services:
  agent-registry:
    image: alice-home/agent-registry:enterprise
    environment:
      - REGISTRY_MODE=private
      - AUTH_PROVIDER=ldap
      - STORAGE_BACKEND=s3
    volumes:
      - ./data:/data
    ports:
      - "8080:8080"
```

---

## 8. 技术栈总结

### 8.1 Alice Home Agent SDK

- **语言**：Python 3.11+
- **核心协议**：A2A Protocol (JSON-RPC 2.0)
- **Web 框架**：FastAPI（用于 JSON-RPC 服务器）
- **异步库**：asyncio, aiohttp
- **依赖管理**：Poetry
- **测试**：pytest, pytest-asyncio

### 8.2 Agent 市场

- **后端**：Django 4.2+ / FastAPI
- **数据库**：PostgreSQL 14+
- **缓存**：Redis 7+
- **文件存储**：S3 / MinIO
- **消息队列**：Celery + Redis
- **搜索**：Elasticsearch（可选）
- **前端**：React 18 + TypeScript

### 8.3 基础设施

- **容器化**：Docker + Docker Compose
- **编排**：Kubernetes（企业版）
- **CI/CD**：GitHub Actions
- **监控**：Prometheus + Grafana
- **日志**：ELK Stack
- **API Gateway**：Kong / Nginx

---

## 9. 实施路线图

### Phase 1: MVP (4 周)

**Week 1-2: Alice Home Agent SDK 开发**
- [ ] 实现 AgentExecutor 基类
- [ ] 实现 Task 生命周期管理
- [ ] 实现 Message 处理
- [ ] 实现 JSON-RPC 2.0 服务器
- [ ] 实现 Agent Card 生成
- [ ] 基础测试用例

**Week 3: Alice Chat Agent 开发**
- [ ] 实现基础对话能力
- [ ] 集成 OpenAI API
- [ ] 实现短期记忆（MongoDB）
- [ ] 实现多轮对话
- [ ] 单元测试和集成测试

**Week 4: Agent 市场 MVP**
- [ ] 数据库设计和迁移
- [ ] Agent 注册 API
- [ ] Agent 发现 API
- [ ] 简单的 Web UI（列表和详情）
- [ ] GitHub Release 安装支持

### Phase 2: 核心功能 (6 周)

**Week 5-6: SDK 增强**
- [ ] 实现 SSE 流式响应
- [ ] 实现长期记忆接口
- [ ] 增加更多 LLM 集成（Anthropic, Azure）
- [ ] 实现 Agent 健康检查
- [ ] 性能优化

**Week 7-8: Agent 市场完善**
- [ ] 审核流程实现
- [ ] 版本管理
- [ ] 评分和评论系统
- [ ] 搜索和分类功能
- [ ] 统计分析仪表板

**Week 9-10: 开发者工具**
- [ ] alice-home-cli 开发
- [ ] 项目模板生成器
- [ ] 本地调试工具
- [ ] 打包和发布工具
- [ ] 文档和示例

### Phase 3: 企业功能 (8 周)

**Week 11-14: 企业 Agent 功能**
- [ ] 知识图谱集成（Neo4j）
- [ ] 多 Agent 协作（A2A 协议）
- [ ] 企业私有注册中心
- [ ] LDAP/SSO 集成
- [ ] 高级权限控制

**Week 15-18: 生产就绪**
- [ ] 容器化和 K8s 部署
- [ ] 监控和日志系统
- [ ] 性能压测和优化
- [ ] 安全审计和加固
- [ ] 完整文档和部署指南

---

## 10. 总结

Alice Home 的 Agent 核心架构基于 **A2A 协议**构建了一个完整的 Agent 生态系统：

1. **Alice Home Agent SDK**：开发者友好的 SDK，完全兼容 A2A 协议标准
2. **Alice Chat Agent**：最小可运行的内置 Agent，开箱即用
3. **Agent 市场**：类似 Dify Marketplace 的注册发现平台
4. **无缝替换**：基于统一协议，Agent 可以无缝互换

这个架构实现了"**开箱即用·伴随成长**"的设计哲学：
- 用户可以立即使用内置的 Alice Chat Agent
- 随着需求增长，可以从市场选择更专业的 Agent
- 企业用户可以开发私有 Agent 并部署到私有市场
- 所有 Agent 都遵循相同的 A2A 协议，保证互操作性

---

## 附录：参考资料

- [A2A Protocol Specification](https://a2a-protocol.org/latest/specification/)
- [A2A Python SDK](https://github.com/a2aproject/a2a-python)
- [Dify Plugin System](https://docs.dify.ai/en/plugins)
- [Dify Marketplace](https://marketplace.dify.ai/)
- [JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)
