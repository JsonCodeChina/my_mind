# Alice Home - 用户与权限模块实现方案 V2

## 1. 模块概述

### 1.1 模块定位
用户与权限模块是 Alice Home 的基础模块，负责用户认证、角色管理、权限控制等功能。**采用单租户架构**，不考虑多租户隔离。

### 1.2 核心原则
- **最小运行**：开箱即用，预置管理员账号和基础角色
- **双角色设计**：管理员（Admin）+ 普通用户（User）
- **权限清晰**：管理员负责配置，普通用户负责使用

### 1.3 技术栈
- **后端框架**：FastAPI 0.104+
- **数据库**：PostgreSQL 14+
- **认证**：JWT (PyJWT 2.8+)
- **密码哈希**：Bcrypt (passlib 1.7+)
- **权限**：基于 RBAC 的装饰器实现
- **测试**：pytest + pytest-asyncio

---

## 2. 数据库设计

### 2.1 核心表结构

#### users 表
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,

    -- 基本信息
    nickname VARCHAR(100),
    avatar_url TEXT,
    phone VARCHAR(20),

    -- 角色和状态
    role VARCHAR(20) NOT NULL DEFAULT 'user',  -- 'admin' 或 'user'
    is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    is_first_login BOOLEAN NOT NULL DEFAULT TRUE,

    -- 元 Agent 配置
    active_agent_id UUID,  -- 当前激活的 Agent

    -- 审计字段
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_login_at TIMESTAMP,
    last_login_ip INET,

    -- 约束
    CONSTRAINT valid_role CHECK (role IN ('admin', 'user')),
    CONSTRAINT users_active_agent_fkey FOREIGN KEY (active_agent_id)
        REFERENCES agent_registry(id) ON DELETE SET NULL
);

-- 索引
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_is_enabled ON users(is_enabled);
CREATE INDEX idx_users_created_at ON users(created_at DESC);
```

#### login_logs 表（登录日志）
```sql
CREATE TABLE login_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID NOT NULL,
    username VARCHAR(50) NOT NULL,

    -- 登录信息
    login_at TIMESTAMP NOT NULL DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT,

    -- 登录状态
    status VARCHAR(20) NOT NULL,  -- 'success', 'failed', 'locked'
    failure_reason TEXT,

    -- 索引
    CONSTRAINT login_logs_user_fkey FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_login_logs_user_id ON login_logs(user_id);
CREATE INDEX idx_login_logs_login_at ON login_logs(login_at DESC);
CREATE INDEX idx_login_logs_status ON login_logs(status);
```

#### password_reset_tokens 表（密码重置令牌）
```sql
CREATE TABLE password_reset_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,

    -- 过期时间
    expires_at TIMESTAMP NOT NULL,
    is_used BOOLEAN NOT NULL DEFAULT FALSE,

    -- 审计
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    used_at TIMESTAMP,

    CONSTRAINT password_reset_tokens_user_fkey FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_password_reset_tokens_token ON password_reset_tokens(token);
CREATE INDEX idx_password_reset_tokens_user_id ON password_reset_tokens(user_id);
CREATE INDEX idx_password_reset_tokens_expires_at ON password_reset_tokens(expires_at);
```

### 2.2 初始化数据

#### 预置管理员账号
```sql
-- 首次部署时自动创建管理员账号
INSERT INTO users (username, email, password_hash, nickname, role, is_first_login)
VALUES (
    'admin',
    'admin@alicehome.local',
    '$2b$12$KIXxZ8vZ8vZ8vZ8vZ8vZ8u...',  -- 初始密码: admin123 (需在首次登录时强制修改)
    'System Administrator',
    'admin',
    TRUE
);
```

---

## 3. 核心功能实现

### 3.1 用户认证

#### JWT Token 结构
```python
# JWT Payload
{
    "sub": "user_id",           # 用户 ID
    "username": "alice",        # 用户名
    "role": "user",             # 角色
    "email": "alice@example.com",
    "iat": 1609459200,          # 签发时间
    "exp": 1609545600,          # 过期时间（24小时）
    "jti": "unique_token_id"    # Token 唯一 ID
}
```

#### 登录流程实现
```python
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from typing import Optional
import secrets

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])

# 密码哈希
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT 配置
SECRET_KEY = secrets.token_urlsafe(32)  # 从环境变量读取
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 1440  # 24小时

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


# ========== 密码处理 ==========
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """验证密码"""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """生成密码哈希"""
    return pwd_context.hash(password)


# ========== JWT Token ==========
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """创建 JWT Token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "jti": secrets.token_urlsafe(16)
    })

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    """从 Token 获取当前用户"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception

        # 从数据库查询用户
        async with get_db() as db:
            user = await db.fetch_one(
                "SELECT * FROM users WHERE id = $1 AND is_enabled = TRUE",
                user_id
            )
            if user is None:
                raise credentials_exception

        return dict(user)

    except JWTError:
        raise credentials_exception


def require_role(required_role: str):
    """权限装饰器：要求特定角色"""
    async def role_checker(current_user: dict = Depends(get_current_user)):
        if current_user["role"] != required_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required role: {required_role}"
            )
        return current_user
    return role_checker


# ========== API 端点 ==========

@router.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    用户登录

    Body:
        username: 用户名
        password: 密码

    Returns:
        access_token: JWT Token
        token_type: "bearer"
        user: 用户信息
    """
    async with get_db() as db:
        # 1. 查询用户
        user = await db.fetch_one(
            "SELECT * FROM users WHERE username = $1",
            form_data.username
        )

        if not user:
            # 记录失败日志
            await db.execute(
                """INSERT INTO login_logs (user_id, username, status, failure_reason, ip_address)
                   VALUES ($1, $2, $3, $4, $5)""",
                None, form_data.username, "failed", "User not found", get_client_ip()
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password"
            )

        # 2. 验证密码
        if not verify_password(form_data.password, user["password_hash"]):
            await db.execute(
                """INSERT INTO login_logs (user_id, username, status, failure_reason, ip_address)
                   VALUES ($1, $2, $3, $4, $5)""",
                user["id"], user["username"], "failed", "Invalid password", get_client_ip()
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password"
            )

        # 3. 检查用户是否被禁用
        if not user["is_enabled"]:
            await db.execute(
                """INSERT INTO login_logs (user_id, username, status, failure_reason, ip_address)
                   VALUES ($1, $2, $3, $4, $5)""",
                user["id"], user["username"], "locked", "User is disabled", get_client_ip()
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User account is disabled"
            )

        # 4. 首次登录且是管理员，自动分配元 Agent
        if user["is_first_login"] and user["active_agent_id"] is None:
            meta_agent = await db.fetch_one(
                "SELECT id FROM agent_registry WHERE is_meta_agent = TRUE LIMIT 1"
            )
            if meta_agent:
                await db.execute(
                    "UPDATE users SET active_agent_id = $1, is_first_login = FALSE WHERE id = $2",
                    meta_agent["id"], user["id"]
                )
                user["active_agent_id"] = meta_agent["id"]

        # 5. 更新最后登录时间
        await db.execute(
            "UPDATE users SET last_login_at = NOW(), last_login_ip = $1 WHERE id = $2",
            get_client_ip(), user["id"]
        )

        # 6. 记录成功日志
        await db.execute(
            """INSERT INTO login_logs (user_id, username, status, ip_address)
               VALUES ($1, $2, $3, $4)""",
            user["id"], user["username"], "success", get_client_ip()
        )

        # 7. 生成 Token
        access_token = create_access_token(
            data={
                "sub": str(user["id"]),
                "username": user["username"],
                "role": user["role"],
                "email": user["email"]
            }
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user["id"]),
                "username": user["username"],
                "email": user["email"],
                "nickname": user["nickname"],
                "role": user["role"],
                "active_agent_id": str(user["active_agent_id"]) if user["active_agent_id"] else None
            }
        }


@router.post("/register")
async def register(username: str, email: str, password: str):
    """
    用户注册（仅普通用户，管理员由系统预置）

    Body:
        username: 用户名
        email: 邮箱
        password: 密码

    Returns:
        user: 新创建的用户信息
    """
    async with get_db() as db:
        # 1. 检查用户名是否存在
        existing = await db.fetch_one(
            "SELECT id FROM users WHERE username = $1 OR email = $2",
            username, email
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username or email already registered"
            )

        # 2. 获取元 Agent
        meta_agent = await db.fetch_one(
            "SELECT id FROM agent_registry WHERE is_meta_agent = TRUE LIMIT 1"
        )

        # 3. 创建用户（自动分配元 Agent）
        user_id = await db.fetch_val(
            """INSERT INTO users (username, email, password_hash, role, active_agent_id, is_first_login)
               VALUES ($1, $2, $3, $4, $5, $6)
               RETURNING id""",
            username, email, get_password_hash(password), "user",
            meta_agent["id"] if meta_agent else None, False
        )

        return {
            "id": str(user_id),
            "username": username,
            "email": email,
            "role": "user",
            "active_agent_id": str(meta_agent["id"]) if meta_agent else None
        }


@router.get("/me")
async def get_current_user_info(current_user: dict = Depends(get_current_user)):
    """获取当前用户信息"""
    return {
        "id": str(current_user["id"]),
        "username": current_user["username"],
        "email": current_user["email"],
        "nickname": current_user["nickname"],
        "avatar_url": current_user["avatar_url"],
        "role": current_user["role"],
        "active_agent_id": str(current_user["active_agent_id"]) if current_user["active_agent_id"] else None,
        "created_at": current_user["created_at"].isoformat()
    }


@router.put("/me/password")
async def change_password(
    old_password: str,
    new_password: str,
    current_user: dict = Depends(get_current_user)
):
    """修改密码"""
    async with get_db() as db:
        # 1. 验证旧密码
        user = await db.fetch_one(
            "SELECT password_hash FROM users WHERE id = $1",
            current_user["id"]
        )

        if not verify_password(old_password, user["password_hash"]):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Old password is incorrect"
            )

        # 2. 更新密码
        await db.execute(
            "UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2",
            get_password_hash(new_password), current_user["id"]
        )

        return {"message": "Password updated successfully"}
```

### 3.2 用户管理（管理员专属）

```python
@router.get("/users", dependencies=[Depends(require_role("admin"))])
async def list_users(
    page: int = 1,
    page_size: int = 20,
    role: Optional[str] = None,
    is_enabled: Optional[bool] = None
):
    """
    查询用户列表（仅管理员）

    Query:
        page: 页码
        page_size: 每页数量
        role: 角色过滤 (admin/user)
        is_enabled: 启用状态过滤
    """
    async with get_db() as db:
        # 构建查询条件
        conditions = []
        params = []
        param_count = 0

        if role:
            param_count += 1
            conditions.append(f"role = ${param_count}")
            params.append(role)

        if is_enabled is not None:
            param_count += 1
            conditions.append(f"is_enabled = ${param_count}")
            params.append(is_enabled)

        where_clause = " AND ".join(conditions) if conditions else "TRUE"

        # 查询总数
        total = await db.fetch_val(
            f"SELECT COUNT(*) FROM users WHERE {where_clause}",
            *params
        )

        # 查询列表
        offset = (page - 1) * page_size
        param_count += 1
        limit_clause = f"LIMIT ${param_count}"
        params.append(page_size)

        param_count += 1
        offset_clause = f"OFFSET ${param_count}"
        params.append(offset)

        users = await db.fetch_all(
            f"""SELECT id, username, email, nickname, avatar_url, role, is_enabled,
                       created_at, last_login_at
                FROM users
                WHERE {where_clause}
                ORDER BY created_at DESC
                {limit_clause} {offset_clause}""",
            *params
        )

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "data": [dict(user) for user in users]
        }


@router.post("/users", dependencies=[Depends(require_role("admin"))])
async def create_user(username: str, email: str, password: str, role: str = "user"):
    """创建用户（仅管理员）"""
    if role not in ["admin", "user"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid role. Must be 'admin' or 'user'"
        )

    async with get_db() as db:
        # 检查重复
        existing = await db.fetch_one(
            "SELECT id FROM users WHERE username = $1 OR email = $2",
            username, email
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username or email already exists"
            )

        # 获取元 Agent
        meta_agent = await db.fetch_one(
            "SELECT id FROM agent_registry WHERE is_meta_agent = TRUE LIMIT 1"
        )

        # 创建用户
        user_id = await db.fetch_val(
            """INSERT INTO users (username, email, password_hash, role, active_agent_id)
               VALUES ($1, $2, $3, $4, $5)
               RETURNING id""",
            username, email, get_password_hash(password), role,
            meta_agent["id"] if meta_agent else None
        )

        return {"id": str(user_id), "username": username, "email": email, "role": role}


@router.put("/users/{user_id}/toggle", dependencies=[Depends(require_role("admin"))])
async def toggle_user_status(user_id: str):
    """启用/禁用用户（仅管理员）"""
    async with get_db() as db:
        user = await db.fetch_one(
            "SELECT is_enabled FROM users WHERE id = $1",
            user_id
        )
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        new_status = not user["is_enabled"]
        await db.execute(
            "UPDATE users SET is_enabled = $1, updated_at = NOW() WHERE id = $2",
            new_status, user_id
        )

        return {"is_enabled": new_status}


@router.delete("/users/{user_id}", dependencies=[Depends(require_role("admin"))])
async def delete_user(user_id: str):
    """删除用户（仅管理员）"""
    async with get_db() as db:
        result = await db.execute(
            "DELETE FROM users WHERE id = $1 AND role != 'admin'",  # 不允许删除管理员
            user_id
        )
        if result == "DELETE 0":
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found or cannot delete admin user"
            )

        return {"message": "User deleted successfully"}
```

---

## 4. 权限控制

### 4.1 RBAC 权限模型

| 功能模块 | 管理员 | 普通用户 |
|---------|--------|----------|
| **用户管理** | ✅ 创建、查看、编辑、删除用户 | ❌ |
| **角色分配** | ✅ 修改用户角色 | ❌ |
| **Agent 管理** | ✅ 安装、启用、配置、设置元 Agent | ❌ |
| **Agent 市场** | ✅ 查看、安装、配置 | ✅ 查看（只读）|
| **Agent 切换** | ✅ | ✅ 切换已启用的 Agent |
| **MCP 管理** | ✅ 安装、启用、配置 | ❌ |
| **MCP 市场** | ✅ 查看、安装、配置 | ✅ 查看（只读）|
| **LLM 配置** | ✅ 添加、配置、绑定 | ❌ |
| **对话功能** | ✅ | ✅ |
| **对话历史** | ✅ 查看所有用户 | ✅ 仅查看自己的 |
| **系统运维** | ✅ 监控、日志、备份 | ❌ |
| **个人设置** | ✅ | ✅ |

### 4.2 权限装饰器使用示例

```python
# 仅管理员可访问
@router.get("/admin/dashboard", dependencies=[Depends(require_role("admin"))])
async def admin_dashboard():
    return {"message": "Admin Dashboard"}

# 任何已登录用户可访问
@router.get("/user/profile", dependencies=[Depends(get_current_user)])
async def user_profile(current_user: dict = Depends(get_current_user)):
    return current_user

# 公开访问（无需登录）
@router.get("/public/info")
async def public_info():
    return {"version": "1.0.0"}
```

---

## 5. 最小运行配置

### 5.1 初始化脚本

```python
# scripts/init_users.py
import asyncio
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

async def init_default_users():
    """初始化默认用户"""
    async with get_db() as db:
        # 1. 检查是否已有管理员
        admin_exists = await db.fetch_val(
            "SELECT COUNT(*) FROM users WHERE role = 'admin'"
        )

        if admin_exists == 0:
            print("Creating default admin user...")
            await db.execute(
                """INSERT INTO users (username, email, password_hash, nickname, role)
                   VALUES ($1, $2, $3, $4, $5)""",
                "admin",
                "admin@alicehome.local",
                pwd_context.hash("admin123"),  # 默认密码
                "System Administrator",
                "admin"
            )
            print("✅ Default admin created: username=admin, password=admin123")
            print("⚠️  Please change the password after first login!")
        else:
            print("Admin user already exists, skipping...")

if __name__ == "__main__":
    asyncio.run(init_default_users())
```

### 5.2 环境变量配置

```bash
# .env
DATABASE_URL=postgresql://alice:password@localhost:5432/alice_home
JWT_SECRET_KEY=<随机生成的密钥>
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=1440

# 管理员默认密码（首次部署）
DEFAULT_ADMIN_PASSWORD=admin123
```

---

## 6. API 接口清单

### 6.1 认证相关

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/auth/login` | 用户登录 | 公开 |
| POST | `/api/v1/auth/register` | 用户注册 | 公开 |
| GET | `/api/v1/auth/me` | 获取当前用户信息 | 已登录 |
| PUT | `/api/v1/auth/me/password` | 修改密码 | 已登录 |
| POST | `/api/v1/auth/logout` | 退出登录 | 已登录 |

### 6.2 用户管理（管理员）

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/api/v1/admin/users` | 查询用户列表 | 管理员 |
| POST | `/api/v1/admin/users` | 创建用户 | 管理员 |
| PUT | `/api/v1/admin/users/{user_id}` | 编辑用户 | 管理员 |
| PUT | `/api/v1/admin/users/{user_id}/toggle` | 启用/禁用用户 | 管理员 |
| DELETE | `/api/v1/admin/users/{user_id}` | 删除用户 | 管理员 |
| PUT | `/api/v1/admin/users/{user_id}/reset-password` | 重置密码 | 管理员 |
| GET | `/api/v1/admin/users/{user_id}/login-logs` | 查看用户登录日志 | 管理员 |

---

## 7. 开发计划

### Phase 1: MVP（2 周）
- ✅ Week 1: 数据库设计、用户模型、JWT 认证
- ✅ Week 2: 登录/注册 API、权限装饰器、初始化脚本

### Phase 2: 用户管理（1 周）
- ✅ Week 3: 管理员用户管理 API、登录日志、测试

### Phase 3: 优化与测试（1 周）
- ✅ Week 4: 单元测试、集成测试、API 文档、安全加固

**总计：4 周**

---

## 8. 测试用例

### 8.1 单元测试
```python
# tests/test_auth.py
import pytest
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_login_success(client: AsyncClient):
    """测试登录成功"""
    response = await client.post("/api/v1/auth/login", data={
        "username": "testuser",
        "password": "testpass123"
    })
    assert response.status_code == 200
    assert "access_token" in response.json()
    assert response.json()["token_type"] == "bearer"

@pytest.mark.asyncio
async def test_login_invalid_password(client: AsyncClient):
    """测试登录失败（密码错误）"""
    response = await client.post("/api/v1/auth/login", data={
        "username": "testuser",
        "password": "wrongpassword"
    })
    assert response.status_code == 401
    assert "Incorrect username or password" in response.json()["detail"]

@pytest.mark.asyncio
async def test_register_duplicate_username(client: AsyncClient):
    """测试注册重复用户名"""
    response = await client.post("/api/v1/auth/register", json={
        "username": "admin",  # 已存在的用户名
        "email": "newemail@example.com",
        "password": "password123"
    })
    assert response.status_code == 400
    assert "already registered" in response.json()["detail"]

@pytest.mark.asyncio
async def test_require_admin_role(client: AsyncClient, user_token: str):
    """测试普通用户访问管理员接口"""
    response = await client.get(
        "/api/v1/admin/users",
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 403
    assert "Insufficient permissions" in response.json()["detail"]
```

---

## 9. 安全考虑

### 9.1 密码策略
- 最小长度：8 个字符
- 必须包含：字母 + 数字
- Bcrypt 哈希（cost factor = 12）

### 9.2 Token 安全
- JWT Token 有效期：24 小时
- 签名算法：HS256
- Secret Key 从环境变量读取，随机生成

### 9.3 防止暴力破解
- 登录失败 5 次后锁定账号 30 分钟（可选）
- 记录所有登录尝试

### 9.4 XSS/CSRF 防护
- FastAPI 自动转义 JSON 输出
- 敏感操作需要 CSRF Token（可选）

---

## 10. 总结

本模块实现了 Alice Home 的用户与权限基础功能，采用 **单租户 + 双角色（管理员/普通用户）** 的简化设计，保证系统开箱即用。核心特性：

1. ✅ JWT 认证
2. ✅ RBAC 权限控制
3. ✅ 管理员用户管理
4. ✅ 登录日志审计
5. ✅ 元 Agent 自动分配
6. ✅ 最小运行配置

**下一步**：集成到 Agent 核心模块，实现用户与 Agent 的绑定关系。
