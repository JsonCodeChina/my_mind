# Alice Home MCP 工具模块完整实现方案

## 1. 模块概述

### 1.1 MCP 协议介绍

Model Context Protocol (MCP) 是 Anthropic 提出的开放协议，用于连接 AI 模型与外部工具、数据源。MCP 提供了标准化的方式来：

- **工具发现 (Tool Discovery)**：动态发现可用工具及其参数定义
- **工具调用 (Tool Invocation)**：标准化的工具执行接口
- **资源访问 (Resource Access)**：统一的数据访问抽象
- **上下文管理 (Context Management)**：会话级的上下文维护

### 1.2 设计理念

Alice Home MCP 模块的核心设计理念：

1. **可扩展性**：通过 MCP 协议实现工具的热插拔
2. **安全隔离**：每个 MCP 工具运行在独立进程中
3. **权限控制**：管理员管理、用户使用的分离
4. **向后兼容**：内置功能可平滑迁移为 MCP 工具
5. **市场生态**：支持第三方 MCP 工具发布与分发

### 1.3 技术栈

- **后端框架**：FastAPI 0.104+
- **数据库**：PostgreSQL 15+
- **MCP 协议**：Stdio (标准输入输出) / SSE (Server-Sent Events)
- **异步运行时**：asyncio + aiohttp
- **进程管理**：asyncio.subprocess
- **包格式**：.mcppkg (Tar + Metadata)

### 1.4 模块职责

```
┌─────────────────────────────────────────────────────────┐
│                    Alice Home Core                       │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────┐      ┌─────────────────────────────┐ │
│  │   Agent      │─────▶│   MCP Manager               │ │
│  │   Engine     │      │   - Tool Discovery          │ │
│  └──────────────┘      │   - Tool Invocation         │ │
│         │              │   - Process Management      │ │
│         │              └─────────────────────────────┘ │
│         │                         │                     │
│         │              ┌──────────┴──────────┐         │
│         │              │                     │         │
│         │         ┌────▼────┐         ┌─────▼────┐    │
│         │         │ MCP     │         │ MCP      │    │
│         │         │ Server  │         │ Server   │    │
│         │         │ (RAG)   │         │ (Memory) │    │
│         │         └─────────┘         └──────────┘    │
│         │                                               │
│  ┌──────▼──────┐                                       │
│  │  MCP Admin  │  (安装、启用、配置)                  │
│  └─────────────┘                                       │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## 2. 数据库设计

### 2.1 MCP Registry Table (MCP 注册表)

存储所有可用的 MCP 工具定义（市场）。

```sql
CREATE TABLE mcp_registry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- 基本信息
    mcp_id VARCHAR(255) UNIQUE NOT NULL,  -- 唯一标识，如 "com.alice.rag"
    name VARCHAR(255) NOT NULL,            -- 显示名称
    description TEXT,                       -- 工具描述
    author VARCHAR(255),                    -- 作者

    -- 类型与分类
    category VARCHAR(50) NOT NULL,         -- 分类：knowledge, memory, search, integration
    is_builtin BOOLEAN DEFAULT FALSE,      -- 是否内置工具
    is_official BOOLEAN DEFAULT FALSE,     -- 是否官方工具

    -- 版本信息
    latest_version VARCHAR(50),            -- 最新版本号

    -- 图标与展示
    icon_url TEXT,                         -- 图标 URL
    homepage_url TEXT,                     -- 主页 URL
    documentation_url TEXT,                -- 文档 URL

    -- 市场信息
    download_count INTEGER DEFAULT 0,      -- 下载次数
    rating_average DECIMAL(3,2),          -- 平均评分 (0-5)
    rating_count INTEGER DEFAULT 0,        -- 评分次数

    -- 标签与搜索
    tags TEXT[],                          -- 标签数组

    -- 时间戳
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    -- 索引
    CONSTRAINT valid_rating CHECK (rating_average >= 0 AND rating_average <= 5)
);

CREATE INDEX idx_mcp_registry_category ON mcp_registry(category);
CREATE INDEX idx_mcp_registry_is_builtin ON mcp_registry(is_builtin);
CREATE INDEX idx_mcp_registry_tags ON mcp_registry USING GIN(tags);
```

### 2.2 MCP Versions Table (版本表)

存储每个 MCP 工具的历史版本。

```sql
CREATE TABLE mcp_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- 关联
    mcp_id VARCHAR(255) NOT NULL REFERENCES mcp_registry(mcp_id) ON DELETE CASCADE,

    -- 版本信息
    version VARCHAR(50) NOT NULL,          -- 语义化版本号，如 "1.2.3"
    release_notes TEXT,                    -- 发布说明

    -- 包信息
    package_url TEXT,                      -- .mcppkg 包下载 URL
    package_size BIGINT,                   -- 包大小（字节）
    package_checksum VARCHAR(64),          -- SHA-256 校验和

    -- 兼容性
    min_alice_version VARCHAR(50),         -- 最小 Alice 版本要求
    max_alice_version VARCHAR(50),         -- 最大 Alice 版本要求

    -- MCP 配置
    mcp_config JSONB NOT NULL,             -- MCP 服务器配置
    /*
    mcp_config 示例：
    {
        "command": "python",
        "args": ["-m", "alice_mcp_rag"],
        "env": {
            "DATABASE_URL": "${ALICE_DATABASE_URL}"
        },
        "transport": "stdio",  // 或 "sse"
        "capabilities": {
            "tools": true,
            "resources": true,
            "prompts": false
        }
    }
    */

    -- 工具清单（从 MCP Server 发现的工具列表，安装时缓存）
    tools_manifest JSONB,                  -- 工具清单
    /*
    tools_manifest 示例：
    [
        {
            "name": "search_knowledge",
            "description": "Search the RAG knowledge base",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "limit": {"type": "integer", "default": 5}
                },
                "required": ["query"]
            }
        }
    ]
    */

    -- 状态
    status VARCHAR(20) DEFAULT 'active',   -- active, deprecated, yanked

    -- 时间戳
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(mcp_id, version)
);

CREATE INDEX idx_mcp_versions_mcp_id ON mcp_versions(mcp_id);
CREATE INDEX idx_mcp_versions_status ON mcp_versions(status);
```

### 2.3 MCP Installations Table (安装表)

管理员已安装的 MCP 工具实例。

```sql
CREATE TABLE mcp_installations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- 关联
    mcp_id VARCHAR(255) NOT NULL REFERENCES mcp_registry(mcp_id) ON DELETE CASCADE,
    version_id UUID NOT NULL REFERENCES mcp_versions(id) ON DELETE CASCADE,

    -- 安装信息
    installed_by UUID REFERENCES users(id),  -- 安装者
    installation_path TEXT,                   -- 本地安装路径

    -- 配置
    custom_config JSONB,                      -- 管理员自定义配置
    /*
    custom_config 示例：
    {
        "env": {
            "RAG_INDEX_PATH": "/data/rag_index",
            "MAX_RESULTS": "10"
        },
        "enabled": true
    }
    */

    -- 状态
    is_enabled BOOLEAN DEFAULT TRUE,          -- 是否启用
    status VARCHAR(20) DEFAULT 'installed',   -- installed, failed, updating

    -- 健康检查
    last_health_check TIMESTAMP WITH TIME ZONE,
    health_status VARCHAR(20),                -- healthy, unhealthy, unknown
    health_message TEXT,

    -- 时间戳
    installed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_mcp_installations_mcp_id ON mcp_installations(mcp_id);
CREATE INDEX idx_mcp_installations_is_enabled ON mcp_installations(is_enabled);
```

### 2.4 Agent MCP Bindings Table (Agent-MCP 绑定表)

定义哪些 Agent 可以使用哪些 MCP 工具。

```sql
CREATE TABLE agent_mcp_bindings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- 关联
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    installation_id UUID NOT NULL REFERENCES mcp_installations(id) ON DELETE CASCADE,

    -- 配置
    priority INTEGER DEFAULT 0,               -- 工具调用优先级
    is_enabled BOOLEAN DEFAULT TRUE,          -- 是否对此 Agent 启用

    -- 使用限制
    max_calls_per_session INTEGER,            -- 单次会话最大调用次数
    timeout_seconds INTEGER DEFAULT 30,       -- 工具调用超时（秒）

    -- 统计
    total_calls INTEGER DEFAULT 0,            -- 累计调用次数
    total_errors INTEGER DEFAULT 0,           -- 累计错误次数
    last_called_at TIMESTAMP WITH TIME ZONE,  -- 最后调用时间

    -- 时间戳
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(agent_id, installation_id)
);

CREATE INDEX idx_agent_mcp_agent_id ON agent_mcp_bindings(agent_id);
CREATE INDEX idx_agent_mcp_installation_id ON agent_mcp_bindings(installation_id);
```

### 2.5 MCP Call Logs Table (调用日志表)

记录所有 MCP 工具调用的审计日志。

```sql
CREATE TABLE mcp_call_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- 关联
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    installation_id UUID NOT NULL REFERENCES mcp_installations(id) ON DELETE CASCADE,
    binding_id UUID REFERENCES agent_mcp_bindings(id) ON DELETE SET NULL,

    -- 调用信息
    tool_name VARCHAR(255) NOT NULL,          -- 工具名称
    tool_input JSONB NOT NULL,                -- 输入参数
    tool_output JSONB,                        -- 输出结果

    -- 执行状态
    status VARCHAR(20) NOT NULL,              -- success, error, timeout
    error_message TEXT,                       -- 错误信息

    -- 性能指标
    started_at TIMESTAMP WITH TIME ZONE NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_ms INTEGER,                      -- 执行耗时（毫秒）

    -- 时间戳
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_mcp_call_logs_session_id ON mcp_call_logs(session_id);
CREATE INDEX idx_mcp_call_logs_agent_id ON mcp_call_logs(agent_id);
CREATE INDEX idx_mcp_call_logs_installation_id ON mcp_call_logs(installation_id);
CREATE INDEX idx_mcp_call_logs_created_at ON mcp_call_logs(created_at);
```

---

## 3. MCP 协议实现

### 3.1 MCP Server 连接管理

#### 3.1.1 MCP Client 基类

```python
# app/mcp/client.py
import asyncio
import json
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from uuid import uuid4

logger = logging.getLogger(__name__)


class MCPClient(ABC):
    """MCP Client 抽象基类"""

    def __init__(self, installation_id: str, config: Dict[str, Any]):
        self.installation_id = installation_id
        self.config = config
        self.is_connected = False
        self.capabilities: Optional[Dict[str, Any]] = None
        self.tools: List[Dict[str, Any]] = []

    @abstractmethod
    async def connect(self) -> None:
        """连接到 MCP Server"""
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """断开连接"""
        pass

    @abstractmethod
    async def send_request(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """发送 JSON-RPC 请求"""
        pass

    async def initialize(self) -> Dict[str, Any]:
        """初始化握手"""
        response = await self.send_request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {"listChanged": True},
                    "resources": {"subscribe": True, "listChanged": True}
                },
                "clientInfo": {
                    "name": "alice-home",
                    "version": "1.0.0"
                }
            }
        )

        self.capabilities = response.get("capabilities", {})
        self.is_connected = True

        # 发送 initialized 通知
        await self.send_notification("notifications/initialized")

        return response

    async def send_notification(self, method: str, params: Optional[Dict[str, Any]] = None) -> None:
        """发送通知（无需响应）"""
        # 通知不需要 id 字段
        pass

    async def list_tools(self) -> List[Dict[str, Any]]:
        """列出所有可用工具"""
        response = await self.send_request("tools/list")
        self.tools = response.get("tools", [])
        return self.tools

    async def call_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        timeout: int = 30
    ) -> Dict[str, Any]:
        """调用工具"""
        try:
            response = await asyncio.wait_for(
                self.send_request(
                    "tools/call",
                    {
                        "name": tool_name,
                        "arguments": arguments
                    }
                ),
                timeout=timeout
            )
            return response
        except asyncio.TimeoutError:
            raise MCPTimeoutError(f"Tool call timeout after {timeout}s")
```

#### 3.1.2 Stdio Transport 实现

```python
# app/mcp/transports/stdio.py
import asyncio
import json
from typing import Any, Dict, Optional

from app.mcp.client import MCPClient
from app.mcp.exceptions import MCPConnectionError, MCPProtocolError

logger = logging.getLogger(__name__)


class StdioMCPClient(MCPClient):
    """基于 Stdio 的 MCP Client"""

    def __init__(self, installation_id: str, config: Dict[str, Any]):
        super().__init__(installation_id, config)
        self.process: Optional[asyncio.subprocess.Process] = None
        self.pending_requests: Dict[str, asyncio.Future] = {}
        self.read_task: Optional[asyncio.Task] = None

    async def connect(self) -> None:
        """启动 MCP Server 进程"""
        command = self.config["command"]
        args = self.config.get("args", [])
        env = self._prepare_env()

        try:
            self.process = await asyncio.create_subprocess_exec(
                command,
                *args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env
            )

            # 启动读取任务
            self.read_task = asyncio.create_task(self._read_loop())

            # 初始化握手
            await self.initialize()

            # 发现工具
            await self.list_tools()

            logger.info(f"MCP Server connected: {self.installation_id}")

        except Exception as e:
            logger.error(f"Failed to connect MCP Server: {e}")
            raise MCPConnectionError(f"Connection failed: {e}")

    async def disconnect(self) -> None:
        """关闭进程"""
        if self.process:
            self.process.terminate()
            try:
                await asyncio.wait_for(self.process.wait(), timeout=5)
            except asyncio.TimeoutError:
                self.process.kill()
                await self.process.wait()

            self.process = None

        if self.read_task:
            self.read_task.cancel()
            try:
                await self.read_task
            except asyncio.CancelledError:
                pass

        self.is_connected = False
        logger.info(f"MCP Server disconnected: {self.installation_id}")

    async def send_request(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """发送 JSON-RPC 请求"""
        if not self.process or not self.process.stdin:
            raise MCPConnectionError("Not connected")

        request_id = str(uuid4())
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {}
        }

        # 创建 Future 等待响应
        future = asyncio.Future()
        self.pending_requests[request_id] = future

        # 发送请求
        message = json.dumps(request) + "\n"
        self.process.stdin.write(message.encode())
        await self.process.stdin.drain()

        # 等待响应
        try:
            response = await future
            if "error" in response:
                raise MCPProtocolError(
                    f"MCP Error: {response['error'].get('message', 'Unknown error')}"
                )
            return response.get("result", {})
        finally:
            self.pending_requests.pop(request_id, None)

    async def _read_loop(self) -> None:
        """读取 stdout 循环"""
        if not self.process or not self.process.stdout:
            return

        try:
            async for line in self.process.stdout:
                try:
                    message = json.loads(line.decode().strip())
                    await self._handle_message(message)
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON from MCP Server: {e}")
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Read loop error: {e}")

    async def _handle_message(self, message: Dict[str, Any]) -> None:
        """处理接收到的消息"""
        if "id" in message and message["id"] in self.pending_requests:
            # 这是一个响应
            future = self.pending_requests[message["id"]]
            if not future.done():
                future.set_result(message)
        elif "method" in message:
            # 这是一个通知或请求（Server -> Client）
            await self._handle_notification(message)

    async def _handle_notification(self, message: Dict[str, Any]) -> None:
        """处理来自 Server 的通知"""
        method = message.get("method")
        params = message.get("params", {})

        if method == "notifications/tools/list_changed":
            # 工具列表变化，重新获取
            await self.list_tools()
        elif method == "notifications/resources/list_changed":
            # 资源列表变化
            pass
        else:
            logger.warning(f"Unknown notification method: {method}")

    def _prepare_env(self) -> Dict[str, str]:
        """准备环境变量"""
        import os
        env = os.environ.copy()

        # 注入自定义环境变量
        custom_env = self.config.get("env", {})
        for key, value in custom_env.items():
            # 支持变量替换，如 ${ALICE_DATABASE_URL}
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                var_name = value[2:-1]
                value = env.get(var_name, "")
            env[key] = str(value)

        return env
```

#### 3.1.3 SSE Transport 实现（可选）

```python
# app/mcp/transports/sse.py
import asyncio
import aiohttp
from typing import Any, Dict, Optional

from app.mcp.client import MCPClient
from app.mcp.exceptions import MCPConnectionError


class SSEMCPClient(MCPClient):
    """基于 SSE 的 MCP Client"""

    def __init__(self, installation_id: str, config: Dict[str, Any]):
        super().__init__(installation_id, config)
        self.base_url = config["url"]
        self.session: Optional[aiohttp.ClientSession] = None
        self.sse_task: Optional[asyncio.Task] = None
        self.pending_requests: Dict[str, asyncio.Future] = {}

    async def connect(self) -> None:
        """连接到 SSE 端点"""
        self.session = aiohttp.ClientSession()

        # 启动 SSE 监听
        self.sse_task = asyncio.create_task(self._sse_loop())

        # 初始化握手
        await self.initialize()
        await self.list_tools()

    async def disconnect(self) -> None:
        """关闭连接"""
        if self.sse_task:
            self.sse_task.cancel()

        if self.session:
            await self.session.close()

        self.is_connected = False

    async def send_request(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """通过 POST 发送请求"""
        if not self.session:
            raise MCPConnectionError("Not connected")

        request_id = str(uuid4())
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {}
        }

        future = asyncio.Future()
        self.pending_requests[request_id] = future

        async with self.session.post(
            f"{self.base_url}/message",
            json=request
        ) as response:
            response.raise_for_status()

        return await future

    async def _sse_loop(self) -> None:
        """SSE 事件循环"""
        if not self.session:
            return

        try:
            async with self.session.get(f"{self.base_url}/sse") as response:
                async for line in response.content:
                    line = line.decode().strip()
                    if line.startswith("data: "):
                        data = json.loads(line[6:])
                        await self._handle_message(data)
        except asyncio.CancelledError:
            pass

    async def _handle_message(self, message: Dict[str, Any]) -> None:
        """处理 SSE 消息"""
        if "id" in message and message["id"] in self.pending_requests:
            future = self.pending_requests.pop(message["id"])
            if "error" in message:
                future.set_exception(
                    MCPProtocolError(message["error"].get("message"))
                )
            else:
                future.set_result(message.get("result", {}))
```

### 3.2 MCP Manager (核心管理器)

```python
# app/mcp/manager.py
import asyncio
from typing import Dict, List, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models import MCPInstallation, AgentMCPBinding, MCPCallLog
from app.mcp.client import MCPClient
from app.mcp.transports.stdio import StdioMCPClient
from app.mcp.transports.sse import SSEMCPClient
from app.mcp.exceptions import MCPNotFoundError


class MCPManager:
    """MCP 管理器 - 负责 MCP Client 生命周期管理"""

    def __init__(self):
        self.clients: Dict[str, MCPClient] = {}  # installation_id -> client
        self.lock = asyncio.Lock()

    async def get_client(
        self,
        db: AsyncSession,
        installation_id: UUID
    ) -> MCPClient:
        """获取或创建 MCP Client"""
        installation_id_str = str(installation_id)

        async with self.lock:
            # 如果已存在且已连接，直接返回
            if installation_id_str in self.clients:
                client = self.clients[installation_id_str]
                if client.is_connected:
                    return client
                else:
                    # 已断开，清理
                    await self._remove_client(installation_id_str)

            # 查询安装信息
            result = await db.execute(
                select(MCPInstallation)
                .where(MCPInstallation.id == installation_id)
                .where(MCPInstallation.is_enabled == True)
            )
            installation = result.scalar_one_or_none()

            if not installation:
                raise MCPNotFoundError(f"Installation {installation_id} not found or disabled")

            # 加载版本配置
            version = await installation.awaitable_attrs.version
            mcp_config = version.mcp_config

            # 合并自定义配置
            if installation.custom_config:
                mcp_config = {**mcp_config, **installation.custom_config}

            # 创建客户端
            transport = mcp_config.get("transport", "stdio")
            if transport == "stdio":
                client = StdioMCPClient(installation_id_str, mcp_config)
            elif transport == "sse":
                client = SSEMCPClient(installation_id_str, mcp_config)
            else:
                raise ValueError(f"Unknown transport: {transport}")

            # 连接
            await client.connect()

            # 缓存
            self.clients[installation_id_str] = client

            return client

    async def call_tool(
        self,
        db: AsyncSession,
        agent_id: UUID,
        session_id: UUID,
        installation_id: UUID,
        tool_name: str,
        arguments: Dict,
        timeout: int = 30
    ) -> Dict:
        """调用 MCP 工具"""
        import time

        started_at = time.time()
        call_log = MCPCallLog(
            session_id=session_id,
            agent_id=agent_id,
            installation_id=installation_id,
            tool_name=tool_name,
            tool_input=arguments,
            status="pending"
        )
        db.add(call_log)
        await db.commit()

        try:
            # 获取客户端
            client = await self.get_client(db, installation_id)

            # 调用工具
            result = await client.call_tool(tool_name, arguments, timeout)

            # 更新日志
            call_log.status = "success"
            call_log.tool_output = result
            call_log.duration_ms = int((time.time() - started_at) * 1000)
            call_log.completed_at = datetime.utcnow()

            await db.commit()

            return result

        except Exception as e:
            call_log.status = "error"
            call_log.error_message = str(e)
            call_log.duration_ms = int((time.time() - started_at) * 1000)
            call_log.completed_at = datetime.utcnow()

            await db.commit()
            raise

    async def get_available_tools(
        self,
        db: AsyncSession,
        agent_id: UUID
    ) -> List[Dict]:
        """获取 Agent 可用的所有工具"""
        # 查询绑定关系
        result = await db.execute(
            select(AgentMCPBinding)
            .where(AgentMCPBinding.agent_id == agent_id)
            .where(AgentMCPBinding.is_enabled == True)
        )
        bindings = result.scalars().all()

        all_tools = []
        for binding in bindings:
            installation = await binding.awaitable_attrs.installation
            if not installation.is_enabled:
                continue

            try:
                client = await self.get_client(db, installation.id)
                tools = client.tools

                # 添加元信息
                for tool in tools:
                    tool["_installation_id"] = str(installation.id)
                    tool["_mcp_id"] = installation.mcp_id

                all_tools.extend(tools)
            except Exception as e:
                logger.error(f"Failed to get tools from {installation.mcp_id}: {e}")

        return all_tools

    async def health_check(
        self,
        db: AsyncSession,
        installation_id: UUID
    ) -> Dict:
        """健康检查"""
        try:
            client = await self.get_client(db, installation_id)

            # 尝试 ping
            await client.send_request("ping")

            return {
                "status": "healthy",
                "is_connected": client.is_connected,
                "tools_count": len(client.tools)
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }

    async def disconnect_all(self):
        """断开所有连接"""
        async with self.lock:
            for installation_id in list(self.clients.keys()):
                await self._remove_client(installation_id)

    async def _remove_client(self, installation_id: str):
        """移除并断开客户端"""
        if installation_id in self.clients:
            client = self.clients.pop(installation_id)
            try:
                await client.disconnect()
            except Exception as e:
                logger.error(f"Error disconnecting client {installation_id}: {e}")


# 全局单例
mcp_manager = MCPManager()
```

### 3.3 异常定义

```python
# app/mcp/exceptions.py

class MCPError(Exception):
    """MCP 基础异常"""
    pass


class MCPConnectionError(MCPError):
    """连接错误"""
    pass


class MCPProtocolError(MCPError):
    """协议错误"""
    pass


class MCPTimeoutError(MCPError):
    """超时错误"""
    pass


class MCPNotFoundError(MCPError):
    """未找到错误"""
    pass
```

---

## 4. MCP 包格式 (.mcppkg)

### 4.1 包结构

```
example-mcp-tool-1.0.0.mcppkg (Tar.gz 格式)
├── manifest.json          # 包元数据
├── server/                # MCP Server 代码
│   ├── __init__.py
│   ├── main.py
│   └── requirements.txt
├── README.md              # 文档
└── LICENSE                # 许可证
```

### 4.2 manifest.json 规范

```json
{
  "mcpId": "com.example.tool",
  "name": "Example MCP Tool",
  "version": "1.0.0",
  "description": "An example MCP tool",
  "author": "Example Inc.",
  "license": "MIT",

  "mcp": {
    "command": "python",
    "args": ["-m", "server.main"],
    "env": {
      "API_KEY": "${EXAMPLE_API_KEY}"
    },
    "transport": "stdio",
    "capabilities": {
      "tools": true,
      "resources": false,
      "prompts": false
    }
  },

  "requirements": {
    "minAliceVersion": "1.0.0",
    "python": ">=3.9",
    "dependencies": ["requests>=2.28.0", "pydantic>=2.0.0"]
  },

  "category": "integration",
  "tags": ["api", "data"],
  "homepage": "https://example.com",
  "documentation": "https://docs.example.com"
}
```

### 4.3 包安装流程

```python
# app/mcp/installer.py
import tarfile
import json
import shutil
from pathlib import Path
from typing import Dict
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.models import MCPRegistry, MCPVersion, MCPInstallation


class MCPInstaller:
    """MCP 包安装器"""

    def __init__(self, install_base_dir: Path):
        self.install_base_dir = install_base_dir

    async def install_from_package(
        self,
        db: AsyncSession,
        package_path: Path,
        installed_by: UUID
    ) -> MCPInstallation:
        """从 .mcppkg 包安装"""

        # 1. 解压包
        extract_dir = self.install_base_dir / "temp" / package_path.stem
        extract_dir.mkdir(parents=True, exist_ok=True)

        with tarfile.open(package_path, "r:gz") as tar:
            tar.extractall(extract_dir)

        # 2. 读取 manifest
        manifest_path = extract_dir / "manifest.json"
        with open(manifest_path) as f:
            manifest = json.load(f)

        mcp_id = manifest["mcpId"]
        version = manifest["version"]

        # 3. 注册到 Registry（如果不存在）
        result = await db.execute(
            select(MCPRegistry).where(MCPRegistry.mcp_id == mcp_id)
        )
        registry = result.scalar_one_or_none()

        if not registry:
            registry = MCPRegistry(
                mcp_id=mcp_id,
                name=manifest["name"],
                description=manifest.get("description"),
                author=manifest.get("author"),
                category=manifest.get("category", "other"),
                is_builtin=False,
                is_official=False,
                latest_version=version,
                homepage_url=manifest.get("homepage"),
                documentation_url=manifest.get("documentation"),
                tags=manifest.get("tags", [])
            )
            db.add(registry)
            await db.flush()

        # 4. 创建版本记录
        mcp_version = MCPVersion(
            mcp_id=mcp_id,
            version=version,
            release_notes=manifest.get("releaseNotes"),
            mcp_config=manifest["mcp"],
            min_alice_version=manifest.get("requirements", {}).get("minAliceVersion"),
            status="active"
        )
        db.add(mcp_version)
        await db.flush()

        # 5. 移动到最终安装目录
        final_dir = self.install_base_dir / mcp_id / version
        final_dir.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(extract_dir), str(final_dir))

        # 6. 安装依赖（如果是 Python）
        if manifest["mcp"]["command"] == "python":
            await self._install_python_deps(final_dir)

        # 7. 创建安装记录
        installation = MCPInstallation(
            mcp_id=mcp_id,
            version_id=mcp_version.id,
            installed_by=installed_by,
            installation_path=str(final_dir),
            is_enabled=True,
            status="installed"
        )
        db.add(installation)
        await db.commit()

        return installation

    async def _install_python_deps(self, install_dir: Path):
        """安装 Python 依赖"""
        requirements_file = install_dir / "server" / "requirements.txt"
        if requirements_file.exists():
            process = await asyncio.create_subprocess_exec(
                "pip", "install", "-r", str(requirements_file),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await process.wait()

    async def uninstall(
        self,
        db: AsyncSession,
        installation_id: UUID
    ):
        """卸载 MCP 工具"""
        result = await db.execute(
            select(MCPInstallation).where(MCPInstallation.id == installation_id)
        )
        installation = result.scalar_one_or_none()

        if installation and installation.installation_path:
            # 删除文件
            install_dir = Path(installation.installation_path)
            if install_dir.exists():
                shutil.rmtree(install_dir)

            # 删除记录
            await db.delete(installation)
            await db.commit()
```

---

## 5. 内置 MCP 工具示例

### 5.1 RAG 知识库 MCP

```python
# builtin_mcps/rag/server.py
"""
内置 RAG 知识库 MCP Server
提供知识库搜索能力
"""
import asyncio
import json
import sys
from typing import Any, Dict

from mcp import MCPServer, Tool


class RAGMCPServer(MCPServer):
    """RAG MCP Server"""

    def __init__(self):
        super().__init__(
            name="alice-rag",
            version="1.0.0"
        )

        # 注册工具
        self.add_tool(
            Tool(
                name="search_knowledge",
                description="Search the RAG knowledge base for relevant documents",
                input_schema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query"
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum number of results",
                            "default": 5
                        },
                        "collection": {
                            "type": "string",
                            "description": "Knowledge base collection name (optional)"
                        }
                    },
                    "required": ["query"]
                },
                handler=self.search_knowledge
            )
        )

        self.add_tool(
            Tool(
                name="get_document",
                description="Retrieve a specific document by ID",
                input_schema={
                    "type": "object",
                    "properties": {
                        "document_id": {
                            "type": "string",
                            "description": "Document ID"
                        }
                    },
                    "required": ["document_id"]
                },
                handler=self.get_document
            )
        )

    async def search_knowledge(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """搜索知识库"""
        query = arguments["query"]
        limit = arguments.get("limit", 5)
        collection = arguments.get("collection")

        # TODO: 实际实现 - 调用 Alice Home 的 RAG 服务
        # 这里是示例
        from app.services.rag_service import rag_service

        results = await rag_service.search(
            query=query,
            limit=limit,
            collection=collection
        )

        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({
                        "results": [
                            {
                                "id": r.id,
                                "content": r.content,
                                "score": r.score,
                                "metadata": r.metadata
                            }
                            for r in results
                        ]
                    }, ensure_ascii=False)
                }
            ]
        }

    async def get_document(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """获取文档"""
        document_id = arguments["document_id"]

        from app.services.rag_service import rag_service

        doc = await rag_service.get_document(document_id)

        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({
                        "id": doc.id,
                        "content": doc.content,
                        "metadata": doc.metadata
                    }, ensure_ascii=False)
                }
            ]
        }


async def main():
    """入口函数"""
    server = RAGMCPServer()
    await server.run_stdio()


if __name__ == "__main__":
    asyncio.run(main())
```

### 5.2 企业记忆 MCP

```python
# builtin_mcps/memory/server.py
"""
内置企业记忆 MCP Server
提供记忆存储与检索能力
"""
import asyncio
import json
from typing import Any, Dict

from mcp import MCPServer, Tool


class MemoryMCPServer(MCPServer):
    """企业记忆 MCP Server"""

    def __init__(self):
        super().__init__(
            name="alice-memory",
            version="1.0.0"
        )

        self.add_tool(
            Tool(
                name="store_memory",
                description="Store a memory item for future recall",
                input_schema={
                    "type": "object",
                    "properties": {
                        "content": {
                            "type": "string",
                            "description": "Memory content"
                        },
                        "category": {
                            "type": "string",
                            "description": "Memory category",
                            "enum": ["fact", "preference", "context", "decision"]
                        },
                        "entities": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Related entities (people, projects, etc.)"
                        },
                        "metadata": {
                            "type": "object",
                            "description": "Additional metadata"
                        }
                    },
                    "required": ["content", "category"]
                },
                handler=self.store_memory
            )
        )

        self.add_tool(
            Tool(
                name="recall_memory",
                description="Recall relevant memories based on query",
                input_schema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query"
                        },
                        "category": {
                            "type": "string",
                            "description": "Filter by category (optional)"
                        },
                        "limit": {
                            "type": "integer",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                },
                handler=self.recall_memory
            )
        )

    async def store_memory(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """存储记忆"""
        from app.services.memory_service import memory_service

        memory = await memory_service.store(
            content=arguments["content"],
            category=arguments["category"],
            entities=arguments.get("entities", []),
            metadata=arguments.get("metadata", {})
        )

        return {
            "content": [
                {
                    "type": "text",
                    "text": f"Memory stored with ID: {memory.id}"
                }
            ]
        }

    async def recall_memory(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """检索记忆"""
        from app.services.memory_service import memory_service

        memories = await memory_service.recall(
            query=arguments["query"],
            category=arguments.get("category"),
            limit=arguments.get("limit", 5)
        )

        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({
                        "memories": [
                            {
                                "id": m.id,
                                "content": m.content,
                                "category": m.category,
                                "entities": m.entities,
                                "created_at": m.created_at.isoformat(),
                                "relevance_score": m.score
                            }
                            for m in memories
                        ]
                    }, ensure_ascii=False)
                }
            ]
        }


async def main():
    server = MemoryMCPServer()
    await server.run_stdio()


if __name__ == "__main__":
    asyncio.run(main())
```

### 5.3 文件搜索 MCP

```python
# builtin_mcps/file_search/server.py
"""
内置文件搜索 MCP Server
提供本地文件系统搜索能力
"""
import asyncio
import json
import os
from pathlib import Path
from typing import Any, Dict

from mcp import MCPServer, Tool


class FileSearchMCPServer(MCPServer):
    """文件搜索 MCP Server"""

    def __init__(self):
        super().__init__(
            name="alice-file-search",
            version="1.0.0"
        )

        self.allowed_paths = self._get_allowed_paths()

        self.add_tool(
            Tool(
                name="search_files",
                description="Search for files by name pattern",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "File name pattern (supports wildcards)"
                        },
                        "path": {
                            "type": "string",
                            "description": "Search path (must be within allowed directories)"
                        },
                        "recursive": {
                            "type": "boolean",
                            "default": True
                        }
                    },
                    "required": ["pattern"]
                },
                handler=self.search_files
            )
        )

        self.add_tool(
            Tool(
                name="read_file",
                description="Read file contents",
                input_schema={
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "File path"
                        },
                        "encoding": {
                            "type": "string",
                            "default": "utf-8"
                        }
                    },
                    "required": ["file_path"]
                },
                handler=self.read_file
            )
        )

    def _get_allowed_paths(self) -> list[Path]:
        """获取允许访问的路径（从环境变量）"""
        allowed = os.getenv("ALLOWED_SEARCH_PATHS", "").split(":")
        return [Path(p).resolve() for p in allowed if p]

    async def search_files(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """搜索文件"""
        import fnmatch

        pattern = arguments["pattern"]
        search_path = Path(arguments.get("path", self.allowed_paths[0]))
        recursive = arguments.get("recursive", True)

        # 安全检查
        if not any(search_path.resolve().is_relative_to(allowed) for allowed in self.allowed_paths):
            return {
                "content": [
                    {
                        "type": "text",
                        "text": "Error: Access denied to this path"
                    }
                ],
                "isError": True
            }

        results = []
        if recursive:
            for root, dirs, files in os.walk(search_path):
                for filename in files:
                    if fnmatch.fnmatch(filename, pattern):
                        full_path = Path(root) / filename
                        results.append({
                            "path": str(full_path),
                            "size": full_path.stat().st_size,
                            "modified": full_path.stat().st_mtime
                        })
        else:
            for item in search_path.iterdir():
                if item.is_file() and fnmatch.fnmatch(item.name, pattern):
                    results.append({
                        "path": str(item),
                        "size": item.stat().st_size,
                        "modified": item.stat().st_mtime
                    })

        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({"files": results}, ensure_ascii=False)
                }
            ]
        }

    async def read_file(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """读取文件"""
        file_path = Path(arguments["file_path"]).resolve()
        encoding = arguments.get("encoding", "utf-8")

        # 安全检查
        if not any(file_path.is_relative_to(allowed) for allowed in self.allowed_paths):
            return {
                "content": [{"type": "text", "text": "Error: Access denied"}],
                "isError": True
            }

        try:
            content = file_path.read_text(encoding=encoding)
            return {
                "content": [
                    {
                        "type": "text",
                        "text": content
                    }
                ]
            }
        except Exception as e:
            return {
                "content": [{"type": "text", "text": f"Error reading file: {e}"}],
                "isError": True
            }


async def main():
    server = FileSearchMCPServer()
    await server.run_stdio()


if __name__ == "__main__":
    asyncio.run(main())
```

---

## 6. API 接口清单

### 6.1 管理员接口

```python
# app/api/v1/admin/mcp.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID

from app.database import get_db
from app.api.deps import get_current_admin_user
from app.schemas.mcp import *
from app.services.mcp_service import mcp_service


router = APIRouter(prefix="/admin/mcp", tags=["MCP Admin"])


@router.get("/registry", response_model=list[MCPRegistryOut])
async def list_registry(
    category: Optional[str] = None,
    is_builtin: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """列出 MCP 市场（注册表）"""
    return await mcp_service.list_registry(db, category, is_builtin)


@router.get("/registry/{mcp_id}", response_model=MCPRegistryDetailOut)
async def get_registry_detail(
    mcp_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """获取 MCP 详情"""
    return await mcp_service.get_registry_detail(db, mcp_id)


@router.post("/install", response_model=MCPInstallationOut)
async def install_mcp(
    package: UploadFile,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """安装 MCP 包"""
    return await mcp_service.install_from_upload(
        db, package, current_user.id
    )


@router.post("/install-from-registry", response_model=MCPInstallationOut)
async def install_from_registry(
    data: MCPInstallFromRegistryIn,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """从市场安装 MCP"""
    return await mcp_service.install_from_registry(
        db, data.mcp_id, data.version, current_user.id
    )


@router.get("/installations", response_model=list[MCPInstallationOut])
async def list_installations(
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """列出已安装的 MCP"""
    return await mcp_service.list_installations(db)


@router.patch("/installations/{installation_id}")
async def update_installation(
    installation_id: UUID,
    data: MCPInstallationUpdateIn,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """更新 MCP 安装配置"""
    return await mcp_service.update_installation(
        db, installation_id, data
    )


@router.delete("/installations/{installation_id}")
async def uninstall_mcp(
    installation_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """卸载 MCP"""
    await mcp_service.uninstall(db, installation_id)
    return {"message": "Uninstalled successfully"}


@router.post("/installations/{installation_id}/health-check")
async def health_check(
    installation_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """执行健康检查"""
    result = await mcp_service.health_check(db, installation_id)
    return result


@router.get("/agents/{agent_id}/bindings", response_model=list[AgentMCPBindingOut])
async def list_agent_bindings(
    agent_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """列出 Agent 的 MCP 绑定"""
    return await mcp_service.list_agent_bindings(db, agent_id)


@router.post("/agents/{agent_id}/bindings")
async def bind_mcp_to_agent(
    agent_id: UUID,
    data: AgentMCPBindingCreateIn,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """绑定 MCP 到 Agent"""
    return await mcp_service.bind_to_agent(db, agent_id, data)


@router.patch("/bindings/{binding_id}")
async def update_binding(
    binding_id: UUID,
    data: AgentMCPBindingUpdateIn,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """更新绑定配置"""
    return await mcp_service.update_binding(db, binding_id, data)


@router.delete("/bindings/{binding_id}")
async def unbind_mcp(
    binding_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_admin_user)
):
    """解绑 MCP"""
    await mcp_service.unbind(db, binding_id)
    return {"message": "Unbound successfully"}
```

### 6.2 用户接口（只读）

```python
# app/api/v1/mcp.py
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.api.deps import get_current_user
from app.schemas.mcp import MCPRegistryOut
from app.services.mcp_service import mcp_service


router = APIRouter(prefix="/mcp", tags=["MCP"])


@router.get("/marketplace", response_model=list[MCPRegistryOut])
async def list_marketplace(
    category: Optional[str] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """浏览 MCP 市场（用户只读）"""
    return await mcp_service.list_registry(
        db, category=category, search=search
    )


@router.get("/marketplace/{mcp_id}")
async def get_mcp_detail(
    mcp_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """查看 MCP 详情"""
    return await mcp_service.get_registry_detail(db, mcp_id)
```

### 6.3 Agent 运行时接口（内部）

```python
# app/services/agent_runtime.py
from app.mcp.manager import mcp_manager


class AgentRuntime:
    """Agent 运行时"""

    async def get_available_tools(
        self,
        db: AsyncSession,
        agent_id: UUID
    ) -> list[Dict]:
        """获取 Agent 可用的所有工具（包括 MCP）"""
        # 获取内置工具
        builtin_tools = self._get_builtin_tools()

        # 获取 MCP 工具
        mcp_tools = await mcp_manager.get_available_tools(db, agent_id)

        return builtin_tools + mcp_tools

    async def call_tool(
        self,
        db: AsyncSession,
        session_id: UUID,
        agent_id: UUID,
        tool_name: str,
        arguments: Dict
    ) -> Dict:
        """调用工具（内置或 MCP）"""
        # 检查是否是 MCP 工具
        if "_installation_id" in arguments:
            installation_id = UUID(arguments.pop("_installation_id"))

            return await mcp_manager.call_tool(
                db=db,
                agent_id=agent_id,
                session_id=session_id,
                installation_id=installation_id,
                tool_name=tool_name,
                arguments=arguments
            )
        else:
            # 调用内置工具
            return await self._call_builtin_tool(tool_name, arguments)
```

---

## 7. 最小运行配置

### 7.1 环境变量

```bash
# .env
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/alice_home

# MCP 配置
MCP_INSTALL_DIR=/var/alice/mcp_installations
MCP_ENABLED=true

# 文件搜索 MCP 允许路径
ALLOWED_SEARCH_PATHS=/data/documents:/home/user/workspace
```

### 7.2 初始化脚本

```python
# scripts/init_builtin_mcps.py
"""初始化内置 MCP 工具"""
import asyncio
from app.database import async_session
from app.models import MCPRegistry, MCPVersion, MCPInstallation


async def init_builtin_mcps():
    async with async_session() as db:
        # 1. RAG MCP
        rag_registry = MCPRegistry(
            mcp_id="com.alice.rag",
            name="RAG Knowledge Base",
            description="Search and retrieve documents from RAG knowledge base",
            author="Alice Team",
            category="knowledge",
            is_builtin=True,
            is_official=True,
            latest_version="1.0.0"
        )
        db.add(rag_registry)

        rag_version = MCPVersion(
            mcp_id="com.alice.rag",
            version="1.0.0",
            mcp_config={
                "command": "python",
                "args": ["-m", "builtin_mcps.rag.server"],
                "env": {"DATABASE_URL": "${ALICE_DATABASE_URL}"},
                "transport": "stdio",
                "capabilities": {"tools": True}
            },
            status="active"
        )
        db.add(rag_version)
        await db.flush()

        rag_installation = MCPInstallation(
            mcp_id="com.alice.rag",
            version_id=rag_version.id,
            installation_path="/builtin/rag",
            is_enabled=True,
            status="installed"
        )
        db.add(rag_installation)

        # 2. Memory MCP
        memory_registry = MCPRegistry(
            mcp_id="com.alice.memory",
            name="Enterprise Memory",
            description="Store and recall organizational memories",
            author="Alice Team",
            category="memory",
            is_builtin=True,
            is_official=True,
            latest_version="1.0.0"
        )
        db.add(memory_registry)

        memory_version = MCPVersion(
            mcp_id="com.alice.memory",
            version="1.0.0",
            mcp_config={
                "command": "python",
                "args": ["-m", "builtin_mcps.memory.server"],
                "env": {"DATABASE_URL": "${ALICE_DATABASE_URL}"},
                "transport": "stdio",
                "capabilities": {"tools": True}
            },
            status="active"
        )
        db.add(memory_version)
        await db.flush()

        memory_installation = MCPInstallation(
            mcp_id="com.alice.memory",
            version_id=memory_version.id,
            installation_path="/builtin/memory",
            is_enabled=True,
            status="installed"
        )
        db.add(memory_installation)

        # 3. File Search MCP
        file_search_registry = MCPRegistry(
            mcp_id="com.alice.file-search",
            name="File Search",
            description="Search and read local files",
            author="Alice Team",
            category="search",
            is_builtin=True,
            is_official=True,
            latest_version="1.0.0"
        )
        db.add(file_search_registry)

        file_search_version = MCPVersion(
            mcp_id="com.alice.file-search",
            version="1.0.0",
            mcp_config={
                "command": "python",
                "args": ["-m", "builtin_mcps.file_search.server"],
                "env": {
                    "ALLOWED_SEARCH_PATHS": "${ALLOWED_SEARCH_PATHS}"
                },
                "transport": "stdio",
                "capabilities": {"tools": True}
            },
            status="active"
        )
        db.add(file_search_version)
        await db.flush()

        file_search_installation = MCPInstallation(
            mcp_id="com.alice.file-search",
            version_id=file_search_version.id,
            installation_path="/builtin/file_search",
            is_enabled=True,
            status="installed"
        )
        db.add(file_search_installation)

        await db.commit()
        print("Built-in MCPs initialized successfully")


if __name__ == "__main__":
    asyncio.run(init_builtin_mcps())
```

### 7.3 启动流程

```python
# app/main.py
from fastapi import FastAPI
from contextlib import asynccontextmanager

from app.mcp.manager import mcp_manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时
    print("Alice Home starting...")

    # 无需预连接 MCP（懒加载）

    yield

    # 关闭时
    print("Alice Home shutting down...")
    await mcp_manager.disconnect_all()


app = FastAPI(lifespan=lifespan)
```

---

## 8. 开发计划

### 8.1 Phase 1: 核心基础设施（2周）

- [ ] 数据库表设计与迁移
- [ ] MCP Client 基类实现
- [ ] Stdio Transport 实现
- [ ] MCP Manager 实现
- [ ] 基础异常处理

### 8.2 Phase 2: 安装与管理（1周）

- [ ] .mcppkg 包格式定义
- [ ] MCP Installer 实现
- [ ] 管理员 API 接口
- [ ] 健康检查机制

### 8.3 Phase 3: 内置 MCP 工具（2周）

- [ ] RAG MCP 实现
- [ ] Memory MCP 实现
- [ ] File Search MCP 实现
- [ ] 内置工具初始化脚本

### 8.4 Phase 4: Agent 集成（1周）

- [ ] Agent Runtime 集成 MCP
- [ ] Tool Discovery 与调用
- [ ] 调用日志记录
- [ ] 权限与限流控制

### 8.5 Phase 5: 市场与生态（1周）

- [ ] MCP Registry 浏览界面
- [ ] 用户只读市场接口
- [ ] 第三方 MCP 上传审核
- [ ] SSE Transport 实现（可选）

### 8.6 Phase 6: 测试与优化（1周）

- [ ] 单元测试
- [ ] 集成测试
- [ ] 性能优化
- [ ] 文档完善

---

## 9. 测试用例

### 9.1 MCP Client 测试

```python
# tests/test_mcp_client.py
import pytest
from app.mcp.transports.stdio import StdioMCPClient


@pytest.mark.asyncio
async def test_stdio_client_connect():
    """测试 Stdio Client 连接"""
    config = {
        "command": "python",
        "args": ["-m", "tests.fixtures.echo_mcp_server"],
        "transport": "stdio"
    }

    client = StdioMCPClient("test-install", config)

    try:
        await client.connect()
        assert client.is_connected

        # 测试工具列表
        tools = await client.list_tools()
        assert len(tools) > 0

        # 测试工具调用
        result = await client.call_tool(
            "echo",
            {"message": "Hello MCP"}
        )
        assert "Hello MCP" in str(result)

    finally:
        await client.disconnect()


@pytest.mark.asyncio
async def test_tool_call_timeout():
    """测试工具调用超时"""
    config = {
        "command": "python",
        "args": ["-m", "tests.fixtures.slow_mcp_server"],
        "transport": "stdio"
    }

    client = StdioMCPClient("test-install", config)

    try:
        await client.connect()

        with pytest.raises(MCPTimeoutError):
            await client.call_tool(
                "slow_operation",
                {"delay": 100},
                timeout=1
            )
    finally:
        await client.disconnect()
```

### 9.2 MCP Manager 测试

```python
# tests/test_mcp_manager.py
import pytest
from app.mcp.manager import mcp_manager


@pytest.mark.asyncio
async def test_get_available_tools(db_session, test_agent):
    """测试获取可用工具"""
    tools = await mcp_manager.get_available_tools(
        db_session,
        test_agent.id
    )

    assert len(tools) > 0
    assert any(t["name"] == "search_knowledge" for t in tools)


@pytest.mark.asyncio
async def test_call_tool(db_session, test_agent, test_session):
    """测试调用工具"""
    result = await mcp_manager.call_tool(
        db=db_session,
        agent_id=test_agent.id,
        session_id=test_session.id,
        installation_id=test_installation.id,
        tool_name="search_knowledge",
        arguments={"query": "test query", "limit": 5}
    )

    assert "results" in result
```

### 9.3 MCP Installer 测试

```python
# tests/test_installer.py
import pytest
from pathlib import Path
from app.mcp.installer import MCPInstaller


@pytest.mark.asyncio
async def test_install_from_package(db_session, test_admin_user, tmp_path):
    """测试从包安装"""
    installer = MCPInstaller(tmp_path)

    package_path = Path("tests/fixtures/test-mcp-1.0.0.mcppkg")

    installation = await installer.install_from_package(
        db_session,
        package_path,
        test_admin_user.id
    )

    assert installation.status == "installed"
    assert installation.is_enabled


@pytest.mark.asyncio
async def test_uninstall(db_session, test_installation):
    """测试卸载"""
    installer = MCPInstaller(Path("/tmp/mcp"))

    await installer.uninstall(db_session, test_installation.id)

    # 验证记录已删除
    result = await db_session.execute(
        select(MCPInstallation).where(MCPInstallation.id == test_installation.id)
    )
    assert result.scalar_one_or_none() is None
```

### 9.4 集成测试

```python
# tests/integration/test_agent_mcp_integration.py
import pytest
from app.services.agent_runtime import AgentRuntime


@pytest.mark.asyncio
async def test_agent_uses_mcp_tool(db_session, test_agent, test_session):
    """测试 Agent 使用 MCP 工具"""
    runtime = AgentRuntime()

    # 获取工具列表
    tools = await runtime.get_available_tools(db_session, test_agent.id)

    # 验证 MCP 工具存在
    rag_tool = next(t for t in tools if t["name"] == "search_knowledge")
    assert rag_tool

    # 调用工具
    result = await runtime.call_tool(
        db=db_session,
        session_id=test_session.id,
        agent_id=test_agent.id,
        tool_name="search_knowledge",
        arguments={
            "_installation_id": str(test_rag_installation.id),
            "query": "machine learning",
            "limit": 3
        }
    )

    assert "results" in result
    assert len(result["results"]) <= 3
```

---

## 10. 总结

### 10.1 核心特性

1. **标准化协议**：完全基于 MCP 协议，确保互操作性
2. **安全隔离**：每个 MCP 工具运行在独立进程，故障不影响主系统
3. **灵活配置**：支持环境变量注入、自定义配置
4. **热插拔**：运行时安装、启用、禁用 MCP 工具
5. **权限管理**：管理员管理、用户使用的清晰分离
6. **可观测性**：完整的调用日志、健康检查机制

### 10.2 技术优势

- **异步架构**：基于 asyncio，高并发性能
- **Stdio 优先**：简单可靠，适合大多数场景
- **懒加载**：按需连接 MCP Server，节省资源
- **错误恢复**：连接断开自动重连
- **超时控制**：防止工具调用阻塞

### 10.3 扩展方向

1. **MCP 市场**：构建完整的第三方 MCP 生态
2. **资源管理**：支持 MCP Resources 协议
3. **Prompt 模板**：支持 MCP Prompts 协议
4. **版本管理**：MCP 工具的升级、降级、回滚
5. **分布式部署**：MCP Server 远程部署（SSE）
6. **可视化配置**：Web UI 管理 MCP

### 10.4 参考资源

- MCP 官方文档: https://modelcontextprotocol.io
- MCP Python SDK: https://github.com/anthropics/mcp-python-sdk
- MCP 规范: https://spec.modelcontextprotocol.io

---

**文档版本**: v2.0
**最后更新**: 2025-12-03
**作者**: Alice Development Team
