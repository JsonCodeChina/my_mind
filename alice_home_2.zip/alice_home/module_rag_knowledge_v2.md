# Alice Home - RAG 知识库模块实现方案 V2

## 1. 模块概述

### 1.1 模块定位

RAG（Retrieval-Augmented Generation）知识库模块是 Alice Home 的扩展功能模块，为 Agent 提供知识增强能力。该模块既可作为内置功能使用，也可被 MCP 工具替换。

### 1.2 核心原则

- **灵活扩展**：可作为内置功能，也支持 MCP 工具替换
- **双权限管理**：管理员配置系统，普通用户管理自己的知识库
- **多格式支持**：PDF, Word, Markdown, TXT 等常见文档格式
- **智能检索**：混合检索策略（BM25 + Vector + Reranker）
- **可配置性**：支持多种 Embedding 模型和向量数据库

### 1.3 RAG 原理

```
文档上传
   │
   ▼
┌──────────────────────┐
│   文档解析           │
│   (PDF/Word/MD/TXT)  │
└──────────────────────┘
   │
   ▼
┌──────────────────────┐
│   智能分块           │
│   - 按段落分块        │
│   - 重叠窗口          │
│   - 保留上下文        │
└──────────────────────┘
   │
   ▼
┌──────────────────────┐
│   向量化 (Embedding) │
│   - Sentence Trans.  │
│   - OpenAI Embedding │
│   - 自定义模型        │
└──────────────────────┘
   │
   ▼
┌──────────────────────┐
│   向量存储           │
│   - Qdrant           │
│   - Milvus           │
│   - PGVector         │
└──────────────────────┘

检索过程：
用户查询
   │
   ├──> BM25 关键词检索 ──┐
   │                      │
   └──> Vector 向量检索 ──┤
                          │
                          ▼
                    ┌──────────────┐
                    │  混合排序     │
                    │  (RRF)       │
                    └──────────────┘
                          │
                          ▼
                    ┌──────────────┐
                    │  Reranker    │
                    │  重排序       │
                    └──────────────┘
                          │
                          ▼
                    返回 Top-K 结果
                          │
                          ▼
                    注入 Agent 上下文
```

### 1.4 技术栈

- **后端框架**：FastAPI 0.104+
- **数据库**：PostgreSQL 14+ (元数据), Qdrant/Milvus (向量数据库)
- **文档解析**：
  - PDF: PyMuPDF (fitz) / pdfplumber
  - Word: python-docx
  - Markdown: markdown-it-py
  - TXT: 内置 Python
- **Embedding**：
  - Sentence Transformers (本地模型)
  - OpenAI Embeddings API
  - HuggingFace Embeddings
- **检索框架**：LangChain 0.1+ / LlamaIndex 0.9+
- **Reranker**：Cross-Encoder Models
- **任务队列**：Celery + Redis (异步处理大文件)

---

## 2. 数据库设计

### 2.1 核心表结构

#### knowledge_bases 表（知识库）

```sql
CREATE TABLE knowledge_bases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,

    -- 所有者
    owner_id UUID NOT NULL,
    owner_type VARCHAR(20) NOT NULL DEFAULT 'user',  -- 'user' 或 'system'

    -- 配置
    embedding_model VARCHAR(100) NOT NULL DEFAULT 'sentence-transformers/all-MiniLM-L6-v2',
    vector_dimension INTEGER NOT NULL DEFAULT 384,
    chunk_size INTEGER NOT NULL DEFAULT 500,
    chunk_overlap INTEGER NOT NULL DEFAULT 50,

    -- 向量数据库配置
    vector_store_type VARCHAR(50) NOT NULL DEFAULT 'qdrant',  -- 'qdrant', 'milvus', 'pgvector'
    vector_store_config JSONB,  -- 连接配置

    -- 检索配置
    retrieval_config JSONB DEFAULT '{"top_k": 5, "score_threshold": 0.7, "rerank": true}',

    -- 统计信息
    document_count INTEGER DEFAULT 0,
    chunk_count INTEGER DEFAULT 0,
    total_size_bytes BIGINT DEFAULT 0,

    -- 状态
    is_enabled BOOLEAN DEFAULT TRUE,

    -- 审计字段
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- 约束
    CONSTRAINT knowledge_bases_owner_fkey FOREIGN KEY (owner_id)
        REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT valid_owner_type CHECK (owner_type IN ('user', 'system')),
    CONSTRAINT valid_vector_store CHECK (vector_store_type IN ('qdrant', 'milvus', 'pgvector'))
);

-- 索引
CREATE INDEX idx_kb_owner ON knowledge_bases(owner_id);
CREATE INDEX idx_kb_is_enabled ON knowledge_bases(is_enabled);
CREATE INDEX idx_kb_created_at ON knowledge_bases(created_at DESC);
```

#### documents 表（文档）

```sql
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    knowledge_base_id UUID NOT NULL,

    -- 文档基本信息
    filename VARCHAR(500) NOT NULL,
    original_filename VARCHAR(500) NOT NULL,
    file_type VARCHAR(50) NOT NULL,  -- 'pdf', 'docx', 'md', 'txt'
    mime_type VARCHAR(100),
    file_size_bytes BIGINT NOT NULL,

    -- 存储路径
    storage_path TEXT NOT NULL,  -- S3/MinIO 路径或本地路径
    storage_backend VARCHAR(50) DEFAULT 'local',  -- 'local', 's3', 'minio'

    -- 文档内容
    content_preview TEXT,  -- 前 500 字符预览
    total_chars INTEGER,
    total_chunks INTEGER DEFAULT 0,

    -- 解析状态
    parse_status VARCHAR(50) DEFAULT 'pending',  -- 'pending', 'parsing', 'completed', 'failed'
    parse_error TEXT,
    parsed_at TIMESTAMP,

    -- 向量化状态
    embedding_status VARCHAR(50) DEFAULT 'pending',  -- 'pending', 'processing', 'completed', 'failed'
    embedding_error TEXT,
    embedded_at TIMESTAMP,

    -- 元数据
    metadata JSONB DEFAULT '{}',  -- 自定义元数据（作者、标签等）

    -- 审计字段
    uploaded_by UUID NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- 约束
    CONSTRAINT documents_kb_fkey FOREIGN KEY (knowledge_base_id)
        REFERENCES knowledge_bases(id) ON DELETE CASCADE,
    CONSTRAINT documents_uploader_fkey FOREIGN KEY (uploaded_by)
        REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT valid_parse_status CHECK (
        parse_status IN ('pending', 'parsing', 'completed', 'failed')
    ),
    CONSTRAINT valid_embedding_status CHECK (
        embedding_status IN ('pending', 'processing', 'completed', 'failed')
    )
);

-- 索引
CREATE INDEX idx_doc_kb ON documents(knowledge_base_id);
CREATE INDEX idx_doc_uploader ON documents(uploaded_by);
CREATE INDEX idx_doc_parse_status ON documents(parse_status);
CREATE INDEX idx_doc_embedding_status ON documents(embedding_status);
CREATE INDEX idx_doc_created_at ON documents(created_at DESC);
```

#### document_chunks 表（文档分块）

```sql
CREATE TABLE document_chunks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL,
    knowledge_base_id UUID NOT NULL,

    -- 分块内容
    chunk_index INTEGER NOT NULL,  -- 在文档中的序号（从 0 开始）
    content TEXT NOT NULL,
    content_length INTEGER NOT NULL,

    -- 上下文信息
    previous_chunk_id UUID,  -- 上一个分块
    next_chunk_id UUID,      -- 下一个分块

    -- 位置信息（用于定位原文档）
    page_number INTEGER,  -- PDF 页码
    section_title TEXT,   -- 章节标题

    -- 向量 ID（在向量数据库中的 ID）
    vector_id VARCHAR(255),

    -- 元数据
    metadata JSONB DEFAULT '{}',

    -- 审计字段
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- 约束
    CONSTRAINT chunks_document_fkey FOREIGN KEY (document_id)
        REFERENCES documents(id) ON DELETE CASCADE,
    CONSTRAINT chunks_kb_fkey FOREIGN KEY (knowledge_base_id)
        REFERENCES knowledge_bases(id) ON DELETE CASCADE,
    CONSTRAINT chunks_prev_fkey FOREIGN KEY (previous_chunk_id)
        REFERENCES document_chunks(id) ON DELETE SET NULL,
    CONSTRAINT chunks_next_fkey FOREIGN KEY (next_chunk_id)
        REFERENCES document_chunks(id) ON DELETE SET NULL,
    UNIQUE (document_id, chunk_index)
);

-- 索引
CREATE INDEX idx_chunk_document ON document_chunks(document_id);
CREATE INDEX idx_chunk_kb ON document_chunks(knowledge_base_id);
CREATE INDEX idx_chunk_index ON document_chunks(document_id, chunk_index);
CREATE INDEX idx_chunk_vector_id ON document_chunks(vector_id);
```

#### rag_queries 表（检索查询日志）

```sql
CREATE TABLE rag_queries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    knowledge_base_id UUID NOT NULL,
    user_id UUID NOT NULL,

    -- 查询信息
    query_text TEXT NOT NULL,
    query_embedding_model VARCHAR(100),

    -- 检索参数
    top_k INTEGER DEFAULT 5,
    score_threshold DECIMAL(3, 2),
    use_reranker BOOLEAN DEFAULT TRUE,

    -- 检索结果
    result_count INTEGER,
    retrieved_chunk_ids UUID[],
    scores DECIMAL(5, 4)[],

    -- 性能指标
    retrieval_time_ms INTEGER,  -- 检索耗时（毫秒）
    rerank_time_ms INTEGER,     -- 重排序耗时（毫秒）

    -- 审计字段
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- 约束
    CONSTRAINT rag_queries_kb_fkey FOREIGN KEY (knowledge_base_id)
        REFERENCES knowledge_bases(id) ON DELETE CASCADE,
    CONSTRAINT rag_queries_user_fkey FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
);

-- 索引
CREATE INDEX idx_query_kb ON rag_queries(knowledge_base_id);
CREATE INDEX idx_query_user ON rag_queries(user_id);
CREATE INDEX idx_query_created_at ON rag_queries(created_at DESC);
```

### 2.2 初始化数据

#### 系统默认知识库

```sql
-- 创建系统默认知识库（可选，用于存放公共文档）
INSERT INTO knowledge_bases (
    name,
    description,
    owner_id,
    owner_type,
    embedding_model,
    vector_dimension,
    chunk_size,
    chunk_overlap,
    vector_store_type
) VALUES (
    'System Knowledge Base',
    'Alice Home system documentation and common knowledge',
    (SELECT id FROM users WHERE role = 'admin' LIMIT 1),
    'system',
    'sentence-transformers/all-MiniLM-L6-v2',
    384,
    500,
    50,
    'qdrant'
);
```

---

## 3. 核心功能实现

### 3.1 文档上传与解析

#### 文档上传 API

```python
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from typing import Optional
import uuid
import os
import aiofiles

router = APIRouter(prefix="/api/v1/rag", tags=["RAG Knowledge Base"])

# 支持的文件类型
ALLOWED_MIME_TYPES = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "text/markdown": "md",
    "text/plain": "txt"
}

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB


@router.post("/knowledge-bases/{kb_id}/documents/upload")
async def upload_document(
    kb_id: str,
    file: UploadFile = File(...),
    metadata: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    """
    上传文档到知识库

    Args:
        kb_id: 知识库 ID
        file: 上传的文件
        metadata: 自定义元数据（JSON 字符串）

    Returns:
        document: 文档信息
    """
    async with get_db() as db:
        # 1. 验证知识库存在且用户有权限
        kb = await db.fetch_one(
            """SELECT * FROM knowledge_bases
               WHERE id = $1 AND (owner_id = $2 OR owner_type = 'system')""",
            kb_id, current_user["id"]
        )
        if not kb:
            raise HTTPException(
                status_code=404,
                detail="Knowledge base not found or access denied"
            )

        # 2. 验证文件类型
        if file.content_type not in ALLOWED_MIME_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type. Allowed: {list(ALLOWED_MIME_TYPES.keys())}"
            )

        # 3. 验证文件大小
        file_content = await file.read()
        file_size = len(file_content)
        if file_size > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"File too large. Max size: {MAX_FILE_SIZE / (1024*1024)}MB"
            )

        # 4. 生成存储路径
        file_type = ALLOWED_MIME_TYPES[file.content_type]
        file_id = str(uuid.uuid4())
        storage_path = f"uploads/{kb_id}/{file_id}.{file_type}"

        # 5. 保存文件
        os.makedirs(os.path.dirname(storage_path), exist_ok=True)
        async with aiofiles.open(storage_path, 'wb') as f:
            await f.write(file_content)

        # 6. 创建文档记录
        doc_id = await db.fetch_val(
            """INSERT INTO documents (
                knowledge_base_id, filename, original_filename, file_type,
                mime_type, file_size_bytes, storage_path, storage_backend,
                uploaded_by, parse_status, embedding_status, metadata
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            RETURNING id""",
            kb_id, file_id, file.filename, file_type, file.content_type,
            file_size, storage_path, "local", current_user["id"],
            "pending", "pending", metadata or "{}"
        )

        # 7. 触发异步解析任务
        from tasks.rag import parse_and_embed_document
        parse_and_embed_document.delay(str(doc_id))

        return {
            "id": str(doc_id),
            "filename": file.filename,
            "file_type": file_type,
            "file_size_bytes": file_size,
            "status": "pending",
            "message": "Document uploaded. Parsing in progress..."
        }
```

#### 文档解析器

```python
from abc import ABC, abstractmethod
from typing import List, Dict
import PyMuPDF as fitz  # PyMuPDF
import pdfplumber
from docx import Document as DocxDocument
import markdown

class DocumentParser(ABC):
    """文档解析器基类"""

    @abstractmethod
    async def parse(self, file_path: str) -> Dict:
        """
        解析文档

        Args:
            file_path: 文件路径

        Returns:
            Dict: {
                "text": str,  # 提取的文本
                "metadata": Dict,  # 元数据
                "sections": List[Dict]  # 章节信息（可选）
            }
        """
        pass


class PDFParser(DocumentParser):
    """PDF 文档解析器"""

    async def parse(self, file_path: str) -> Dict:
        """使用 PyMuPDF 解析 PDF"""
        text_parts = []
        sections = []

        # 打开 PDF
        doc = fitz.open(file_path)

        metadata = {
            "page_count": len(doc),
            "title": doc.metadata.get("title", ""),
            "author": doc.metadata.get("author", ""),
            "subject": doc.metadata.get("subject", ""),
            "keywords": doc.metadata.get("keywords", "")
        }

        # 逐页提取文本
        for page_num, page in enumerate(doc, start=1):
            page_text = page.get_text()
            text_parts.append(page_text)

            sections.append({
                "type": "page",
                "page_number": page_num,
                "content": page_text
            })

        doc.close()

        return {
            "text": "\n\n".join(text_parts),
            "metadata": metadata,
            "sections": sections
        }


class WordParser(DocumentParser):
    """Word 文档解析器"""

    async def parse(self, file_path: str) -> Dict:
        """使用 python-docx 解析 Word"""
        doc = DocxDocument(file_path)

        text_parts = []
        sections = []

        # 提取段落
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                text_parts.append(text)

                # 检测标题（根据样式）
                if para.style.name.startswith("Heading"):
                    sections.append({
                        "type": "heading",
                        "level": int(para.style.name.replace("Heading ", "")),
                        "content": text
                    })

        metadata = {
            "paragraph_count": len(doc.paragraphs),
            "title": doc.core_properties.title or "",
            "author": doc.core_properties.author or "",
            "created": str(doc.core_properties.created) if doc.core_properties.created else ""
        }

        return {
            "text": "\n\n".join(text_parts),
            "metadata": metadata,
            "sections": sections
        }


class MarkdownParser(DocumentParser):
    """Markdown 文档解析器"""

    async def parse(self, file_path: str) -> Dict:
        """解析 Markdown"""
        with open(file_path, 'r', encoding='utf-8') as f:
            md_text = f.read()

        # 转换为 HTML（用于提取结构）
        html = markdown.markdown(md_text)

        # 提取标题
        sections = []
        import re
        headers = re.findall(r'^(#{1,6})\s+(.+)$', md_text, re.MULTILINE)
        for level, title in headers:
            sections.append({
                "type": "heading",
                "level": len(level),
                "content": title
            })

        metadata = {
            "format": "markdown",
            "header_count": len(sections)
        }

        return {
            "text": md_text,
            "metadata": metadata,
            "sections": sections
        }


class TxtParser(DocumentParser):
    """纯文本解析器"""

    async def parse(self, file_path: str) -> Dict:
        """解析纯文本"""
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()

        metadata = {
            "format": "plain_text",
            "char_count": len(text),
            "line_count": text.count('\n')
        }

        return {
            "text": text,
            "metadata": metadata,
            "sections": []
        }


# 解析器工厂
def get_parser(file_type: str) -> DocumentParser:
    """根据文件类型返回对应的解析器"""
    parsers = {
        "pdf": PDFParser(),
        "docx": WordParser(),
        "md": MarkdownParser(),
        "txt": TxtParser()
    }
    return parsers.get(file_type)
```

### 3.2 智能分块策略

```python
from typing import List, Dict
import re

class TextChunker:
    """文本分块器"""

    def __init__(
        self,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        separators: List[str] = None
    ):
        """
        初始化分块器

        Args:
            chunk_size: 每个分块的最大字符数
            chunk_overlap: 相邻分块的重叠字符数
            separators: 分割符优先级列表
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or [
            "\n\n\n",  # 多个空行
            "\n\n",    # 段落分隔
            "\n",      # 单行
            "。",      # 中文句号
            ". ",      # 英文句号
            "！",      # 中文感叹号
            "! ",      # 英文感叹号
            "？",      # 中文问号
            "? ",      # 英文问号
            " ",       # 空格
            ""         # 最后兜底：按字符切分
        ]

    def chunk(self, text: str, metadata: Dict = None) -> List[Dict]:
        """
        将文本分块

        Args:
            text: 要分块的文本
            metadata: 元数据（会传递到每个分块）

        Returns:
            List[Dict]: 分块列表
        """
        chunks = []
        current_chunk = ""

        # 递归分割
        splits = self._split_text(text, self.separators)

        for split in splits:
            # 如果当前块 + 新文本超过限制
            if len(current_chunk) + len(split) > self.chunk_size:
                if current_chunk:
                    chunks.append(current_chunk.strip())

                    # 保留重叠部分
                    overlap_text = current_chunk[-self.chunk_overlap:] if len(current_chunk) > self.chunk_overlap else current_chunk
                    current_chunk = overlap_text + split
                else:
                    # 单个 split 太长，直接作为一个块
                    current_chunk = split
            else:
                current_chunk += split

        # 添加最后一个块
        if current_chunk:
            chunks.append(current_chunk.strip())

        # 构建结果
        result = []
        for idx, chunk_text in enumerate(chunks):
            result.append({
                "chunk_index": idx,
                "content": chunk_text,
                "content_length": len(chunk_text),
                "metadata": metadata or {}
            })

        return result

    def _split_text(self, text: str, separators: List[str]) -> List[str]:
        """递归分割文本"""
        if not separators:
            return [text]

        separator = separators[0]
        remaining_separators = separators[1:]

        if separator == "":
            # 最后兜底：按字符切分
            return [text[i:i+self.chunk_size] for i in range(0, len(text), self.chunk_size)]

        splits = text.split(separator)

        # 如果没有分割成功，尝试下一个分隔符
        if len(splits) == 1:
            return self._split_text(text, remaining_separators)

        # 保留分隔符
        result = []
        for i, split in enumerate(splits):
            if i < len(splits) - 1:
                result.append(split + separator)
            else:
                result.append(split)

        return result


# 使用示例
async def chunk_document(document_id: str, text: str, chunk_size: int, chunk_overlap: int):
    """
    对文档进行分块并存储

    Args:
        document_id: 文档 ID
        text: 文档文本
        chunk_size: 分块大小
        chunk_overlap: 重叠大小
    """
    chunker = TextChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = chunker.chunk(text)

    async with get_db() as db:
        # 获取知识库 ID
        doc = await db.fetch_one(
            "SELECT knowledge_base_id FROM documents WHERE id = $1",
            document_id
        )

        previous_chunk_id = None

        for chunk_data in chunks:
            # 插入分块
            chunk_id = await db.fetch_val(
                """INSERT INTO document_chunks (
                    document_id, knowledge_base_id, chunk_index,
                    content, content_length, previous_chunk_id, metadata
                ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id""",
                document_id, doc["knowledge_base_id"], chunk_data["chunk_index"],
                chunk_data["content"], chunk_data["content_length"],
                previous_chunk_id, chunk_data["metadata"]
            )

            # 更新上一个分块的 next_chunk_id
            if previous_chunk_id:
                await db.execute(
                    "UPDATE document_chunks SET next_chunk_id = $1 WHERE id = $2",
                    chunk_id, previous_chunk_id
                )

            previous_chunk_id = chunk_id

        # 更新文档统计
        await db.execute(
            """UPDATE documents
               SET total_chunks = $1, parse_status = 'completed', parsed_at = NOW()
               WHERE id = $2""",
            len(chunks), document_id
        )
```

### 3.3 向量化（Embedding）

```python
from abc import ABC, abstractmethod
from typing import List
import numpy as np
from sentence_transformers import SentenceTransformer
import openai

class EmbeddingModel(ABC):
    """Embedding 模型基类"""

    @abstractmethod
    async def embed(self, texts: List[str]) -> np.ndarray:
        """
        将文本转换为向量

        Args:
            texts: 文本列表

        Returns:
            np.ndarray: 向量矩阵，形状为 (len(texts), dimension)
        """
        pass

    @abstractmethod
    def get_dimension(self) -> int:
        """获取向量维度"""
        pass


class SentenceTransformerEmbedding(EmbeddingModel):
    """基于 Sentence Transformers 的 Embedding"""

    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        初始化模型

        Args:
            model_name: 模型名称
        """
        self.model = SentenceTransformer(model_name)
        self.dimension = self.model.get_sentence_embedding_dimension()

    async def embed(self, texts: List[str]) -> np.ndarray:
        """生成向量"""
        # 批量编码
        embeddings = self.model.encode(
            texts,
            batch_size=32,
            show_progress_bar=False,
            normalize_embeddings=True  # 归一化，便于余弦相似度计算
        )
        return embeddings

    def get_dimension(self) -> int:
        return self.dimension


class OpenAIEmbedding(EmbeddingModel):
    """基于 OpenAI API 的 Embedding"""

    def __init__(self, model: str = "text-embedding-3-small", api_key: str = None):
        """
        初始化 OpenAI Embedding

        Args:
            model: 模型名称
            api_key: API Key
        """
        self.model = model
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        openai.api_key = self.api_key

        # 维度映射
        dimensions = {
            "text-embedding-3-small": 1536,
            "text-embedding-3-large": 3072,
            "text-embedding-ada-002": 1536
        }
        self.dimension = dimensions.get(model, 1536)

    async def embed(self, texts: List[str]) -> np.ndarray:
        """生成向量"""
        response = await openai.Embedding.acreate(
            input=texts,
            model=self.model
        )

        embeddings = [item["embedding"] for item in response["data"]]
        return np.array(embeddings)

    def get_dimension(self) -> int:
        return self.dimension


# Embedding 管理器
class EmbeddingManager:
    """Embedding 管理器"""

    def __init__(self, model_name: str):
        """
        初始化管理器

        Args:
            model_name: 模型名称
        """
        self.model = self._load_model(model_name)

    def _load_model(self, model_name: str) -> EmbeddingModel:
        """加载 Embedding 模型"""
        if model_name.startswith("sentence-transformers/"):
            return SentenceTransformerEmbedding(model_name)
        elif model_name.startswith("text-embedding"):
            return OpenAIEmbedding(model_name)
        else:
            # 默认使用 Sentence Transformers
            return SentenceTransformerEmbedding(model_name)

    async def embed_chunks(self, chunks: List[Dict]) -> List[np.ndarray]:
        """
        对分块进行向量化

        Args:
            chunks: 分块列表

        Returns:
            List[np.ndarray]: 向量列表
        """
        texts = [chunk["content"] for chunk in chunks]
        embeddings = await self.model.embed(texts)
        return embeddings


# 异步任务：对文档分块进行向量化
async def embed_document_chunks(document_id: str):
    """
    对文档的所有分块进行向量化

    Args:
        document_id: 文档 ID
    """
    async with get_db() as db:
        # 获取文档和知识库配置
        doc = await db.fetch_one(
            """SELECT d.*, kb.embedding_model, kb.vector_store_type, kb.vector_store_config
               FROM documents d
               JOIN knowledge_bases kb ON d.knowledge_base_id = kb.id
               WHERE d.id = $1""",
            document_id
        )

        if not doc:
            raise ValueError(f"Document {document_id} not found")

        # 获取所有分块
        chunks = await db.fetch_all(
            """SELECT id, content FROM document_chunks
               WHERE document_id = $1
               ORDER BY chunk_index""",
            document_id
        )

        if not chunks:
            return

        # 初始化 Embedding 管理器
        embedding_mgr = EmbeddingManager(doc["embedding_model"])

        # 批量向量化
        chunk_data = [{"content": c["content"]} for c in chunks]
        embeddings = await embedding_mgr.embed_chunks(chunk_data)

        # 初始化向量存储
        vector_store = get_vector_store(
            doc["vector_store_type"],
            doc["vector_store_config"]
        )

        # 批量插入向量
        vector_ids = []
        for chunk, embedding in zip(chunks, embeddings):
            vector_id = await vector_store.insert(
                vector=embedding.tolist(),
                metadata={
                    "chunk_id": str(chunk["id"]),
                    "document_id": document_id,
                    "knowledge_base_id": str(doc["knowledge_base_id"]),
                    "content": chunk["content"]
                }
            )
            vector_ids.append(vector_id)

        # 更新分块的 vector_id
        for chunk, vector_id in zip(chunks, vector_ids):
            await db.execute(
                "UPDATE document_chunks SET vector_id = $1 WHERE id = $2",
                vector_id, chunk["id"]
            )

        # 更新文档状态
        await db.execute(
            """UPDATE documents
               SET embedding_status = 'completed', embedded_at = NOW()
               WHERE id = $1""",
            document_id
        )
```

### 3.4 向量存储（Qdrant/Milvus/PGVector）

```python
from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
import uuid

class VectorStore(ABC):
    """向量存储基类"""

    @abstractmethod
    async def create_collection(self, collection_name: str, dimension: int):
        """创建集合"""
        pass

    @abstractmethod
    async def insert(self, vector: List[float], metadata: Dict) -> str:
        """插入向量"""
        pass

    @abstractmethod
    async def search(
        self,
        query_vector: List[float],
        top_k: int = 5,
        score_threshold: float = 0.0,
        filter_conditions: Dict = None
    ) -> List[Dict]:
        """检索向量"""
        pass

    @abstractmethod
    async def delete(self, vector_ids: List[str]):
        """删除向量"""
        pass


class QdrantVectorStore(VectorStore):
    """Qdrant 向量存储"""

    def __init__(self, host: str = "localhost", port: int = 6333, collection_name: str = "alice_rag"):
        """
        初始化 Qdrant 客户端

        Args:
            host: Qdrant 服务地址
            port: Qdrant 端口
            collection_name: 集合名称
        """
        self.client = QdrantClient(host=host, port=port)
        self.collection_name = collection_name

    async def create_collection(self, collection_name: str, dimension: int):
        """创建集合"""
        self.collection_name = collection_name

        # 检查集合是否存在
        collections = self.client.get_collections().collections
        exists = any(c.name == collection_name for c in collections)

        if not exists:
            self.client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=dimension,
                    distance=Distance.COSINE
                )
            )

    async def insert(self, vector: List[float], metadata: Dict) -> str:
        """插入向量"""
        point_id = str(uuid.uuid4())

        self.client.upsert(
            collection_name=self.collection_name,
            points=[
                PointStruct(
                    id=point_id,
                    vector=vector,
                    payload=metadata
                )
            ]
        )

        return point_id

    async def search(
        self,
        query_vector: List[float],
        top_k: int = 5,
        score_threshold: float = 0.0,
        filter_conditions: Dict = None
    ) -> List[Dict]:
        """检索向量"""
        search_result = self.client.search(
            collection_name=self.collection_name,
            query_vector=query_vector,
            limit=top_k,
            score_threshold=score_threshold,
            query_filter=filter_conditions
        )

        results = []
        for hit in search_result:
            results.append({
                "id": hit.id,
                "score": hit.score,
                "metadata": hit.payload
            })

        return results

    async def delete(self, vector_ids: List[str]):
        """删除向量"""
        self.client.delete(
            collection_name=self.collection_name,
            points_selector=vector_ids
        )


# 向量存储工厂
def get_vector_store(store_type: str, config: Dict) -> VectorStore:
    """
    获取向量存储实例

    Args:
        store_type: 存储类型 ('qdrant', 'milvus', 'pgvector')
        config: 配置参数

    Returns:
        VectorStore: 向量存储实例
    """
    if store_type == "qdrant":
        return QdrantVectorStore(
            host=config.get("host", "localhost"),
            port=config.get("port", 6333),
            collection_name=config.get("collection_name", "alice_rag")
        )
    elif store_type == "milvus":
        # TODO: 实现 Milvus 集成
        raise NotImplementedError("Milvus integration coming soon")
    elif store_type == "pgvector":
        # TODO: 实现 PGVector 集成
        raise NotImplementedError("PGVector integration coming soon")
    else:
        raise ValueError(f"Unsupported vector store type: {store_type}")
```

### 3.5 检索与排序（BM25 + Vector）

```python
from typing import List, Dict
import numpy as np
from rank_bm25 import BM25Okapi
import jieba  # 中文分词

class HybridRetriever:
    """混合检索器（BM25 + Vector）"""

    def __init__(
        self,
        vector_store: VectorStore,
        embedding_model: EmbeddingModel,
        alpha: float = 0.5  # 向量检索权重（1-alpha 为 BM25 权重）
    ):
        """
        初始化混合检索器

        Args:
            vector_store: 向量存储
            embedding_model: Embedding 模型
            alpha: 向量检索权重（0-1）
        """
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.alpha = alpha
        self.bm25_index = None
        self.corpus = []
        self.corpus_ids = []

    async def build_bm25_index(self, chunks: List[Dict]):
        """
        构建 BM25 索引

        Args:
            chunks: 分块列表 [{"id": str, "content": str}, ...]
        """
        self.corpus = [chunk["content"] for chunk in chunks]
        self.corpus_ids = [chunk["id"] for chunk in chunks]

        # 分词（支持中英文）
        tokenized_corpus = []
        for text in self.corpus:
            # 简单的中英文混合分词
            tokens = list(jieba.cut(text))
            tokenized_corpus.append(tokens)

        # 构建 BM25 索引
        self.bm25_index = BM25Okapi(tokenized_corpus)

    async def retrieve(
        self,
        query: str,
        knowledge_base_id: str,
        top_k: int = 5,
        score_threshold: float = 0.7,
        use_reranker: bool = True
    ) -> List[Dict]:
        """
        混合检索

        Args:
            query: 查询文本
            knowledge_base_id: 知识库 ID
            top_k: 返回结果数量
            score_threshold: 分数阈值
            use_reranker: 是否使用 Reranker

        Returns:
            List[Dict]: 检索结果
        """
        # 1. 向量检索
        query_embedding = await self.embedding_model.embed([query])
        vector_results = await self.vector_store.search(
            query_vector=query_embedding[0].tolist(),
            top_k=top_k * 2,  # 获取更多候选
            score_threshold=score_threshold,
            filter_conditions={"knowledge_base_id": knowledge_base_id}
        )

        # 2. BM25 检索
        if self.bm25_index is None:
            # 如果索引未构建，从数据库加载
            async with get_db() as db:
                chunks = await db.fetch_all(
                    """SELECT id, content FROM document_chunks
                       WHERE knowledge_base_id = $1""",
                    knowledge_base_id
                )
                await self.build_bm25_index([dict(c) for c in chunks])

        query_tokens = list(jieba.cut(query))
        bm25_scores = self.bm25_index.get_scores(query_tokens)

        # 获取 Top-K BM25 结果
        bm25_top_indices = np.argsort(bm25_scores)[-top_k * 2:][::-1]
        bm25_results = [
            {
                "id": self.corpus_ids[idx],
                "score": bm25_scores[idx],
                "content": self.corpus[idx]
            }
            for idx in bm25_top_indices
        ]

        # 3. 融合结果（RRF - Reciprocal Rank Fusion）
        merged_results = self._reciprocal_rank_fusion(
            vector_results,
            bm25_results,
            k=60  # RRF 常数
        )

        # 4. 重排序（可选）
        if use_reranker:
            merged_results = await self._rerank(query, merged_results)

        # 5. 返回 Top-K
        return merged_results[:top_k]

    def _reciprocal_rank_fusion(
        self,
        vector_results: List[Dict],
        bm25_results: List[Dict],
        k: int = 60
    ) -> List[Dict]:
        """
        RRF 融合算法

        公式: RRF_score(d) = sum(1 / (k + rank_i(d)))
        """
        scores = {}

        # 向量检索分数
        for rank, result in enumerate(vector_results, start=1):
            chunk_id = result["metadata"]["chunk_id"]
            scores[chunk_id] = scores.get(chunk_id, 0) + self.alpha / (k + rank)

        # BM25 分数
        for rank, result in enumerate(bm25_results, start=1):
            chunk_id = result["id"]
            scores[chunk_id] = scores.get(chunk_id, 0) + (1 - self.alpha) / (k + rank)

        # 排序
        sorted_results = sorted(scores.items(), key=lambda x: x[1], reverse=True)

        # 构建结果
        result_map = {r["metadata"]["chunk_id"]: r for r in vector_results}
        result_map.update({r["id"]: r for r in bm25_results})

        merged = []
        for chunk_id, score in sorted_results:
            if chunk_id in result_map:
                result = result_map[chunk_id]
                merged.append({
                    "chunk_id": chunk_id,
                    "score": score,
                    "content": result.get("metadata", {}).get("content") or result.get("content"),
                    "metadata": result.get("metadata", {})
                })

        return merged

    async def _rerank(self, query: str, results: List[Dict]) -> List[Dict]:
        """
        使用 Cross-Encoder 重排序

        Args:
            query: 查询文本
            results: 候选结果

        Returns:
            List[Dict]: 重排序后的结果
        """
        from sentence_transformers import CrossEncoder

        # 加载 Cross-Encoder 模型
        reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')

        # 准备查询-文档对
        pairs = [[query, result["content"]] for result in results]

        # 计算相关性分数
        rerank_scores = reranker.predict(pairs)

        # 更新分数
        for result, score in zip(results, rerank_scores):
            result["rerank_score"] = float(score)

        # 重新排序
        results.sort(key=lambda x: x["rerank_score"], reverse=True)

        return results
```

### 3.6 检索 API

```python
@router.post("/knowledge-bases/{kb_id}/retrieve")
async def retrieve_knowledge(
    kb_id: str,
    query: str,
    top_k: int = 5,
    score_threshold: float = 0.7,
    use_reranker: bool = True,
    current_user: dict = Depends(get_current_user)
):
    """
    从知识库检索相关内容

    Args:
        kb_id: 知识库 ID
        query: 查询文本
        top_k: 返回结果数量
        score_threshold: 分数阈值
        use_reranker: 是否使用重排序

    Returns:
        results: 检索结果列表
    """
    import time

    async with get_db() as db:
        # 验证知识库权限
        kb = await db.fetch_one(
            """SELECT * FROM knowledge_bases
               WHERE id = $1 AND (owner_id = $2 OR owner_type = 'system')""",
            kb_id, current_user["id"]
        )
        if not kb:
            raise HTTPException(status_code=404, detail="Knowledge base not found")

        # 初始化检索器
        vector_store = get_vector_store(
            kb["vector_store_type"],
            kb["vector_store_config"]
        )
        embedding_model = EmbeddingManager(kb["embedding_model"]).model
        retriever = HybridRetriever(vector_store, embedding_model)

        # 执行检索
        start_time = time.time()
        results = await retriever.retrieve(
            query=query,
            knowledge_base_id=kb_id,
            top_k=top_k,
            score_threshold=score_threshold,
            use_reranker=use_reranker
        )
        retrieval_time = int((time.time() - start_time) * 1000)

        # 记录查询日志
        chunk_ids = [r["chunk_id"] for r in results]
        scores = [r.get("rerank_score", r["score"]) for r in results]

        await db.execute(
            """INSERT INTO rag_queries (
                knowledge_base_id, user_id, query_text, query_embedding_model,
                top_k, score_threshold, use_reranker, result_count,
                retrieved_chunk_ids, scores, retrieval_time_ms
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)""",
            kb_id, current_user["id"], query, kb["embedding_model"],
            top_k, score_threshold, use_reranker, len(results),
            chunk_ids, scores, retrieval_time
        )

        # 格式化返回结果
        formatted_results = []
        for r in results:
            # 获取分块详细信息
            chunk = await db.fetch_one(
                """SELECT dc.*, d.original_filename, d.file_type
                   FROM document_chunks dc
                   JOIN documents d ON dc.document_id = d.id
                   WHERE dc.id = $1""",
                r["chunk_id"]
            )

            formatted_results.append({
                "chunk_id": r["chunk_id"],
                "score": r.get("rerank_score", r["score"]),
                "content": r["content"],
                "document_filename": chunk["original_filename"],
                "document_type": chunk["file_type"],
                "chunk_index": chunk["chunk_index"],
                "page_number": chunk["page_number"]
            })

        return {
            "query": query,
            "result_count": len(results),
            "retrieval_time_ms": retrieval_time,
            "results": formatted_results
        }
```

---

## 4. Agent 调用 RAG

### 4.1 RAG 集成接口

```python
class RAGIntegration:
    """RAG 集成模块（供 Agent 调用）"""

    def __init__(self, knowledge_base_id: str, user_id: str):
        """
        初始化 RAG 集成

        Args:
            knowledge_base_id: 知识库 ID
            user_id: 用户 ID
        """
        self.kb_id = knowledge_base_id
        self.user_id = user_id
        self.retriever = None

    async def initialize(self):
        """初始化检索器"""
        async with get_db() as db:
            kb = await db.fetch_one(
                "SELECT * FROM knowledge_bases WHERE id = $1",
                self.kb_id
            )

            if not kb:
                raise ValueError(f"Knowledge base {self.kb_id} not found")

            # 初始化检索器
            vector_store = get_vector_store(
                kb["vector_store_type"],
                kb["vector_store_config"]
            )
            embedding_model = EmbeddingManager(kb["embedding_model"]).model
            self.retriever = HybridRetriever(vector_store, embedding_model)

    async def retrieve_context(
        self,
        query: str,
        top_k: int = 3,
        score_threshold: float = 0.7
    ) -> str:
        """
        检索相关上下文（返回纯文本）

        Args:
            query: 查询文本
            top_k: 返回结果数量
            score_threshold: 分数阈值

        Returns:
            str: 检索到的上下文（拼接后的文本）
        """
        if not self.retriever:
            await self.initialize()

        results = await self.retriever.retrieve(
            query=query,
            knowledge_base_id=self.kb_id,
            top_k=top_k,
            score_threshold=score_threshold,
            use_reranker=True
        )

        # 拼接上下文
        context_parts = []
        for idx, result in enumerate(results, start=1):
            context_parts.append(f"[文档片段 {idx}]\n{result['content']}\n")

        return "\n".join(context_parts)


# Agent 使用示例
class AliceChatAgentWithRAG(AgentExecutor):
    """集成 RAG 的 Alice Chat Agent"""

    def __init__(self, knowledge_base_id: Optional[str] = None):
        super().__init__(agent_card={...})
        self.knowledge_base_id = knowledge_base_id
        self.rag = None

    async def execute(
        self,
        message: Message,
        context_id: Optional[str] = None,
        task_id: Optional[str] = None
    ) -> Task:
        """执行任务（带 RAG）"""

        task = self.task_manager.create_task(message=message, context_id=context_id)

        try:
            task.transition_to(TaskState.WORKING)

            user_query = message.parts[0].text

            # 如果配置了知识库，先检索相关上下文
            rag_context = ""
            if self.knowledge_base_id:
                if not self.rag:
                    self.rag = RAGIntegration(
                        knowledge_base_id=self.knowledge_base_id,
                        user_id=task.metadata.get("user_id")
                    )
                    await self.rag.initialize()

                rag_context = await self.rag.retrieve_context(
                    query=user_query,
                    top_k=3,
                    score_threshold=0.7
                )

            # 构建 Prompt（注入 RAG 上下文）
            system_prompt = "你是 Alice Home 的智能助手。"
            if rag_context:
                system_prompt += f"\n\n请参考以下知识库内容回答用户问题：\n\n{rag_context}"

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query}
            ]

            # 调用 LLM
            response = await self.llm_client.chat_completion(
                messages=messages,
                model="gpt-4o-mini"
            )

            # 返回结果
            response_message = Message(
                role="agent",
                parts=[TextPart(text=response)]
            )
            task.message = response_message
            task.transition_to(TaskState.COMPLETED)

        except Exception as e:
            task.error = {"code": -32000, "message": str(e)}
            task.transition_to(TaskState.FAILED)

        return task
```

---

## 5. API 接口清单

### 5.1 知识库管理

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/rag/knowledge-bases` | 创建知识库 | 已登录 |
| GET | `/api/v1/rag/knowledge-bases` | 列出知识库 | 已登录 |
| GET | `/api/v1/rag/knowledge-bases/{kb_id}` | 获取知识库详情 | 所有者 |
| PUT | `/api/v1/rag/knowledge-bases/{kb_id}` | 更新知识库配置 | 所有者 |
| DELETE | `/api/v1/rag/knowledge-bases/{kb_id}` | 删除知识库 | 所有者 |

### 5.2 文档管理

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/rag/knowledge-bases/{kb_id}/documents/upload` | 上传文档 | 所有者 |
| GET | `/api/v1/rag/knowledge-bases/{kb_id}/documents` | 列出文档 | 所有者 |
| GET | `/api/v1/rag/documents/{doc_id}` | 获取文档详情 | 所有者 |
| DELETE | `/api/v1/rag/documents/{doc_id}` | 删除文档 | 所有者 |
| GET | `/api/v1/rag/documents/{doc_id}/chunks` | 获取文档分块 | 所有者 |

### 5.3 检索

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/rag/knowledge-bases/{kb_id}/retrieve` | 检索知识 | 所有者 |
| POST | `/api/v1/rag/knowledge-bases/{kb_id}/search` | 搜索文档 | 所有者 |
| GET | `/api/v1/rag/knowledge-bases/{kb_id}/stats` | 获取统计信息 | 所有者 |

### 5.4 管理员接口

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/api/v1/admin/rag/embedding-models` | 列出可用 Embedding 模型 | 管理员 |
| POST | `/api/v1/admin/rag/embedding-models` | 添加 Embedding 模型 | 管理员 |
| GET | `/api/v1/admin/rag/vector-stores` | 列出向量数据库配置 | 管理员 |
| POST | `/api/v1/admin/rag/vector-stores` | 添加向量数据库 | 管理员 |

---

## 6. 最小运行配置

### 6.1 环境依赖

```bash
# requirements.txt
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
sqlalchemy>=2.0.0
asyncpg>=0.29.0
pydantic>=2.0.0

# 文档解析
PyMuPDF>=1.23.0
pdfplumber>=0.10.0
python-docx>=1.1.0
markdown-it-py>=3.0.0

# Embedding 和检索
sentence-transformers>=2.2.0
openai>=1.0.0
qdrant-client>=1.7.0
rank-bm25>=0.2.2
jieba>=0.42.1

# 任务队列
celery>=5.3.0
redis>=5.0.0

# 工具库
aiofiles>=23.2.0
numpy>=1.24.0
```

### 6.2 Docker Compose 配置

```yaml
version: '3.8'

services:
  # PostgreSQL (元数据)
  postgres:
    image: postgres:14
    environment:
      POSTGRES_USER: alice
      POSTGRES_PASSWORD: password
      POSTGRES_DB: alice_home
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  # Qdrant (向量数据库)
  qdrant:
    image: qdrant/qdrant:v1.7.0
    ports:
      - "6333:6333"
      - "6334:6334"
    volumes:
      - qdrant_data:/qdrant/storage

  # Redis (任务队列)
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  # Alice Home API
  api:
    build: .
    command: uvicorn main:app --host 0.0.0.0 --port 8000
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://alice:password@postgres:5432/alice_home
      - QDRANT_HOST=qdrant
      - QDRANT_PORT=6333
      - REDIS_URL=redis://redis:6379/0
      - EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
    depends_on:
      - postgres
      - qdrant
      - redis
    volumes:
      - ./uploads:/app/uploads

  # Celery Worker (异步任务)
  celery-worker:
    build: .
    command: celery -A tasks.celery_app worker --loglevel=info
    environment:
      - DATABASE_URL=postgresql://alice:password@postgres:5432/alice_home
      - QDRANT_HOST=qdrant
      - QDRANT_PORT=6333
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - postgres
      - qdrant
      - redis
    volumes:
      - ./uploads:/app/uploads

volumes:
  postgres_data:
  qdrant_data:
```

### 6.3 初始化脚本

```python
# scripts/init_rag.py
import asyncio
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams

async def init_rag_system():
    """初始化 RAG 系统"""

    # 1. 初始化数据库表
    async with get_db() as db:
        print("Creating RAG tables...")
        # 执行 SQL 建表语句（略）

        # 检查是否已有系统知识库
        system_kb = await db.fetch_one(
            "SELECT id FROM knowledge_bases WHERE owner_type = 'system'"
        )

        if not system_kb:
            print("Creating system knowledge base...")
            await db.execute(
                """INSERT INTO knowledge_bases (
                    name, description, owner_id, owner_type,
                    embedding_model, vector_dimension, chunk_size, chunk_overlap,
                    vector_store_type, vector_store_config
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)""",
                "System Knowledge Base",
                "Alice Home system documentation",
                (await db.fetch_val("SELECT id FROM users WHERE role = 'admin' LIMIT 1")),
                "system",
                "sentence-transformers/all-MiniLM-L6-v2",
                384, 500, 50,
                "qdrant",
                '{"host": "localhost", "port": 6333, "collection_name": "alice_system_kb"}'
            )
            print("System knowledge base created.")

    # 2. 初始化 Qdrant 集合
    print("Initializing Qdrant collection...")
    client = QdrantClient(host="localhost", port=6333)

    collections = client.get_collections().collections
    if not any(c.name == "alice_system_kb" for c in collections):
        client.create_collection(
            collection_name="alice_system_kb",
            vectors_config=VectorParams(size=384, distance=Distance.COSINE)
        )
        print("Qdrant collection created.")
    else:
        print("Qdrant collection already exists.")

    print("RAG system initialization complete!")

if __name__ == "__main__":
    asyncio.run(init_rag_system())
```

---

## 7. 开发计划

### Phase 1: 基础功能（4 周）

**Week 1: 数据库和文档解析**
- 数据库表设计和迁移
- 文档上传 API
- PDF/Word/Markdown/TXT 解析器实现
- 文件存储（本地 + S3）

**Week 2: 分块和向量化**
- 智能分块策略实现
- Sentence Transformers 集成
- OpenAI Embeddings 集成
- Qdrant 向量存储集成

**Week 3: 检索功能**
- BM25 关键词检索
- 向量检索
- 混合检索（RRF）
- 基础检索 API

**Week 4: Agent 集成**
- RAGIntegration 接口实现
- Agent 调用 RAG 示例
- 单元测试和集成测试

### Phase 2: 高级功能（3 周）

**Week 5: Reranker 和优化**
- Cross-Encoder Reranker 集成
- 检索性能优化
- 分块策略优化
- 缓存机制

**Week 6: 任务队列**
- Celery 集成
- 异步文档处理
- 批量向量化
- 任务状态跟踪

**Week 7: 管理功能**
- 知识库管理 UI
- 文档管理 UI
- 统计和分析
- 日志和监控

### Phase 3: 扩展和优化（2 周）

**Week 8: 多向量数据库支持**
- Milvus 集成
- PGVector 集成
- 向量数据库选择器

**Week 9: 生产就绪**
- 性能压测
- 安全加固
- 完整文档
- 部署指南

**总计：9 周**

---

## 8. 测试用例

### 8.1 单元测试

```python
# tests/test_rag.py
import pytest
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_upload_document(client: AsyncClient, user_token: str):
    """测试文档上传"""
    # 创建知识库
    kb_response = await client.post(
        "/api/v1/rag/knowledge-bases",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "name": "Test KB",
            "description": "Test knowledge base"
        }
    )
    assert kb_response.status_code == 200
    kb_id = kb_response.json()["id"]

    # 上传文档
    with open("tests/fixtures/test.pdf", "rb") as f:
        response = await client.post(
            f"/api/v1/rag/knowledge-bases/{kb_id}/documents/upload",
            headers={"Authorization": f"Bearer {user_token}"},
            files={"file": ("test.pdf", f, "application/pdf")}
        )

    assert response.status_code == 200
    assert "id" in response.json()
    assert response.json()["status"] == "pending"


@pytest.mark.asyncio
async def test_retrieve_knowledge(client: AsyncClient, user_token: str):
    """测试知识检索"""
    # 假设已有知识库和文档
    kb_id = "existing_kb_id"

    response = await client.post(
        f"/api/v1/rag/knowledge-bases/{kb_id}/retrieve",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "query": "What is Alice Home?",
            "top_k": 3,
            "score_threshold": 0.7
        }
    )

    assert response.status_code == 200
    data = response.json()
    assert "results" in data
    assert len(data["results"]) <= 3
    assert data["retrieval_time_ms"] > 0


@pytest.mark.asyncio
async def test_text_chunking():
    """测试文本分块"""
    chunker = TextChunker(chunk_size=100, chunk_overlap=20)

    text = "This is a test document. " * 50  # 长文本
    chunks = chunker.chunk(text)

    assert len(chunks) > 1
    assert all(len(c["content"]) <= 120 for c in chunks)  # 允许稍微超出

    # 验证重叠
    for i in range(len(chunks) - 1):
        current_end = chunks[i]["content"][-20:]
        next_start = chunks[i + 1]["content"][:20]
        assert len(set(current_end) & set(next_start)) > 0  # 有重叠


@pytest.mark.asyncio
async def test_embedding():
    """测试向量化"""
    model = SentenceTransformerEmbedding()

    texts = ["Hello world", "This is a test"]
    embeddings = await model.embed(texts)

    assert embeddings.shape == (2, model.get_dimension())
    assert np.all(np.abs(embeddings) <= 1)  # 归一化后的向量
```

---

## 9. 总结

本文档详细描述了 Alice Home RAG 知识库模块的完整实现方案，涵盖以下核心功能：

### 核心特性

1. **多格式文档支持**：PDF, Word, Markdown, TXT
2. **智能分块**：基于段落和句子的智能分块策略，保留上下文
3. **灵活的 Embedding**：支持 Sentence Transformers 和 OpenAI Embeddings
4. **多种向量数据库**：Qdrant（默认）、Milvus、PGVector
5. **混合检索**：BM25 + 向量检索 + RRF 融合 + Reranker 重排序
6. **异步处理**：Celery 任务队列处理大文件
7. **权限管理**：管理员配置系统，用户管理自己的知识库
8. **Agent 集成**：简单的 API 接口供 Agent 调用

### 技术亮点

- **RAG 最佳实践**：结合关键词检索和向量检索，使用 RRF 融合和 Cross-Encoder 重排序
- **可扩展架构**：支持多种 Embedding 模型和向量数据库，易于扩展
- **生产就绪**：完整的错误处理、日志记录、性能监控
- **开箱即用**：提供 Docker Compose 配置和初始化脚本

### 下一步

- 集成到 Alice Home 核心系统
- 支持更多文档格式（Excel, PPT 等）
- 实现增量更新（文档修改后自动重新向量化）
- 支持多模态检索（图片、表格）
- 知识图谱集成（企业版）
