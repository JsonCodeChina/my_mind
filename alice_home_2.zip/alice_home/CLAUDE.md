# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Alice Home is an AI agent platform with a marketplace architecture. This is a **design documentation repository** containing technical specifications for 7 core modules. No production code exists yet - only comprehensive implementation plans.

**Core Architecture**: Single-tenant, Meta-Agent mechanism, dual marketplace (Agent + MCP tools)

## Repository Structure

This repository contains technical design documents, not code:

```
alice_home/
├── module_*_v2.md           # Module implementation specifications (7 modules)
├── *_architecture.drawio     # Architecture diagrams
├── *_flow_diagram.drawio     # User flow diagrams
└── alice_home_implementation_summary.md  # Complete project summary
```

## Key Design Documents

### Module Specifications (Read these first for new modules)

1. **module_user_permission_v2.md** (25KB) - User authentication & RBAC
   - JWT auth, dual-role (admin/user) permissions
   - PostgreSQL schema, API endpoints
   - Development: 4 weeks

2. **module_agent_core_v2.md** (52KB) - Agent lifecycle management
   - A2A protocol implementation
   - .alicepkg package format
   - Meta Agent mechanism
   - Development: 7 weeks

3. **module_mcp_tools_v2.md** (66KB) - MCP tool ecosystem
   - MCP protocol (stdio/SSE transport)
   - .mcppkg package format
   - Can replace built-in features (RAG, memory)
   - Development: 8 weeks

4. **module_rag_knowledge_v2.md** (57KB) - RAG knowledge base
   - Hybrid retrieval (BM25 + vector + reranker)
   - Qdrant/Milvus vector DB
   - Development: 9 weeks

5. **module_model_management_v2.md** (52KB) - LLM provider management
   - Multi-provider support (OpenAI, Anthropic, Azure, Ollama)
   - Unified interface via LiteLLM
   - Development: 6 weeks

6. **module_conversation_v2.md** (62KB) - Conversation management
   - MongoDB for short-term memory
   - WebSocket/SSE streaming
   - Context management
   - Development: 6 weeks

7. **module_billing_v2.md** (93KB) - Billing system
   - Usage tracking, quota management
   - Plan management, invoice generation
   - Development: 6 weeks

### Architecture Diagrams

- **system_architecture_v3.drawio** - Overall system architecture (left: base modules, right: Agent core)
- **user_flow_diagram_v2.drawio** - Admin vs User workflows, Agent+MCP marketplace
- **agent_core_architecture.drawio** - Agent SDK 3-layer architecture

### Summary Document

- **alice_home_implementation_summary.md** - Complete project overview, tech stack, development roadmap

## Core Design Principles

### Architecture
- **Single-tenant**: No multi-tenant isolation
- **Meta Agent**: Global default agent for new users
- **Dual Marketplace**: Separate Agent and MCP tool marketplaces
- **MCP Replaceability**: Built-in features (RAG, memory) can be replaced by MCP tools

### Technology Stack
- Backend: FastAPI 0.104+
- Databases: PostgreSQL 14+ (relational), MongoDB 6.0+ (conversations)
- Cache: Redis 7.0+
- Vector DB: Qdrant/Milvus
- Task Queue: Celery + Redis
- Containers: Docker + Kubernetes

### Permissions
- **Admin**: Configure everything (LLM, Agents, MCP tools)
- **User**: Use everything (conversations, switch agents, view marketplace)

## A2A Protocol (Agent-to-Agent)

All Agent implementations must follow A2A protocol:

- **Task States**: submitted → working → completed/failed/canceled
- **Message Format**: Supports text, file, image, tool_result
- **Agent Card**: JSON-RPC 2.0 endpoint descriptor
- **Transport**: JSON-RPC 2.0 (primary), gRPC (optional)

Refer to `module_agent_core_v2.md` section 2.2 for AgentExecutor base class.

## MCP Protocol (Model Context Protocol)

MCP tools extend Agent capabilities:

- **Package Format**: .mcppkg with manifest.json
- **Transport**: stdio (subprocess) or SSE (HTTP)
- **Tool Discovery**: JSON-RPC `tools/list` method
- **Tool Invocation**: JSON-RPC `tools/call` method
- **Binding**: Many-to-many relationship with Agents (agent_mcp_bindings table)

Refer to `module_mcp_tools_v2.md` section 3 for implementation details.

## Database Schemas

### PostgreSQL
- Users, roles, permissions
- Agent registry, versions, installations
- MCP registry, bindings
- LLM providers, models
- Billing, quotas, invoices

### MongoDB
- Conversations (metadata)
- Messages (A2A protocol format)
- Conversation summaries

### Redis
- Session cache
- Rate limiting
- Streaming message buffers

## Development Workflow (When Code Exists)

### Parallel Development Strategy
1. **Phase 1 (Week 1-4)**: User auth + Agent SDK
2. **Phase 2 (Week 5-12)**: Model management + Conversations + Agent marketplace
3. **Phase 3 (Week 13-20)**: MCP tools + RAG + Billing

### API Endpoints
- 96 total REST APIs across 7 modules
- 42 public endpoints (authenticated users)
- 52 admin endpoints (admin role required)
- 2 WebSocket/SSE endpoints

## Working with DrawIO Files

**Important Rule**: When generating or modifying .drawio files with stacked components, always group them using `<mxCell>` groups. This maintains visual hierarchy and editability.

Example structure:
```xml
<mxCell id="group-id" value="" style="group" vertex="1" connectable="0">
    <mxGeometry x="..." y="..." width="..." height="..." as="geometry"/>
</mxCell>
<mxCell id="child-1" parent="group-id" ...>
    ...
</mxCell>
```

## Meta Agent Mechanism

The Meta Agent is the system's default agent:
- Automatically assigned to new users on first login
- Admin can change which agent is the Meta Agent
- Stored in `agent_registry.is_meta_agent` (boolean flag)
- User's active agent stored in `users.active_agent_id`

## Common Patterns

### Agent Installation Flow (Admin)
1. Admin browses marketplace → selects agent
2. System downloads .alicepkg → validates signature
3. Extracts and registers in agent_registry
4. Admin enables agent → now visible to users

### Agent Switching Flow (User)
1. User views enabled agents in dropdown
2. Selects new agent
3. System validates availability + loads Agent Card
4. Updates user.active_agent_id
5. Optionally migrates conversation context

### MCP Tool Binding
1. Admin installs MCP tool from marketplace
2. Admin binds MCP to specific agent(s) via agent_mcp_bindings table
3. When agent executes, it can invoke bound MCP tools
4. MCP tools can replace built-in functionality (e.g., RAG, memory)

## Future Implementation Notes

When implementing code:
- Use async/await throughout (asyncio, asyncpg, motor)
- Follow Pydantic models from module specs for API schemas
- Implement proper error handling and logging
- Write unit tests alongside features (pytest + pytest-asyncio)
- Use Docker Compose for local development
- Follow database schemas exactly as specified in module docs

## Next Steps for Development

1. Review `alice_home_implementation_summary.md` for complete overview
2. Set up development environment (Docker Compose with Postgres, MongoDB, Redis, Qdrant)
3. Start with `module_user_permission_v2.md` (foundation)
4. Implement `module_agent_core_v2.md` SDK in parallel
5. Follow phased development plan in summary document
