# Alice Home 计费系统模块实现方案 v2

## 1. 模块概述

### 1.1 设计理念

Alice Home 计费系统是一个灵活、可扩展的计费解决方案，旨在：

- **精确计量**：准确跟踪 API 调用次数、Token 消耗、存储空间等资源使用
- **灵活计费**：支持多种计费模式（按量付费、套餐订阅、混合模式）
- **实时监控**：提供实时用量监控和成本预警
- **配额管理**：支持灵活的配额设置和限流策略
- **自动化账单**：自动生成账单、发票，支持多种支付方式
- **透明可审计**：完整的使用记录和账单历史

### 1.2 核心特性

- 多维度计费（用户、Agent、LLM 模型）
- 实时用量统计和成本计算
- 灵活的套餐管理系统
- 配额限制和软/硬限流
- 自动账单生成和发送
- 支付集成（Stripe、支付宝）
- 成本预警和通知
- 详细的使用报告

### 1.3 技术栈

```yaml
Backend:
  - FastAPI: Web 框架
  - SQLAlchemy: ORM
  - Pydantic: 数据验证

Database:
  - PostgreSQL: 主数据库
  - Redis: 缓存和限流

Task Queue:
  - Celery: 异步任务
  - Redis: 消息代理

Payment:
  - Stripe SDK: 国际支付
  - Alipay SDK: 国内支付

Monitoring:
  - Prometheus: 指标收集
  - Grafana: 可视化

Testing:
  - Pytest: 单元测试
  - Factory Boy: 测试数据生成
```

---

## 2. 数据库设计

### 2.1 ER 图

```
┌─────────────────┐       ┌──────────────────┐       ┌─────────────────┐
│  billing_plans  │◄──────│user_subscriptions│──────►│      users      │
└─────────────────┘       └──────────────────┘       └─────────────────┘
                                    │
                                    │
                                    ▼
                          ┌─────────────────┐
                          │  usage_records  │
                          └─────────────────┘
                                    │
                                    │
                                    ▼
                          ┌─────────────────┐
                          │    invoices     │
                          └─────────────────┘
                                    │
                                    │
                                    ▼
                          ┌─────────────────┐
                          │invoice_line_items│
                          └─────────────────┘

┌─────────────────┐       ┌─────────────────┐
│  quota_limits   │       │ payment_methods │
└─────────────────┘       └─────────────────┘
```

### 2.2 表结构设计

#### 2.2.1 billing_plans（套餐计划表）

```sql
CREATE TABLE billing_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    display_name VARCHAR(200) NOT NULL,
    description TEXT,
    plan_type VARCHAR(50) NOT NULL, -- 'free', 'standard', 'professional', 'enterprise'
    billing_cycle VARCHAR(20) NOT NULL, -- 'monthly', 'yearly', 'one_time'

    -- 价格信息
    base_price DECIMAL(10, 2) NOT NULL DEFAULT 0,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',

    -- 配额限制
    quota_config JSONB NOT NULL DEFAULT '{}', -- 灵活的配额配置
    -- 示例: {
    --   "api_calls": {"monthly": 10000, "daily": 500},
    --   "tokens": {"monthly": 1000000, "daily": 50000},
    --   "storage_gb": 10,
    --   "agents": 5,
    --   "models": ["gpt-3.5-turbo", "claude-sonnet-3.5"]
    -- }

    -- 计费规则
    pricing_rules JSONB NOT NULL DEFAULT '{}',
    -- 示例: {
    --   "api_call_price": 0.001,
    --   "token_prices": {
    --     "gpt-4": {"input": 0.00003, "output": 0.00006},
    --     "claude-sonnet-3.5": {"input": 0.00003, "output": 0.000015}
    --   },
    --   "storage_price_per_gb": 0.1,
    --   "overage_multiplier": 1.5
    -- }

    -- 特性标志
    features JSONB NOT NULL DEFAULT '{}',
    -- 示例: {
    --   "custom_agents": true,
    --   "advanced_analytics": true,
    --   "priority_support": true,
    --   "api_access": true
    -- }

    -- 状态
    is_active BOOLEAN DEFAULT true,
    is_visible BOOLEAN DEFAULT true, -- 是否在前端展示
    sort_order INTEGER DEFAULT 0,

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_billing_plans_type ON billing_plans(plan_type);
CREATE INDEX idx_billing_plans_active ON billing_plans(is_active, is_visible);
```

#### 2.2.2 user_subscriptions（用户订阅表）

```sql
CREATE TABLE user_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_id UUID NOT NULL REFERENCES billing_plans(id),

    -- 订阅状态
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    -- 'active', 'cancelled', 'expired', 'suspended', 'trial'

    -- 时间信息
    started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    current_period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    current_period_end TIMESTAMP WITH TIME ZONE NOT NULL,
    trial_end TIMESTAMP WITH TIME ZONE,
    cancelled_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,

    -- 计费信息
    billing_cycle VARCHAR(20) NOT NULL, -- 'monthly', 'yearly'
    next_billing_date TIMESTAMP WITH TIME ZONE,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',

    -- 自动续费
    auto_renew BOOLEAN DEFAULT true,

    -- 定制配额（可覆盖套餐默认配额）
    custom_quota JSONB DEFAULT '{}',

    -- 当前周期使用量
    current_usage JSONB DEFAULT '{}',
    -- 示例: {
    --   "api_calls": 1234,
    --   "tokens": {"input": 50000, "output": 30000},
    --   "storage_gb": 2.5
    -- }

    -- 支付信息
    stripe_subscription_id VARCHAR(255),
    stripe_customer_id VARCHAR(255),
    payment_method_id UUID REFERENCES payment_methods(id),

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT unique_active_subscription UNIQUE (user_id, status)
        WHERE status = 'active'
);

CREATE INDEX idx_user_subscriptions_user ON user_subscriptions(user_id);
CREATE INDEX idx_user_subscriptions_status ON user_subscriptions(status);
CREATE INDEX idx_user_subscriptions_period ON user_subscriptions(current_period_end);
CREATE INDEX idx_user_subscriptions_stripe ON user_subscriptions(stripe_subscription_id);
```

#### 2.2.3 usage_records（用量记录表）

```sql
CREATE TABLE usage_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES user_subscriptions(id),

    -- 资源类型
    resource_type VARCHAR(50) NOT NULL,
    -- 'api_call', 'token_usage', 'storage', 'agent_execution'

    -- 资源详情
    resource_id VARCHAR(255), -- Agent ID, Model ID 等
    resource_name VARCHAR(255),

    -- 使用量
    quantity DECIMAL(15, 6) NOT NULL,
    unit VARCHAR(50) NOT NULL, -- 'count', 'token', 'gb', 'second'

    -- 成本信息
    unit_price DECIMAL(10, 8),
    total_cost DECIMAL(10, 4),
    currency VARCHAR(10) DEFAULT 'USD',

    -- 详细信息
    details JSONB DEFAULT '{}',
    -- 示例（API调用）: {
    --   "endpoint": "/api/v1/agents/run",
    --   "method": "POST",
    --   "model": "gpt-4",
    --   "input_tokens": 500,
    --   "output_tokens": 300,
    --   "duration_ms": 1234
    -- }

    -- 时间信息
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    billing_period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    billing_period_end TIMESTAMP WITH TIME ZONE NOT NULL,

    -- 状态
    is_billed BOOLEAN DEFAULT false,
    invoice_id UUID REFERENCES invoices(id),

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_usage_records_user ON usage_records(user_id, recorded_at DESC);
CREATE INDEX idx_usage_records_subscription ON usage_records(subscription_id);
CREATE INDEX idx_usage_records_resource ON usage_records(resource_type, resource_id);
CREATE INDEX idx_usage_records_billing ON usage_records(is_billed, billing_period_start);
CREATE INDEX idx_usage_records_period ON usage_records(billing_period_start, billing_period_end);

-- 分区表（按月分区，提升查询性能）
CREATE TABLE usage_records_y2024m01 PARTITION OF usage_records
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
-- 后续月份可通过脚本自动创建
```

#### 2.2.4 invoices（账单表）

```sql
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number VARCHAR(100) NOT NULL UNIQUE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES user_subscriptions(id),

    -- 账单状态
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    -- 'draft', 'pending', 'paid', 'overdue', 'cancelled', 'refunded'

    -- 金额信息
    subtotal DECIMAL(10, 2) NOT NULL DEFAULT 0,
    tax_rate DECIMAL(5, 4) DEFAULT 0,
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    total_amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',

    -- 账期信息
    billing_period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    billing_period_end TIMESTAMP WITH TIME ZONE NOT NULL,
    issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
    due_date DATE NOT NULL,

    -- 支付信息
    paid_at TIMESTAMP WITH TIME ZONE,
    payment_method VARCHAR(50), -- 'stripe', 'alipay', 'manual'
    payment_transaction_id VARCHAR(255),
    stripe_invoice_id VARCHAR(255),

    -- 账单详情
    line_items_count INTEGER DEFAULT 0,

    -- 备注
    notes TEXT,

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_invoices_user ON invoices(user_id, issue_date DESC);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_period ON invoices(billing_period_start, billing_period_end);
CREATE INDEX idx_invoices_due ON invoices(due_date) WHERE status IN ('pending', 'overdue');
CREATE UNIQUE INDEX idx_invoices_number ON invoices(invoice_number);
```

#### 2.2.5 invoice_line_items（账单明细表）

```sql
CREATE TABLE invoice_line_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,

    -- 项目信息
    description TEXT NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_name VARCHAR(255),

    -- 数量和价格
    quantity DECIMAL(15, 6) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    unit_price DECIMAL(10, 8) NOT NULL,
    amount DECIMAL(10, 4) NOT NULL,

    -- 时间范围
    period_start TIMESTAMP WITH TIME ZONE,
    period_end TIMESTAMP WITH TIME ZONE,

    -- 详细信息
    details JSONB DEFAULT '{}',

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_invoice_line_items_invoice ON invoice_line_items(invoice_id);
CREATE INDEX idx_invoice_line_items_resource ON invoice_line_items(resource_type);
```

#### 2.2.6 quota_limits（配额限制表）

```sql
CREATE TABLE quota_limits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES user_subscriptions(id) ON DELETE CASCADE,

    -- 资源类型
    resource_type VARCHAR(50) NOT NULL,
    -- 'api_calls', 'tokens', 'storage', 'agents', 'models'

    -- 限额配置
    limit_type VARCHAR(20) NOT NULL, -- 'daily', 'monthly', 'total'
    limit_value BIGINT NOT NULL,

    -- 当前使用量
    current_usage BIGINT DEFAULT 0,

    -- 重置信息
    reset_period VARCHAR(20), -- 'daily', 'monthly'
    last_reset_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    next_reset_at TIMESTAMP WITH TIME ZONE,

    -- 限流策略
    throttle_config JSONB DEFAULT '{}',
    -- 示例: {
    --   "soft_limit": 8000,  -- 80% 时发送警告
    --   "hard_limit": 10000, -- 100% 时阻止请求
    --   "burst_allowance": 100 -- 允许短时突发
    -- }

    -- 超限行为
    over_limit_action VARCHAR(50) DEFAULT 'block',
    -- 'block', 'throttle', 'allow_with_fee'

    -- 状态
    is_active BOOLEAN DEFAULT true,

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT unique_quota_limit UNIQUE (user_id, subscription_id, resource_type, limit_type)
);

CREATE INDEX idx_quota_limits_user ON quota_limits(user_id, resource_type);
CREATE INDEX idx_quota_limits_subscription ON quota_limits(subscription_id);
CREATE INDEX idx_quota_limits_reset ON quota_limits(next_reset_at) WHERE is_active = true;
```

#### 2.2.7 payment_methods（支付方式表）

```sql
CREATE TABLE payment_methods (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- 支付方式类型
    payment_type VARCHAR(50) NOT NULL, -- 'card', 'alipay', 'wechat', 'bank_account'

    -- Stripe 信息
    stripe_payment_method_id VARCHAR(255),

    -- 卡片信息（仅存储必要的展示信息）
    card_brand VARCHAR(50),
    card_last4 VARCHAR(4),
    card_exp_month INTEGER,
    card_exp_year INTEGER,

    -- 支付宝/微信信息
    alipay_user_id VARCHAR(255),
    wechat_openid VARCHAR(255),

    -- 状态
    is_default BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT unique_default_payment UNIQUE (user_id, is_default)
        WHERE is_default = true
);

CREATE INDEX idx_payment_methods_user ON payment_methods(user_id);
CREATE INDEX idx_payment_methods_stripe ON payment_methods(stripe_payment_method_id);
```

#### 2.2.8 billing_alerts（计费告警表）

```sql
CREATE TABLE billing_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES user_subscriptions(id),

    -- 告警类型
    alert_type VARCHAR(50) NOT NULL,
    -- 'quota_warning', 'quota_exceeded', 'payment_failed', 'invoice_overdue'

    -- 告警级别
    severity VARCHAR(20) NOT NULL, -- 'info', 'warning', 'critical'

    -- 告警内容
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,

    -- 触发信息
    triggered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    trigger_data JSONB DEFAULT '{}',

    -- 状态
    is_read BOOLEAN DEFAULT false,
    is_resolved BOOLEAN DEFAULT false,
    resolved_at TIMESTAMP WITH TIME ZONE,

    -- 通知状态
    notification_sent BOOLEAN DEFAULT false,
    notification_sent_at TIMESTAMP WITH TIME ZONE,

    -- 元数据
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_billing_alerts_user ON billing_alerts(user_id, created_at DESC);
CREATE INDEX idx_billing_alerts_type ON billing_alerts(alert_type, is_resolved);
CREATE INDEX idx_billing_alerts_unread ON billing_alerts(user_id, is_read)
    WHERE is_read = false;
```

---

## 3. 核心功能实现

### 3.1 数据模型（SQLAlchemy Models）

```python
# app/models/billing.py
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, Dict, Any
from sqlalchemy import (
    Column, String, Integer, Boolean, DECIMAL, DateTime,
    ForeignKey, Text, Date, BigInteger, CheckConstraint
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
import uuid

from app.db.base import Base


class BillingPlan(Base):
    __tablename__ = "billing_plans"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), unique=True, nullable=False, index=True)
    display_name = Column(String(200), nullable=False)
    description = Column(Text)
    plan_type = Column(String(50), nullable=False, index=True)
    billing_cycle = Column(String(20), nullable=False)

    base_price = Column(DECIMAL(10, 2), nullable=False, default=0)
    currency = Column(String(10), nullable=False, default='USD')

    quota_config = Column(JSONB, nullable=False, default={})
    pricing_rules = Column(JSONB, nullable=False, default={})
    features = Column(JSONB, nullable=False, default={})

    is_active = Column(Boolean, default=True)
    is_visible = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    subscriptions = relationship("UserSubscription", back_populates="plan")

    def get_quota(self, resource_type: str, period: str = "monthly") -> Optional[int]:
        """获取特定资源的配额限制"""
        return self.quota_config.get(resource_type, {}).get(period)

    def get_price(self, resource_type: str, sub_type: Optional[str] = None) -> Optional[Decimal]:
        """获取特定资源的价格"""
        if sub_type:
            return Decimal(str(self.pricing_rules.get(resource_type, {}).get(sub_type, 0)))
        return Decimal(str(self.pricing_rules.get(resource_type, 0)))

    def has_feature(self, feature_name: str) -> bool:
        """检查是否包含特定功能"""
        return self.features.get(feature_name, False)


class UserSubscription(Base):
    __tablename__ = "user_subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    plan_id = Column(UUID(as_uuid=True), ForeignKey("billing_plans.id"), nullable=False)

    status = Column(String(50), nullable=False, default='active', index=True)

    started_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)
    current_period_start = Column(DateTime(timezone=True), nullable=False)
    current_period_end = Column(DateTime(timezone=True), nullable=False)
    trial_end = Column(DateTime(timezone=True))
    cancelled_at = Column(DateTime(timezone=True))
    ended_at = Column(DateTime(timezone=True))

    billing_cycle = Column(String(20), nullable=False)
    next_billing_date = Column(DateTime(timezone=True))
    amount = Column(DECIMAL(10, 2), nullable=False)
    currency = Column(String(10), nullable=False, default='USD')

    auto_renew = Column(Boolean, default=True)
    custom_quota = Column(JSONB, default={})
    current_usage = Column(JSONB, default={})

    stripe_subscription_id = Column(String(255), index=True)
    stripe_customer_id = Column(String(255))
    payment_method_id = Column(UUID(as_uuid=True), ForeignKey("payment_methods.id"))

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    plan = relationship("BillingPlan", back_populates="subscriptions")
    usage_records = relationship("UsageRecord", back_populates="subscription")
    invoices = relationship("Invoice", back_populates="subscription")
    quota_limits = relationship("QuotaLimit", back_populates="subscription")
    payment_method = relationship("PaymentMethod")

    def is_trial(self) -> bool:
        """是否处于试用期"""
        return self.trial_end and datetime.utcnow() < self.trial_end

    def is_expired(self) -> bool:
        """是否已过期"""
        return datetime.utcnow() > self.current_period_end

    def get_quota(self, resource_type: str, period: str = "monthly") -> Optional[int]:
        """获取配额（优先使用自定义配额）"""
        custom = self.custom_quota.get(resource_type, {}).get(period)
        if custom is not None:
            return custom
        return self.plan.get_quota(resource_type, period)

    def get_usage(self, resource_type: str) -> int:
        """获取当前使用量"""
        return self.current_usage.get(resource_type, 0)

    def increment_usage(self, resource_type: str, amount: int = 1):
        """增加使用量"""
        if resource_type not in self.current_usage:
            self.current_usage[resource_type] = 0
        self.current_usage[resource_type] += amount


class UsageRecord(Base):
    __tablename__ = "usage_records"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("user_subscriptions.id"))

    resource_type = Column(String(50), nullable=False, index=True)
    resource_id = Column(String(255), index=True)
    resource_name = Column(String(255))

    quantity = Column(DECIMAL(15, 6), nullable=False)
    unit = Column(String(50), nullable=False)

    unit_price = Column(DECIMAL(10, 8))
    total_cost = Column(DECIMAL(10, 4))
    currency = Column(String(10), default='USD')

    details = Column(JSONB, default={})

    recorded_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow, index=True)
    billing_period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    billing_period_end = Column(DateTime(timezone=True), nullable=False)

    is_billed = Column(Boolean, default=False, index=True)
    invoice_id = Column(UUID(as_uuid=True), ForeignKey("invoices.id"))

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    # Relationships
    subscription = relationship("UserSubscription", back_populates="usage_records")
    invoice = relationship("Invoice", back_populates="usage_records")

    def calculate_cost(self, unit_price: Decimal) -> Decimal:
        """计算成本"""
        self.unit_price = unit_price
        self.total_cost = Decimal(str(self.quantity)) * unit_price
        return self.total_cost


class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    invoice_number = Column(String(100), unique=True, nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("user_subscriptions.id"))

    status = Column(String(50), nullable=False, default='draft', index=True)

    subtotal = Column(DECIMAL(10, 2), nullable=False, default=0)
    tax_rate = Column(DECIMAL(5, 4), default=0)
    tax_amount = Column(DECIMAL(10, 2), default=0)
    discount_amount = Column(DECIMAL(10, 2), default=0)
    total_amount = Column(DECIMAL(10, 2), nullable=False)
    currency = Column(String(10), nullable=False, default='USD')

    billing_period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    billing_period_end = Column(DateTime(timezone=True), nullable=False)
    issue_date = Column(Date, nullable=False, default=datetime.utcnow().date)
    due_date = Column(Date, nullable=False)

    paid_at = Column(DateTime(timezone=True))
    payment_method = Column(String(50))
    payment_transaction_id = Column(String(255))
    stripe_invoice_id = Column(String(255), index=True)

    line_items_count = Column(Integer, default=0)
    notes = Column(Text)

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    subscription = relationship("UserSubscription", back_populates="invoices")
    line_items = relationship("InvoiceLineItem", back_populates="invoice", cascade="all, delete-orphan")
    usage_records = relationship("UsageRecord", back_populates="invoice")

    def calculate_total(self):
        """计算总金额"""
        self.subtotal = sum(item.amount for item in self.line_items)
        self.tax_amount = self.subtotal * self.tax_rate
        self.total_amount = self.subtotal + self.tax_amount - self.discount_amount

    def is_overdue(self) -> bool:
        """是否逾期"""
        return self.status in ['pending', 'overdue'] and datetime.utcnow().date() > self.due_date


class InvoiceLineItem(Base):
    __tablename__ = "invoice_line_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    invoice_id = Column(UUID(as_uuid=True), ForeignKey("invoices.id", ondelete="CASCADE"), nullable=False)

    description = Column(Text, nullable=False)
    resource_type = Column(String(50), nullable=False, index=True)
    resource_name = Column(String(255))

    quantity = Column(DECIMAL(15, 6), nullable=False)
    unit = Column(String(50), nullable=False)
    unit_price = Column(DECIMAL(10, 8), nullable=False)
    amount = Column(DECIMAL(10, 4), nullable=False)

    period_start = Column(DateTime(timezone=True))
    period_end = Column(DateTime(timezone=True))

    details = Column(JSONB, default={})
    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    # Relationships
    invoice = relationship("Invoice", back_populates="line_items")


class QuotaLimit(Base):
    __tablename__ = "quota_limits"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("user_subscriptions.id", ondelete="CASCADE"))

    resource_type = Column(String(50), nullable=False, index=True)
    limit_type = Column(String(20), nullable=False)
    limit_value = Column(BigInteger, nullable=False)

    current_usage = Column(BigInteger, default=0)

    reset_period = Column(String(20))
    last_reset_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    next_reset_at = Column(DateTime(timezone=True))

    throttle_config = Column(JSONB, default={})
    over_limit_action = Column(String(50), default='block')

    is_active = Column(Boolean, default=True)

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    subscription = relationship("UserSubscription", back_populates="quota_limits")

    __table_args__ = (
        CheckConstraint('current_usage >= 0', name='check_current_usage_positive'),
    )

    def is_exceeded(self) -> bool:
        """是否超限"""
        return self.current_usage >= self.limit_value

    def get_usage_percentage(self) -> float:
        """获取使用百分比"""
        if self.limit_value == 0:
            return 0.0
        return (self.current_usage / self.limit_value) * 100

    def needs_reset(self) -> bool:
        """是否需要重置"""
        return self.next_reset_at and datetime.utcnow() >= self.next_reset_at

    def reset(self):
        """重置使用量"""
        self.current_usage = 0
        self.last_reset_at = datetime.utcnow()
        if self.reset_period == 'daily':
            self.next_reset_at = datetime.utcnow() + timedelta(days=1)
        elif self.reset_period == 'monthly':
            self.next_reset_at = datetime.utcnow() + timedelta(days=30)


class PaymentMethod(Base):
    __tablename__ = "payment_methods"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    payment_type = Column(String(50), nullable=False)
    stripe_payment_method_id = Column(String(255), index=True)

    card_brand = Column(String(50))
    card_last4 = Column(String(4))
    card_exp_month = Column(Integer)
    card_exp_year = Column(Integer)

    alipay_user_id = Column(String(255))
    wechat_openid = Column(String(255))

    is_default = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)


class BillingAlert(Base):
    __tablename__ = "billing_alerts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("user_subscriptions.id"))

    alert_type = Column(String(50), nullable=False, index=True)
    severity = Column(String(20), nullable=False)

    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)

    triggered_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)
    trigger_data = Column(JSONB, default={})

    is_read = Column(Boolean, default=False, index=True)
    is_resolved = Column(Boolean, default=False, index=True)
    resolved_at = Column(DateTime(timezone=True))

    notification_sent = Column(Boolean, default=False)
    notification_sent_at = Column(DateTime(timezone=True))

    metadata = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
```

### 3.2 用量统计服务

```python
# app/services/usage_tracking.py
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, Dict, Any, List
from uuid import UUID

from sqlalchemy import func, and_
from sqlalchemy.orm import Session

from app.models.billing import (
    UsageRecord, UserSubscription, QuotaLimit, BillingAlert
)
from app.core.cache import redis_client
import json


class UsageTrackingService:
    """用量统计服务"""

    def __init__(self, db: Session):
        self.db = db

    async def record_usage(
        self,
        user_id: UUID,
        resource_type: str,
        quantity: float,
        unit: str,
        resource_id: Optional[str] = None,
        resource_name: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        subscription_id: Optional[UUID] = None
    ) -> UsageRecord:
        """
        记录用量

        Args:
            user_id: 用户ID
            resource_type: 资源类型 (api_call, token_usage, storage, etc.)
            quantity: 数量
            unit: 单位 (count, token, gb, second)
            resource_id: 资源ID（可选）
            resource_name: 资源名称（可选）
            details: 详细信息（可选）
            subscription_id: 订阅ID（可选）

        Returns:
            UsageRecord: 用量记录
        """
        # 获取用户当前订阅
        if not subscription_id:
            subscription = self.db.query(UserSubscription).filter(
                UserSubscription.user_id == user_id,
                UserSubscription.status == 'active'
            ).first()
            subscription_id = subscription.id if subscription else None
        else:
            subscription = self.db.query(UserSubscription).get(subscription_id)

        # 确定计费周期
        if subscription:
            period_start = subscription.current_period_start
            period_end = subscription.current_period_end
        else:
            # 如果没有订阅，使用当月作为计费周期
            now = datetime.utcnow()
            period_start = datetime(now.year, now.month, 1)
            if now.month == 12:
                period_end = datetime(now.year + 1, 1, 1)
            else:
                period_end = datetime(now.year, now.month + 1, 1)

        # 创建用量记录
        usage_record = UsageRecord(
            user_id=user_id,
            subscription_id=subscription_id,
            resource_type=resource_type,
            resource_id=resource_id,
            resource_name=resource_name,
            quantity=Decimal(str(quantity)),
            unit=unit,
            details=details or {},
            recorded_at=datetime.utcnow(),
            billing_period_start=period_start,
            billing_period_end=period_end
        )

        # 计算成本
        if subscription and subscription.plan:
            unit_price = subscription.plan.get_price(resource_type)
            if unit_price:
                usage_record.calculate_cost(unit_price)

        self.db.add(usage_record)

        # 更新订阅的当前使用量
        if subscription:
            subscription.increment_usage(resource_type, int(quantity))

        # 更新配额使用量（Redis + DB）
        await self._update_quota_usage(user_id, resource_type, int(quantity))

        # 检查配额限制
        await self._check_quota_limits(user_id, resource_type)

        self.db.commit()
        self.db.refresh(usage_record)

        return usage_record

    async def record_api_call(
        self,
        user_id: UUID,
        endpoint: str,
        method: str,
        model: Optional[str] = None,
        input_tokens: int = 0,
        output_tokens: int = 0,
        duration_ms: int = 0
    ) -> UsageRecord:
        """记录 API 调用"""
        details = {
            "endpoint": endpoint,
            "method": method,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "duration_ms": duration_ms
        }

        # 记录 API 调用
        usage_record = await self.record_usage(
            user_id=user_id,
            resource_type="api_call",
            quantity=1,
            unit="count",
            resource_name=f"{method} {endpoint}",
            details=details
        )

        # 如果有 token 使用，单独记录
        if input_tokens > 0 or output_tokens > 0:
            await self.record_token_usage(
                user_id=user_id,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens
            )

        return usage_record

    async def record_token_usage(
        self,
        user_id: UUID,
        model: str,
        input_tokens: int,
        output_tokens: int
    ) -> List[UsageRecord]:
        """记录 Token 使用"""
        records = []

        # 记录输入 tokens
        if input_tokens > 0:
            record = await self.record_usage(
                user_id=user_id,
                resource_type="token_input",
                quantity=input_tokens,
                unit="token",
                resource_id=model,
                resource_name=f"{model} Input Tokens"
            )
            records.append(record)

        # 记录输出 tokens
        if output_tokens > 0:
            record = await self.record_usage(
                user_id=user_id,
                resource_type="token_output",
                quantity=output_tokens,
                unit="token",
                resource_id=model,
                resource_name=f"{model} Output Tokens"
            )
            records.append(record)

        return records

    async def get_usage_summary(
        self,
        user_id: UUID,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        resource_type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        获取用量汇总

        Args:
            user_id: 用户ID
            start_date: 开始日期（可选）
            end_date: 结束日期（可选）
            resource_type: 资源类型（可选）

        Returns:
            Dict: 用量汇总信息
        """
        query = self.db.query(
            UsageRecord.resource_type,
            func.sum(UsageRecord.quantity).label('total_quantity'),
            func.sum(UsageRecord.total_cost).label('total_cost'),
            func.count(UsageRecord.id).label('record_count')
        ).filter(UsageRecord.user_id == user_id)

        if start_date:
            query = query.filter(UsageRecord.recorded_at >= start_date)
        if end_date:
            query = query.filter(UsageRecord.recorded_at <= end_date)
        if resource_type:
            query = query.filter(UsageRecord.resource_type == resource_type)

        results = query.group_by(UsageRecord.resource_type).all()

        summary = {
            "user_id": str(user_id),
            "start_date": start_date.isoformat() if start_date else None,
            "end_date": end_date.isoformat() if end_date else None,
            "resources": [],
            "total_cost": Decimal('0')
        }

        for result in results:
            resource_summary = {
                "resource_type": result.resource_type,
                "total_quantity": float(result.total_quantity),
                "total_cost": float(result.total_cost or 0),
                "record_count": result.record_count
            }
            summary["resources"].append(resource_summary)
            summary["total_cost"] += (result.total_cost or Decimal('0'))

        summary["total_cost"] = float(summary["total_cost"])

        return summary

    async def _update_quota_usage(
        self,
        user_id: UUID,
        resource_type: str,
        amount: int
    ):
        """更新配额使用量（Redis + DB）"""
        # Redis 键
        daily_key = f"quota:{user_id}:{resource_type}:daily"
        monthly_key = f"quota:{user_id}:{resource_type}:monthly"

        # 增加 Redis 计数
        pipe = redis_client.pipeline()
        pipe.incrby(daily_key, amount)
        pipe.incrby(monthly_key, amount)

        # 设置过期时间（如果是新键）
        pipe.expire(daily_key, 86400)  # 1 天
        pipe.expire(monthly_key, 2592000)  # 30 天

        pipe.execute()

        # 更新数据库中的配额记录
        quota_limits = self.db.query(QuotaLimit).filter(
            QuotaLimit.user_id == user_id,
            QuotaLimit.resource_type == resource_type,
            QuotaLimit.is_active == True
        ).all()

        for quota in quota_limits:
            quota.current_usage += amount

        self.db.commit()

    async def _check_quota_limits(self, user_id: UUID, resource_type: str):
        """检查配额限制并发送告警"""
        quota_limits = self.db.query(QuotaLimit).filter(
            QuotaLimit.user_id == user_id,
            QuotaLimit.resource_type == resource_type,
            QuotaLimit.is_active == True
        ).all()

        for quota in quota_limits:
            usage_pct = quota.get_usage_percentage()

            # 软限制（80%）告警
            soft_limit = quota.throttle_config.get('soft_limit_pct', 80)
            if usage_pct >= soft_limit and usage_pct < 100:
                await self._create_quota_alert(
                    user_id=user_id,
                    quota=quota,
                    severity='warning',
                    usage_pct=usage_pct
                )

            # 硬限制（100%）告警
            if usage_pct >= 100:
                await self._create_quota_alert(
                    user_id=user_id,
                    quota=quota,
                    severity='critical',
                    usage_pct=usage_pct
                )

    async def _create_quota_alert(
        self,
        user_id: UUID,
        quota: QuotaLimit,
        severity: str,
        usage_pct: float
    ):
        """创建配额告警"""
        alert_type = 'quota_warning' if severity == 'warning' else 'quota_exceeded'

        # 检查是否已存在未解决的同类告警
        existing_alert = self.db.query(BillingAlert).filter(
            BillingAlert.user_id == user_id,
            BillingAlert.alert_type == alert_type,
            BillingAlert.is_resolved == False,
            BillingAlert.trigger_data['resource_type'].astext == quota.resource_type
        ).first()

        if existing_alert:
            return  # 已有告警，不重复创建

        # 创建新告警
        alert = BillingAlert(
            user_id=user_id,
            subscription_id=quota.subscription_id,
            alert_type=alert_type,
            severity=severity,
            title=f"{quota.resource_type.replace('_', ' ').title()} Quota {severity.title()}",
            message=f"Your {quota.resource_type} usage has reached {usage_pct:.1f}% of the limit.",
            trigger_data={
                "resource_type": quota.resource_type,
                "limit_type": quota.limit_type,
                "limit_value": quota.limit_value,
                "current_usage": quota.current_usage,
                "usage_percentage": usage_pct
            }
        )

        self.db.add(alert)
        self.db.commit()
```

### 3.3 配额管理服务

```python
# app/services/quota_management.py
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from uuid import UUID

from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.billing import QuotaLimit, UserSubscription
from app.core.cache import redis_client


class QuotaManagementService:
    """配额管理服务"""

    def __init__(self, db: Session):
        self.db = db

    async def check_quota(
        self,
        user_id: UUID,
        resource_type: str,
        required_amount: int = 1
    ) -> Dict[str, Any]:
        """
        检查配额是否充足

        Args:
            user_id: 用户ID
            resource_type: 资源类型
            required_amount: 需要的数量

        Returns:
            Dict: 配额检查结果

        Raises:
            HTTPException: 如果配额不足
        """
        # 先从 Redis 快速检查
        redis_result = await self._check_redis_quota(user_id, resource_type, required_amount)
        if not redis_result['allowed']:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Quota exceeded for {resource_type}. {redis_result.get('message', '')}"
            )

        # 从数据库获取详细配额信息
        quota_limits = self.db.query(QuotaLimit).filter(
            QuotaLimit.user_id == user_id,
            QuotaLimit.resource_type == resource_type,
            QuotaLimit.is_active == True
        ).all()

        if not quota_limits:
            # 没有配额限制，允许使用
            return {
                "allowed": True,
                "message": "No quota limit set",
                "remaining": None
            }

        for quota in quota_limits:
            # 检查是否需要重置
            if quota.needs_reset():
                quota.reset()
                self.db.commit()

            # 检查是否超限
            if quota.current_usage + required_amount > quota.limit_value:
                action = quota.over_limit_action

                if action == 'block':
                    raise HTTPException(
                        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                        detail=f"{quota.limit_type.title()} quota exceeded for {resource_type}. "
                               f"Limit: {quota.limit_value}, Used: {quota.current_usage}"
                    )
                elif action == 'throttle':
                    # 实施限流（可以返回特殊状态让调用方延迟）
                    return {
                        "allowed": True,
                        "throttled": True,
                        "message": "Request throttled due to quota limit",
                        "remaining": quota.limit_value - quota.current_usage,
                        "retry_after": 60  # 建议 60 秒后重试
                    }
                elif action == 'allow_with_fee':
                    # 允许但收取超量费用
                    return {
                        "allowed": True,
                        "overage": True,
                        "message": "Usage allowed with overage charges",
                        "remaining": 0,
                        "overage_amount": required_amount
                    }

        # 配额充足
        remaining = min(
            quota.limit_value - quota.current_usage
            for quota in quota_limits
        )

        return {
            "allowed": True,
            "message": "Quota available",
            "remaining": remaining
        }

    async def _check_redis_quota(
        self,
        user_id: UUID,
        resource_type: str,
        required_amount: int
    ) -> Dict[str, Any]:
        """从 Redis 快速检查配额（用于高频限流）"""
        # 检查日配额
        daily_key = f"quota:{user_id}:{resource_type}:daily"
        daily_usage = int(redis_client.get(daily_key) or 0)

        # 从数据库获取限额（可以缓存）
        daily_limit = await self._get_quota_limit(user_id, resource_type, 'daily')

        if daily_limit and daily_usage + required_amount > daily_limit:
            return {
                "allowed": False,
                "message": f"Daily quota exceeded. Used: {daily_usage}/{daily_limit}"
            }

        return {"allowed": True}

    async def _get_quota_limit(
        self,
        user_id: UUID,
        resource_type: str,
        limit_type: str
    ) -> Optional[int]:
        """获取配额限制（带缓存）"""
        cache_key = f"quota_limit:{user_id}:{resource_type}:{limit_type}"

        # 尝试从缓存获取
        cached_limit = redis_client.get(cache_key)
        if cached_limit:
            return int(cached_limit)

        # 从数据库查询
        quota = self.db.query(QuotaLimit).filter(
            QuotaLimit.user_id == user_id,
            QuotaLimit.resource_type == resource_type,
            QuotaLimit.limit_type == limit_type,
            QuotaLimit.is_active == True
        ).first()

        if quota:
            # 缓存 5 分钟
            redis_client.setex(cache_key, 300, quota.limit_value)
            return quota.limit_value

        return None

    async def create_quota_limits_for_subscription(
        self,
        subscription: UserSubscription
    ):
        """为订阅创建配额限制"""
        plan = subscription.plan
        quota_config = plan.quota_config

        # 删除现有配额限制
        self.db.query(QuotaLimit).filter(
            QuotaLimit.subscription_id == subscription.id
        ).delete()

        # 创建新的配额限制
        for resource_type, limits in quota_config.items():
            if isinstance(limits, dict):
                for limit_type, limit_value in limits.items():
                    if limit_type in ['daily', 'monthly', 'total']:
                        quota = QuotaLimit(
                            user_id=subscription.user_id,
                            subscription_id=subscription.id,
                            resource_type=resource_type,
                            limit_type=limit_type,
                            limit_value=limit_value,
                            reset_period=limit_type if limit_type != 'total' else None,
                            next_reset_at=self._calculate_next_reset(limit_type)
                        )
                        self.db.add(quota)

        self.db.commit()

    def _calculate_next_reset(self, reset_period: str) -> Optional[datetime]:
        """计算下次重置时间"""
        now = datetime.utcnow()
        if reset_period == 'daily':
            return now + timedelta(days=1)
        elif reset_period == 'monthly':
            # 下个月的第一天
            if now.month == 12:
                return datetime(now.year + 1, 1, 1)
            else:
                return datetime(now.year, now.month + 1, 1)
        return None

    async def get_quota_status(self, user_id: UUID) -> Dict[str, Any]:
        """获取用户的配额状态"""
        quota_limits = self.db.query(QuotaLimit).filter(
            QuotaLimit.user_id == user_id,
            QuotaLimit.is_active == True
        ).all()

        status = {
            "user_id": str(user_id),
            "quotas": []
        }

        for quota in quota_limits:
            quota_info = {
                "resource_type": quota.resource_type,
                "limit_type": quota.limit_type,
                "limit_value": quota.limit_value,
                "current_usage": quota.current_usage,
                "remaining": quota.limit_value - quota.current_usage,
                "usage_percentage": quota.get_usage_percentage(),
                "is_exceeded": quota.is_exceeded(),
                "next_reset_at": quota.next_reset_at.isoformat() if quota.next_reset_at else None
            }
            status["quotas"].append(quota_info)

        return status
```

### 3.4 账单生成服务

```python
# app/services/invoice_generation.py
from datetime import datetime, timedelta, date
from decimal import Decimal
from typing import Optional, List, Dict, Any
from uuid import UUID

from sqlalchemy import and_
from sqlalchemy.orm import Session

from app.models.billing import (
    Invoice, InvoiceLineItem, UsageRecord,
    UserSubscription, BillingPlan
)


class InvoiceGenerationService:
    """账单生成服务"""

    def __init__(self, db: Session):
        self.db = db

    async def generate_invoice(
        self,
        user_id: UUID,
        subscription_id: UUID,
        billing_period_start: datetime,
        billing_period_end: datetime,
        auto_finalize: bool = True
    ) -> Invoice:
        """
        生成账单

        Args:
            user_id: 用户ID
            subscription_id: 订阅ID
            billing_period_start: 账期开始时间
            billing_period_end: 账期结束时间
            auto_finalize: 是否自动完成账单

        Returns:
            Invoice: 生成的账单
        """
        subscription = self.db.query(UserSubscription).get(subscription_id)
        if not subscription or subscription.user_id != user_id:
            raise ValueError("Invalid subscription")

        # 创建账单
        invoice = Invoice(
            invoice_number=self._generate_invoice_number(),
            user_id=user_id,
            subscription_id=subscription_id,
            status='draft',
            billing_period_start=billing_period_start,
            billing_period_end=billing_period_end,
            issue_date=date.today(),
            due_date=date.today() + timedelta(days=30),
            currency=subscription.currency
        )

        self.db.add(invoice)
        self.db.flush()  # 获取 invoice.id

        # 添加订阅费用
        await self._add_subscription_line_item(invoice, subscription)

        # 添加用量费用
        await self._add_usage_line_items(
            invoice,
            user_id,
            billing_period_start,
            billing_period_end
        )

        # 计算总额
        invoice.calculate_total()

        # 标记用量记录为已开票
        self._mark_usage_as_billed(invoice)

        self.db.commit()
        self.db.refresh(invoice)

        if auto_finalize:
            await self.finalize_invoice(invoice.id)

        return invoice

    async def _add_subscription_line_item(
        self,
        invoice: Invoice,
        subscription: UserSubscription
    ):
        """添加订阅费用明细"""
        line_item = InvoiceLineItem(
            invoice_id=invoice.id,
            description=f"{subscription.plan.display_name} Subscription",
            resource_type="subscription",
            resource_name=subscription.plan.name,
            quantity=Decimal('1'),
            unit="subscription",
            unit_price=subscription.amount,
            amount=subscription.amount,
            period_start=subscription.current_period_start,
            period_end=subscription.current_period_end,
            details={
                "plan_id": str(subscription.plan_id),
                "plan_name": subscription.plan.name,
                "billing_cycle": subscription.billing_cycle
            }
        )

        self.db.add(line_item)
        invoice.line_items_count += 1

    async def _add_usage_line_items(
        self,
        invoice: Invoice,
        user_id: UUID,
        period_start: datetime,
        period_end: datetime
    ):
        """添加用量费用明细"""
        # 查询未开票的用量记录
        usage_records = self.db.query(UsageRecord).filter(
            and_(
                UsageRecord.user_id == user_id,
                UsageRecord.is_billed == False,
                UsageRecord.billing_period_start >= period_start,
                UsageRecord.billing_period_end <= period_end,
                UsageRecord.total_cost > 0
            )
        ).all()

        # 按资源类型聚合
        usage_by_type: Dict[str, Dict[str, Any]] = {}

        for record in usage_records:
            key = f"{record.resource_type}:{record.resource_name or 'default'}"

            if key not in usage_by_type:
                usage_by_type[key] = {
                    "resource_type": record.resource_type,
                    "resource_name": record.resource_name,
                    "quantity": Decimal('0'),
                    "unit": record.unit,
                    "total_cost": Decimal('0'),
                    "unit_price": record.unit_price,
                    "records": []
                }

            usage_by_type[key]["quantity"] += record.quantity
            usage_by_type[key]["total_cost"] += record.total_cost
            usage_by_type[key]["records"].append(record.id)

        # 创建账单明细
        for usage_data in usage_by_type.values():
            # 计算平均单价
            avg_unit_price = (
                usage_data["total_cost"] / usage_data["quantity"]
                if usage_data["quantity"] > 0 else Decimal('0')
            )

            line_item = InvoiceLineItem(
                invoice_id=invoice.id,
                description=self._format_usage_description(
                    usage_data["resource_type"],
                    usage_data["resource_name"]
                ),
                resource_type=usage_data["resource_type"],
                resource_name=usage_data["resource_name"],
                quantity=usage_data["quantity"],
                unit=usage_data["unit"],
                unit_price=avg_unit_price,
                amount=usage_data["total_cost"],
                period_start=period_start,
                period_end=period_end,
                details={
                    "record_count": len(usage_data["records"]),
                    "usage_record_ids": [str(rid) for rid in usage_data["records"]]
                }
            )

            self.db.add(line_item)
            invoice.line_items_count += 1

    def _mark_usage_as_billed(self, invoice: Invoice):
        """标记用量记录为已开票"""
        for line_item in invoice.line_items:
            if line_item.resource_type != "subscription":
                record_ids = line_item.details.get("usage_record_ids", [])
                if record_ids:
                    self.db.query(UsageRecord).filter(
                        UsageRecord.id.in_([UUID(rid) for rid in record_ids])
                    ).update(
                        {"is_billed": True, "invoice_id": invoice.id},
                        synchronize_session=False
                    )

    def _format_usage_description(
        self,
        resource_type: str,
        resource_name: Optional[str]
    ) -> str:
        """格式化用量描述"""
        type_names = {
            "api_call": "API Calls",
            "token_input": "Input Tokens",
            "token_output": "Output Tokens",
            "storage": "Storage",
            "agent_execution": "Agent Executions"
        }

        base_name = type_names.get(resource_type, resource_type.replace('_', ' ').title())

        if resource_name:
            return f"{base_name} - {resource_name}"
        return base_name

    def _generate_invoice_number(self) -> str:
        """生成账单号"""
        # 格式: INV-YYYYMMDD-XXXX
        today = date.today()
        prefix = f"INV-{today.strftime('%Y%m%d')}"

        # 查询当天最后一个账单号
        last_invoice = self.db.query(Invoice).filter(
            Invoice.invoice_number.like(f"{prefix}-%")
        ).order_by(Invoice.invoice_number.desc()).first()

        if last_invoice:
            last_num = int(last_invoice.invoice_number.split('-')[-1])
            new_num = last_num + 1
        else:
            new_num = 1

        return f"{prefix}-{new_num:04d}"

    async def finalize_invoice(self, invoice_id: UUID) -> Invoice:
        """完成账单（从草稿变为待支付）"""
        invoice = self.db.query(Invoice).get(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found")

        if invoice.status != 'draft':
            raise ValueError("Only draft invoices can be finalized")

        invoice.status = 'pending'
        invoice.updated_at = datetime.utcnow()

        self.db.commit()
        self.db.refresh(invoice)

        # TODO: 发送账单通知邮件

        return invoice

    async def mark_invoice_paid(
        self,
        invoice_id: UUID,
        payment_method: str,
        transaction_id: str
    ) -> Invoice:
        """标记账单为已支付"""
        invoice = self.db.query(Invoice).get(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found")

        invoice.status = 'paid'
        invoice.paid_at = datetime.utcnow()
        invoice.payment_method = payment_method
        invoice.payment_transaction_id = transaction_id
        invoice.updated_at = datetime.utcnow()

        self.db.commit()
        self.db.refresh(invoice)

        return invoice

    async def get_invoice_pdf(self, invoice_id: UUID) -> bytes:
        """生成账单 PDF（占位符，实际需要使用 PDF 库）"""
        invoice = self.db.query(Invoice).get(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found")

        # TODO: 使用 WeasyPrint 或 ReportLab 生成 PDF
        # 这里返回一个占位符
        return b"PDF content placeholder"
```

### 3.5 定时任务（Celery）

```python
# app/tasks/billing_tasks.py
from datetime import datetime, timedelta
from celery import Celery
from sqlalchemy.orm import Session

from app.db.session import SessionLocal
from app.models.billing import UserSubscription, QuotaLimit
from app.services.invoice_generation import InvoiceGenerationService

celery_app = Celery('billing_tasks', broker='redis://localhost:6379/0')


@celery_app.task
def generate_monthly_invoices():
    """每月生成账单（定时任务）"""
    db: Session = SessionLocal()

    try:
        invoice_service = InvoiceGenerationService(db)

        # 查询需要生成账单的订阅
        now = datetime.utcnow()
        subscriptions = db.query(UserSubscription).filter(
            UserSubscription.status == 'active',
            UserSubscription.next_billing_date <= now
        ).all()

        for subscription in subscriptions:
            try:
                # 生成账单
                invoice = invoice_service.generate_invoice(
                    user_id=subscription.user_id,
                    subscription_id=subscription.id,
                    billing_period_start=subscription.current_period_start,
                    billing_period_end=subscription.current_period_end,
                    auto_finalize=True
                )

                print(f"Generated invoice {invoice.invoice_number} for user {subscription.user_id}")

                # 更新订阅周期
                if subscription.billing_cycle == 'monthly':
                    subscription.current_period_start = subscription.current_period_end
                    subscription.current_period_end = subscription.current_period_end + timedelta(days=30)
                elif subscription.billing_cycle == 'yearly':
                    subscription.current_period_start = subscription.current_period_end
                    subscription.current_period_end = subscription.current_period_end + timedelta(days=365)

                subscription.next_billing_date = subscription.current_period_end
                subscription.current_usage = {}  # 重置使用量

                db.commit()

            except Exception as e:
                print(f"Error generating invoice for subscription {subscription.id}: {str(e)}")
                db.rollback()
                continue

    finally:
        db.close()


@celery_app.task
def reset_daily_quotas():
    """每日重置配额（定时任务）"""
    db: Session = SessionLocal()

    try:
        quotas = db.query(QuotaLimit).filter(
            QuotaLimit.is_active == True,
            QuotaLimit.reset_period == 'daily',
            QuotaLimit.next_reset_at <= datetime.utcnow()
        ).all()

        for quota in quotas:
            quota.reset()

        db.commit()
        print(f"Reset {len(quotas)} daily quotas")

    finally:
        db.close()


@celery_app.task
def check_overdue_invoices():
    """检查逾期账单（定时任务）"""
    db: Session = SessionLocal()

    try:
        from app.models.billing import Invoice

        invoices = db.query(Invoice).filter(
            Invoice.status == 'pending',
            Invoice.due_date < datetime.utcnow().date()
        ).all()

        for invoice in invoices:
            invoice.status = 'overdue'
            # TODO: 发送逾期通知

        db.commit()
        print(f"Marked {len(invoices)} invoices as overdue")

    finally:
        db.close()


# 配置定时任务
celery_app.conf.beat_schedule = {
    'generate-monthly-invoices': {
        'task': 'app.tasks.billing_tasks.generate_monthly_invoices',
        'schedule': timedelta(hours=24),  # 每天执行一次
    },
    'reset-daily-quotas': {
        'task': 'app.tasks.billing_tasks.reset_daily_quotas',
        'schedule': timedelta(days=1),  # 每天执行一次
    },
    'check-overdue-invoices': {
        'task': 'app.tasks.billing_tasks.check_overdue_invoices',
        'schedule': timedelta(hours=6),  # 每6小时执行一次
    },
}
```

---

## 4. API 接口实现

### 4.1 用量统计 API

```python
# app/api/v1/endpoints/usage.py
from datetime import datetime
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.models.user import User
from app.services.usage_tracking import UsageTrackingService
from app.schemas.billing import UsageSummaryResponse

router = APIRouter()


@router.post("/record")
async def record_usage(
    resource_type: str,
    quantity: float,
    unit: str,
    resource_id: Optional[str] = None,
    resource_name: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """记录用量"""
    service = UsageTrackingService(db)

    usage_record = await service.record_usage(
        user_id=current_user.id,
        resource_type=resource_type,
        quantity=quantity,
        unit=unit,
        resource_id=resource_id,
        resource_name=resource_name
    )

    return {
        "id": str(usage_record.id),
        "resource_type": usage_record.resource_type,
        "quantity": float(usage_record.quantity),
        "total_cost": float(usage_record.total_cost) if usage_record.total_cost else None,
        "recorded_at": usage_record.recorded_at.isoformat()
    }


@router.get("/summary", response_model=UsageSummaryResponse)
async def get_usage_summary(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    resource_type: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """获取用量汇总"""
    service = UsageTrackingService(db)

    summary = await service.get_usage_summary(
        user_id=current_user.id,
        start_date=start_date,
        end_date=end_date,
        resource_type=resource_type
    )

    return summary
```

### 4.2 配额管理 API

```python
# app/api/v1/endpoints/quota.py
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.models.user import User
from app.services.quota_management import QuotaManagementService

router = APIRouter()


@router.get("/status")
async def get_quota_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """获取配额状态"""
    service = QuotaManagementService(db)
    status = await service.get_quota_status(current_user.id)
    return status


@router.post("/check")
async def check_quota(
    resource_type: str,
    required_amount: int = 1,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """检查配额"""
    service = QuotaManagementService(db)

    try:
        result = await service.check_quota(
            user_id=current_user.id,
            resource_type=resource_type,
            required_amount=required_amount
        )
        return result
    except HTTPException as e:
        raise e
```

### 4.3 订阅管理 API

```python
# app/api/v1/endpoints/subscriptions.py
from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.models.user import User
from app.models.billing import BillingPlan, UserSubscription
from app.services.quota_management import QuotaManagementService
from app.schemas.billing import (
    SubscriptionCreate, SubscriptionResponse,
    BillingPlanResponse
)

router = APIRouter()


@router.get("/plans", response_model=List[BillingPlanResponse])
async def list_billing_plans(
    db: Session = Depends(get_db)
):
    """列出所有套餐"""
    plans = db.query(BillingPlan).filter(
        BillingPlan.is_active == True,
        BillingPlan.is_visible == True
    ).order_by(BillingPlan.sort_order).all()

    return plans


@router.post("/subscribe", response_model=SubscriptionResponse)
async def create_subscription(
    subscription_data: SubscriptionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """创建订阅"""
    # 检查套餐是否存在
    plan = db.query(BillingPlan).get(subscription_data.plan_id)
    if not plan or not plan.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found or inactive"
        )

    # 检查是否已有活跃订阅
    existing = db.query(UserSubscription).filter(
        UserSubscription.user_id == current_user.id,
        UserSubscription.status == 'active'
    ).first()

    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already has an active subscription"
        )

    # 创建订阅
    from datetime import datetime, timedelta

    now = datetime.utcnow()
    if plan.billing_cycle == 'monthly':
        period_end = now + timedelta(days=30)
    elif plan.billing_cycle == 'yearly':
        period_end = now + timedelta(days=365)
    else:
        period_end = now + timedelta(days=30)

    subscription = UserSubscription(
        user_id=current_user.id,
        plan_id=plan.id,
        status='active',
        started_at=now,
        current_period_start=now,
        current_period_end=period_end,
        billing_cycle=plan.billing_cycle,
        next_billing_date=period_end,
        amount=plan.base_price,
        currency=plan.currency
    )

    db.add(subscription)
    db.commit()
    db.refresh(subscription)

    # 创建配额限制
    quota_service = QuotaManagementService(db)
    await quota_service.create_quota_limits_for_subscription(subscription)

    return subscription


@router.get("/current", response_model=SubscriptionResponse)
async def get_current_subscription(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """获取当前订阅"""
    subscription = db.query(UserSubscription).filter(
        UserSubscription.user_id == current_user.id,
        UserSubscription.status == 'active'
    ).first()

    if not subscription:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No active subscription found"
        )

    return subscription


@router.post("/{subscription_id}/cancel")
async def cancel_subscription(
    subscription_id: UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """取消订阅"""
    subscription = db.query(UserSubscription).filter(
        UserSubscription.id == subscription_id,
        UserSubscription.user_id == current_user.id
    ).first()

    if not subscription:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Subscription not found"
        )

    if subscription.status != 'active':
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Subscription is not active"
        )

    from datetime import datetime

    subscription.status = 'cancelled'
    subscription.cancelled_at = datetime.utcnow()
    subscription.auto_renew = False

    db.commit()

    return {"message": "Subscription cancelled successfully"}
```

### 4.4 账单管理 API

```python
# app/api/v1/endpoints/invoices.py
from typing import List, Optional
from uuid import UUID
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.models.user import User
from app.models.billing import Invoice
from app.services.invoice_generation import InvoiceGenerationService
from app.schemas.billing import InvoiceResponse, InvoiceDetailResponse

router = APIRouter()


@router.get("/", response_model=List[InvoiceResponse])
async def list_invoices(
    status: Optional[str] = Query(None),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """列出账单"""
    query = db.query(Invoice).filter(Invoice.user_id == current_user.id)

    if status:
        query = query.filter(Invoice.status == status)
    if start_date:
        query = query.filter(Invoice.issue_date >= start_date)
    if end_date:
        query = query.filter(Invoice.issue_date <= end_date)

    invoices = query.order_by(Invoice.issue_date.desc()).all()

    return invoices


@router.get("/{invoice_id}", response_model=InvoiceDetailResponse)
async def get_invoice(
    invoice_id: UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """获取账单详情"""
    invoice = db.query(Invoice).filter(
        Invoice.id == invoice_id,
        Invoice.user_id == current_user.id
    ).first()

    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    return invoice


@router.get("/{invoice_id}/pdf")
async def download_invoice_pdf(
    invoice_id: UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """下载账单 PDF"""
    invoice = db.query(Invoice).filter(
        Invoice.id == invoice_id,
        Invoice.user_id == current_user.id
    ).first()

    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    service = InvoiceGenerationService(db)
    pdf_content = await service.get_invoice_pdf(invoice_id)

    return Response(
        content=pdf_content,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=invoice_{invoice.invoice_number}.pdf"
        }
    )
```

---

## 5. 支付集成

### 5.1 Stripe 集成

```python
# app/services/payment_stripe.py
import stripe
from typing import Dict, Any
from uuid import UUID

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.billing import Invoice, UserSubscription, PaymentMethod

stripe.api_key = settings.STRIPE_SECRET_KEY


class StripePaymentService:
    """Stripe 支付服务"""

    def __init__(self, db: Session):
        self.db = db

    async def create_customer(self, user_id: UUID, email: str, name: str) -> str:
        """创建 Stripe 客户"""
        customer = stripe.Customer.create(
            email=email,
            name=name,
            metadata={"user_id": str(user_id)}
        )

        return customer.id

    async def create_payment_intent(
        self,
        invoice_id: UUID,
        amount: float,
        currency: str = "usd"
    ) -> Dict[str, Any]:
        """创建支付意图"""
        invoice = self.db.query(Invoice).get(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found")

        # 将金额转换为分（Stripe 要求）
        amount_cents = int(amount * 100)

        payment_intent = stripe.PaymentIntent.create(
            amount=amount_cents,
            currency=currency.lower(),
            metadata={
                "invoice_id": str(invoice_id),
                "invoice_number": invoice.invoice_number,
                "user_id": str(invoice.user_id)
            }
        )

        return {
            "client_secret": payment_intent.client_secret,
            "payment_intent_id": payment_intent.id
        }

    async def create_subscription(
        self,
        customer_id: str,
        price_id: str,
        payment_method_id: str
    ) -> Dict[str, Any]:
        """创建 Stripe 订阅"""
        subscription = stripe.Subscription.create(
            customer=customer_id,
            items=[{"price": price_id}],
            default_payment_method=payment_method_id,
            expand=["latest_invoice.payment_intent"]
        )

        return subscription

    async def handle_webhook(self, payload: bytes, sig_header: str) -> Dict[str, Any]:
        """处理 Stripe Webhook"""
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
            )
        except ValueError:
            raise ValueError("Invalid payload")
        except stripe.error.SignatureVerificationError:
            raise ValueError("Invalid signature")

        # 处理不同类型的事件
        if event.type == 'payment_intent.succeeded':
            await self._handle_payment_succeeded(event.data.object)
        elif event.type == 'payment_intent.payment_failed':
            await self._handle_payment_failed(event.data.object)
        elif event.type == 'invoice.payment_succeeded':
            await self._handle_invoice_paid(event.data.object)
        elif event.type == 'customer.subscription.deleted':
            await self._handle_subscription_cancelled(event.data.object)

        return {"status": "success"}

    async def _handle_payment_succeeded(self, payment_intent: Dict[str, Any]):
        """处理支付成功"""
        invoice_id = payment_intent.metadata.get('invoice_id')
        if not invoice_id:
            return

        from app.services.invoice_generation import InvoiceGenerationService

        invoice_service = InvoiceGenerationService(self.db)
        await invoice_service.mark_invoice_paid(
            invoice_id=UUID(invoice_id),
            payment_method='stripe',
            transaction_id=payment_intent.id
        )

    async def _handle_payment_failed(self, payment_intent: Dict[str, Any]):
        """处理支付失败"""
        # TODO: 发送支付失败通知
        pass

    async def _handle_invoice_paid(self, stripe_invoice: Dict[str, Any]):
        """处理 Stripe 账单支付"""
        # TODO: 更新本地账单状态
        pass

    async def _handle_subscription_cancelled(self, subscription: Dict[str, Any]):
        """处理订阅取消"""
        # TODO: 更新本地订阅状态
        pass
```

### 5.2 支付宝集成

```python
# app/services/payment_alipay.py
from alipay.aop.api.AlipayClientConfig import AlipayClientConfig
from alipay.aop.api.DefaultAlipayClient import DefaultAlipayClient
from alipay.aop.api.request.AlipayTradePagePayRequest import AlipayTradePagePayRequest
from typing import Dict, Any
from uuid import UUID

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.billing import Invoice


class AlipayPaymentService:
    """支付宝支付服务"""

    def __init__(self, db: Session):
        self.db = db

        # 配置支付宝客户端
        alipay_config = AlipayClientConfig()
        alipay_config.server_url = settings.ALIPAY_GATEWAY_URL
        alipay_config.app_id = settings.ALIPAY_APP_ID
        alipay_config.app_private_key = settings.ALIPAY_PRIVATE_KEY
        alipay_config.alipay_public_key = settings.ALIPAY_PUBLIC_KEY

        self.client = DefaultAlipayClient(alipay_config)

    async def create_payment(
        self,
        invoice_id: UUID,
        return_url: str,
        notify_url: str
    ) -> str:
        """创建支付宝支付"""
        invoice = self.db.query(Invoice).get(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found")

        # 创建支付请求
        request = AlipayTradePagePayRequest()
        request.return_url = return_url
        request.notify_url = notify_url

        # 设置业务参数
        request.biz_content = {
            "out_trade_no": invoice.invoice_number,
            "total_amount": str(invoice.total_amount),
            "subject": f"Invoice {invoice.invoice_number}",
            "product_code": "FAST_INSTANT_TRADE_PAY"
        }

        # 执行请求
        response = self.client.page_execute(request, http_method="GET")

        return response

    async def verify_payment(self, params: Dict[str, Any]) -> bool:
        """验证支付宝回调"""
        # TODO: 实现签名验证
        return True

    async def handle_notify(self, params: Dict[str, Any]) -> Dict[str, str]:
        """处理支付宝异步通知"""
        # 验证签名
        if not await self.verify_payment(params):
            return {"result": "fail"}

        # 获取交易状态
        trade_status = params.get('trade_status')
        out_trade_no = params.get('out_trade_no')
        trade_no = params.get('trade_no')

        if trade_status == 'TRADE_SUCCESS':
            # 查找账单
            invoice = self.db.query(Invoice).filter(
                Invoice.invoice_number == out_trade_no
            ).first()

            if invoice and invoice.status == 'pending':
                from app.services.invoice_generation import InvoiceGenerationService

                invoice_service = InvoiceGenerationService(self.db)
                await invoice_service.mark_invoice_paid(
                    invoice_id=invoice.id,
                    payment_method='alipay',
                    transaction_id=trade_no
                )

        return {"result": "success"}
```

---

## 6. 最小运行配置

### 6.1 环境变量配置

```bash
# .env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/alice_home

# Redis
REDIS_URL=redis://localhost:6379/0

# Stripe
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_PUBLISHABLE_KEY=pk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx

# Alipay
ALIPAY_APP_ID=xxx
ALIPAY_GATEWAY_URL=https://openapi.alipay.com/gateway.do
ALIPAY_PRIVATE_KEY=path/to/private_key.pem
ALIPAY_PUBLIC_KEY=path/to/alipay_public_key.pem

# Celery
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
```

### 6.2 初始化数据脚本

```python
# scripts/init_billing_data.py
from sqlalchemy.orm import Session

from app.db.session import SessionLocal
from app.models.billing import BillingPlan


def create_default_plans(db: Session):
    """创建默认套餐"""
    plans = [
        {
            "name": "free",
            "display_name": "Free Plan",
            "description": "Perfect for getting started",
            "plan_type": "free",
            "billing_cycle": "monthly",
            "base_price": 0,
            "quota_config": {
                "api_calls": {"monthly": 1000, "daily": 100},
                "tokens": {"monthly": 100000, "daily": 5000},
                "storage_gb": 1,
                "agents": 2
            },
            "pricing_rules": {},
            "features": {
                "basic_agents": True,
                "api_access": True
            },
            "sort_order": 1
        },
        {
            "name": "standard",
            "display_name": "Standard Plan",
            "description": "For individuals and small teams",
            "plan_type": "standard",
            "billing_cycle": "monthly",
            "base_price": 29.99,
            "quota_config": {
                "api_calls": {"monthly": 10000, "daily": 500},
                "tokens": {"monthly": 1000000, "daily": 50000},
                "storage_gb": 10,
                "agents": 10
            },
            "pricing_rules": {
                "api_call_price": 0.001,
                "token_prices": {
                    "gpt-4": {"input": 0.00003, "output": 0.00006}
                }
            },
            "features": {
                "custom_agents": True,
                "advanced_analytics": True,
                "api_access": True,
                "email_support": True
            },
            "sort_order": 2
        },
        {
            "name": "professional",
            "display_name": "Professional Plan",
            "description": "For growing businesses",
            "plan_type": "professional",
            "billing_cycle": "monthly",
            "base_price": 99.99,
            "quota_config": {
                "api_calls": {"monthly": 50000, "daily": 2000},
                "tokens": {"monthly": 5000000, "daily": 200000},
                "storage_gb": 50,
                "agents": 50
            },
            "pricing_rules": {
                "api_call_price": 0.0008,
                "token_prices": {
                    "gpt-4": {"input": 0.000025, "output": 0.00005}
                }
            },
            "features": {
                "custom_agents": True,
                "advanced_analytics": True,
                "api_access": True,
                "priority_support": True,
                "white_label": True
            },
            "sort_order": 3
        },
        {
            "name": "enterprise",
            "display_name": "Enterprise Plan",
            "description": "For large organizations",
            "plan_type": "enterprise",
            "billing_cycle": "yearly",
            "base_price": 999.99,
            "quota_config": {
                "api_calls": {"monthly": -1, "daily": -1},  # -1 表示无限制
                "tokens": {"monthly": -1, "daily": -1},
                "storage_gb": 500,
                "agents": -1
            },
            "pricing_rules": {
                "api_call_price": 0.0005,
                "token_prices": {
                    "gpt-4": {"input": 0.00002, "output": 0.00004}
                }
            },
            "features": {
                "custom_agents": True,
                "advanced_analytics": True,
                "api_access": True,
                "priority_support": True,
                "white_label": True,
                "dedicated_support": True,
                "sla_guarantee": True
            },
            "sort_order": 4
        }
    ]

    for plan_data in plans:
        # 检查是否已存在
        existing = db.query(BillingPlan).filter(
            BillingPlan.name == plan_data["name"]
        ).first()

        if not existing:
            plan = BillingPlan(**plan_data)
            db.add(plan)

    db.commit()
    print("Default billing plans created successfully!")


if __name__ == "__main__":
    db = SessionLocal()
    try:
        create_default_plans(db)
    finally:
        db.close()
```

### 6.3 启动脚本

```bash
#!/bin/bash
# scripts/start_billing.sh

# 启动 API 服务器
uvicorn app.main:app --host 0.0.0.0 --port 8000 &

# 启动 Celery Worker
celery -A app.tasks.billing_tasks worker --loglevel=info &

# 启动 Celery Beat（定时任务调度器）
celery -A app.tasks.billing_tasks beat --loglevel=info &

echo "Billing system started successfully!"
```

---

## 7. 开发计划

### Phase 1: 核心功能（2-3 周）
- [ ] 数据库设计和 ORM 模型
- [ ] 用量统计服务
- [ ] 配额管理和限流
- [ ] 基础 API 接口

### Phase 2: 计费和账单（2 周）
- [ ] 计费规则引擎
- [ ] 账单生成服务
- [ ] 套餐管理
- [ ] 账单 PDF 生成

### Phase 3: 支付集成（2 周）
- [ ] Stripe 集成
- [ ] 支付宝集成
- [ ] Webhook 处理
- [ ] 支付方式管理

### Phase 4: 监控和告警（1 周）
- [ ] 实时监控仪表盘
- [ ] 成本预警系统
- [ ] 邮件/短信通知
- [ ] 管理员后台

### Phase 5: 优化和测试（1-2 周）
- [ ] 性能优化
- [ ] 单元测试
- [ ] 集成测试
- [ ] 压力测试

---

## 8. 测试用例

### 8.1 单元测试

```python
# tests/test_usage_tracking.py
import pytest
from datetime import datetime
from decimal import Decimal

from app.services.usage_tracking import UsageTrackingService
from app.models.billing import UsageRecord


@pytest.mark.asyncio
async def test_record_api_call(db_session, test_user):
    """测试记录 API 调用"""
    service = UsageTrackingService(db_session)

    usage_record = await service.record_api_call(
        user_id=test_user.id,
        endpoint="/api/v1/agents/run",
        method="POST",
        model="gpt-4",
        input_tokens=500,
        output_tokens=300,
        duration_ms=1234
    )

    assert usage_record.id is not None
    assert usage_record.resource_type == "api_call"
    assert usage_record.quantity == 1
    assert usage_record.details["model"] == "gpt-4"


@pytest.mark.asyncio
async def test_usage_summary(db_session, test_user, test_usage_records):
    """测试用量汇总"""
    service = UsageTrackingService(db_session)

    summary = await service.get_usage_summary(
        user_id=test_user.id,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31)
    )

    assert "resources" in summary
    assert len(summary["resources"]) > 0
    assert summary["total_cost"] >= 0
```

```python
# tests/test_quota_management.py
import pytest
from fastapi import HTTPException

from app.services.quota_management import QuotaManagementService


@pytest.mark.asyncio
async def test_check_quota_sufficient(db_session, test_user, test_subscription):
    """测试配额充足"""
    service = QuotaManagementService(db_session)

    result = await service.check_quota(
        user_id=test_user.id,
        resource_type="api_calls",
        required_amount=1
    )

    assert result["allowed"] is True
    assert "remaining" in result


@pytest.mark.asyncio
async def test_check_quota_exceeded(db_session, test_user, test_quota_limit):
    """测试配额超限"""
    service = QuotaManagementService(db_session)

    # 设置配额为已用完
    test_quota_limit.current_usage = test_quota_limit.limit_value
    db_session.commit()

    with pytest.raises(HTTPException) as exc_info:
        await service.check_quota(
            user_id=test_user.id,
            resource_type="api_calls",
            required_amount=1
        )

    assert exc_info.value.status_code == 429
```

```python
# tests/test_invoice_generation.py
import pytest
from datetime import datetime, timedelta

from app.services.invoice_generation import InvoiceGenerationService


@pytest.mark.asyncio
async def test_generate_invoice(db_session, test_user, test_subscription, test_usage_records):
    """测试生成账单"""
    service = InvoiceGenerationService(db_session)

    period_start = datetime.utcnow() - timedelta(days=30)
    period_end = datetime.utcnow()

    invoice = await service.generate_invoice(
        user_id=test_user.id,
        subscription_id=test_subscription.id,
        billing_period_start=period_start,
        billing_period_end=period_end
    )

    assert invoice.id is not None
    assert invoice.invoice_number is not None
    assert invoice.total_amount > 0
    assert invoice.line_items_count > 0


@pytest.mark.asyncio
async def test_invoice_calculation(db_session, test_invoice):
    """测试账单金额计算"""
    test_invoice.calculate_total()

    expected_subtotal = sum(item.amount for item in test_invoice.line_items)
    expected_tax = expected_subtotal * test_invoice.tax_rate
    expected_total = expected_subtotal + expected_tax - test_invoice.discount_amount

    assert test_invoice.subtotal == expected_subtotal
    assert test_invoice.tax_amount == expected_tax
    assert test_invoice.total_amount == expected_total
```

### 8.2 集成测试

```python
# tests/integration/test_billing_flow.py
import pytest
from datetime import datetime, timedelta

from app.services.usage_tracking import UsageTrackingService
from app.services.quota_management import QuotaManagementService
from app.services.invoice_generation import InvoiceGenerationService


@pytest.mark.asyncio
async def test_complete_billing_flow(db_session, test_user, test_subscription):
    """测试完整计费流程"""
    usage_service = UsageTrackingService(db_session)
    quota_service = QuotaManagementService(db_session)
    invoice_service = InvoiceGenerationService(db_session)

    # 1. 检查配额
    quota_result = await quota_service.check_quota(
        user_id=test_user.id,
        resource_type="api_calls",
        required_amount=10
    )
    assert quota_result["allowed"] is True

    # 2. 记录用量
    for i in range(10):
        await usage_service.record_api_call(
            user_id=test_user.id,
            endpoint="/api/v1/test",
            method="POST",
            model="gpt-4",
            input_tokens=100,
            output_tokens=50
        )

    # 3. 生成账单
    period_start = datetime.utcnow() - timedelta(days=30)
    period_end = datetime.utcnow()

    invoice = await invoice_service.generate_invoice(
        user_id=test_user.id,
        subscription_id=test_subscription.id,
        billing_period_start=period_start,
        billing_period_end=period_end
    )

    assert invoice.line_items_count >= 2  # 订阅费 + 用量费
    assert invoice.total_amount > test_subscription.amount  # 包含用量成本

    # 4. 标记为已支付
    await invoice_service.mark_invoice_paid(
        invoice_id=invoice.id,
        payment_method="stripe",
        transaction_id="test_txn_123"
    )

    db_session.refresh(invoice)
    assert invoice.status == "paid"
    assert invoice.paid_at is not None
```

---

## 9. 监控和运维

### 9.1 Prometheus 指标

```python
# app/monitoring/metrics.py
from prometheus_client import Counter, Histogram, Gauge

# 用量指标
api_calls_total = Counter(
    'billing_api_calls_total',
    'Total number of API calls',
    ['user_id', 'endpoint', 'model']
)

tokens_used_total = Counter(
    'billing_tokens_used_total',
    'Total number of tokens used',
    ['user_id', 'model', 'token_type']
)

# 配额指标
quota_usage_percentage = Gauge(
    'billing_quota_usage_percentage',
    'Quota usage percentage',
    ['user_id', 'resource_type']
)

# 账单指标
invoices_generated_total = Counter(
    'billing_invoices_generated_total',
    'Total number of invoices generated',
    ['status']
)

invoice_amount = Histogram(
    'billing_invoice_amount',
    'Invoice amount distribution',
    ['currency']
)

# 支付指标
payments_total = Counter(
    'billing_payments_total',
    'Total number of payments',
    ['method', 'status']
)
```

### 9.2 日志配置

```python
# app/core/logging.py
import logging
from logging.handlers import RotatingFileHandler

def setup_billing_logger():
    logger = logging.getLogger('billing')
    logger.setLevel(logging.INFO)

    # 文件处理器
    file_handler = RotatingFileHandler(
        'logs/billing.log',
        maxBytes=10485760,  # 10MB
        backupCount=10
    )

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(formatter)

    logger.addHandler(file_handler)

    return logger
```

---

## 10. 总结

本文档详细描述了 Alice Home 计费系统的完整实现方案，包括：

1. **数据库设计**：完整的 ER 模型和表结构，支持灵活的计费场景
2. **核心服务**：用量统计、配额管理、账单生成等核心功能
3. **支付集成**：Stripe 和支付宝的完整集成方案
4. **API 接口**：RESTful API 设计，方便前端调用
5. **定时任务**：自动生成账单、重置配额等后台任务
6. **监控运维**：Prometheus 指标、日志配置等

### 技术亮点

- **灵活的配额系统**：支持多维度、多周期的配额限制
- **精确的用量跟踪**：实时记录和聚合用量数据
- **自动化账单生成**：基于用量和订阅自动生成账单
- **多支付方式支持**：集成国内外主流支付渠道
- **实时监控告警**：及时发现配额超限和支付问题

### 后续优化方向

1. **成本优化**：分析用户用量模式，优化定价策略
2. **欺诈检测**：识别异常使用行为
3. **自助服务**：用户自助升级/降级套餐
4. **多币种支持**：支持更多货币和汇率转换
5. **税务合规**：增值税、营业税等税务处理
