# Alice Home 对话管理模块实现方案 v2

## 1. 模块概述

### 1.1 定位
对话管理模块是 Alice Home 的核心交互模块,负责:
- 多轮对话的创建、管理和历史记录
- 对话上下文的短期记忆管理(存储在 MongoDB)
- 消息的发送、接收和流式输出
- Agent 切换时的上下文迁移
- 对话摘要的生成和查询
- 管理员查看所有对话,普通用户仅查看自己的对话

### 1.2 核心原则
1. **上下文连续性**: 维护多轮对话的语义连贯性
2. **短期记忆优先**: 使用 MongoDB 存储短期对话上下文
3. **长期记忆可替换**: 通过 MCP 工具实现长期记忆,支持多种后端
4. **流式友好**: 支持 WebSocket 和 SSE 的流式输出
5. **权限隔离**: 管理员可查看所有对话,普通用户仅看自己的
6. **Agent 解耦**: Agent 切换不影响对话历史,支持上下文迁移

### 1.3 技术栈
- **Web 框架**: FastAPI 0.104+
- **数据库**: MongoDB (Motor 异步驱动)
- **缓存**: Redis (会话缓存、速率限制)
- **流式输出**: WebSocket / Server-Sent Events
- **消息格式**: A2A 协议兼容的 Message 格式
- **序列化**: Pydantic 2.0+

---

## 2. 数据库设计

### 2.1 conversations 集合 (MongoDB)

存储对话会话的元数据。

```javascript
// conversations collection
{
  _id: ObjectId("..."),
  conversation_id: "uuid-string",  // 对话唯一标识

  // 用户信息
  user_id: "uuid-string",
  username: "alice",

  // Agent 信息
  agent_id: "alice.chat",  // 当前绑定的 Agent
  agent_name: "Alice Chat",
  agent_history: [  // Agent 切换历史
    {
      agent_id: "alice.chat",
      switched_at: ISODate("2025-12-01T10:00:00Z"),
      message_count: 10
    }
  ],

  // 对话元数据
  title: "关于 Python 的讨论",  // 自动生成或用户修改
  summary: "讨论了 Python 异步编程的最佳实践...",  // 对话摘要
  tags: ["python", "async", "programming"],

  // 统计信息
  message_count: 25,
  token_count: 12500,

  // 状态
  status: "active",  // "active", "archived", "deleted"
  is_pinned: false,

  // 时间戳
  created_at: ISODate("2025-12-01T10:00:00Z"),
  updated_at: ISODate("2025-12-03T15:30:00Z"),
  last_message_at: ISODate("2025-12-03T15:30:00Z"),

  // 索引
  // Index: { user_id: 1, created_at: -1 }
  // Index: { conversation_id: 1 } (unique)
  // Index: { user_id: 1, status: 1, last_message_at: -1 }
  // Index: { tags: 1 }
}
```

### 2.2 messages 集合 (MongoDB)

存储对话消息,支持多模态内容。

```javascript
// messages collection
{
  _id: ObjectId("..."),
  message_id: "uuid-string",
  conversation_id: "uuid-string",  // 外键关联到 conversations

  // 消息内容 (A2A 协议格式)
  role: "user",  // "user", "assistant", "system", "tool"
  content: [
    {
      type: "text",
      text: "请帮我分析这张图片"
    },
    {
      type: "image",
      image_url: "https://example.com/image.jpg",
      image_data: "base64...",  // 或直接存储 base64
      mime_type: "image/jpeg"
    }
  ],

  // 工具调用 (如果是 assistant 调用工具)
  tool_calls: [
    {
      id: "call_123",
      type: "function",
      function: {
        name: "search_web",
        arguments: "{\"query\": \"Python asyncio\"}"
      }
    }
  ],

  // 工具响应 (如果是 tool 角色)
  tool_call_id: "call_123",
  tool_name: "search_web",

  // 元数据
  agent_id: "alice.chat",  // 产生该消息的 Agent
  model_name: "claude-sonnet-4.5",  // 使用的模型
  parent_message_id: "uuid-string",  // 父消息 ID (用于分支对话)

  // Token 统计
  token_count: 150,
  prompt_tokens: 100,
  completion_tokens: 50,

  // 状态
  status: "completed",  // "pending", "streaming", "completed", "failed", "cancelled"
  error_message: null,

  // 时间戳
  created_at: ISODate("2025-12-03T15:30:00Z"),
  completed_at: ISODate("2025-12-03T15:30:05Z"),

  // 索引
  // Index: { conversation_id: 1, created_at: 1 }
  // Index: { message_id: 1 } (unique)
  // Index: { conversation_id: 1, role: 1 }
}
```

### 2.3 conversation_summaries 集合 (MongoDB)

存储对话的定期摘要,用于长对话的上下文压缩。

```javascript
// conversation_summaries collection
{
  _id: ObjectId("..."),
  conversation_id: "uuid-string",

  // 摘要内容
  summary_text: "用户咨询了关于 Python 异步编程的问题,讨论了 asyncio 的事件循环、协程和任务管理...",

  // 摘要范围
  start_message_id: "uuid-string",
  end_message_id: "uuid-string",
  message_count: 20,  // 摘要涵盖的消息数

  // 摘要元数据
  summary_type: "auto",  // "auto" (自动生成), "manual" (用户手动)
  generated_by: "alice.chat",  // 生成摘要的 Agent

  // 时间戳
  created_at: ISODate("2025-12-02T10:00:00Z"),

  // 索引
  // Index: { conversation_id: 1, created_at: -1 }
}
```

### 2.4 Redis 缓存结构

用于会话状态缓存和速率限制。

```redis
# 活跃对话缓存 (TTL: 1小时)
conversation:active:{conversation_id} = {
  "user_id": "uuid",
  "agent_id": "alice.chat",
  "message_count": 25,
  "last_activity": "2025-12-03T15:30:00Z"
}

# 对话锁 (防止并发写入)
conversation:lock:{conversation_id} = "locked"  # TTL: 30秒

# 流式消息缓冲
stream:message:{message_id} = [
  {"delta": "Hello", "timestamp": "..."},
  {"delta": " world", "timestamp": "..."}
]  # TTL: 5分钟

# 用户速率限制
ratelimit:user:{user_id}:messages = 100  # 每小时消息数, TTL: 1小时
```

---

## 3. 核心功能实现

### 3.1 对话创建与管理

#### 3.1.1 ConversationService 类

```python
# app/core/conversation/service.py

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from motor.motor_asyncio import AsyncIOMotorClient
from app.schemas.conversation import ConversationCreate, ConversationResponse
from app.core.redis import redis_client

class ConversationService:
    """对话管理服务"""

    def __init__(self, mongo_client: AsyncIOMotorClient):
        self.db = mongo_client.alice_home
        self.conversations = self.db.conversations
        self.messages = self.db.messages
        self.summaries = self.db.conversation_summaries

    async def create_conversation(
        self,
        user_id: UUID,
        agent_id: str,
        title: Optional[str] = None,
        initial_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        创建新对话

        Args:
            user_id: 用户 ID
            agent_id: 绑定的 Agent ID
            title: 对话标题 (可选,会自动生成)
            initial_message: 初始消息 (可选)

        Returns:
            创建的对话对象
        """
        conversation_id = str(uuid4())
        now = datetime.utcnow()

        # 获取 Agent 名称
        from app.core.agent.registry import AgentRegistryService
        # 假设已有方法获取 agent_name
        agent_name = await self._get_agent_name(agent_id)

        conversation = {
            "conversation_id": conversation_id,
            "user_id": str(user_id),
            "agent_id": agent_id,
            "agent_name": agent_name,
            "agent_history": [
                {
                    "agent_id": agent_id,
                    "switched_at": now,
                    "message_count": 0
                }
            ],
            "title": title or "新对话",
            "summary": "",
            "tags": [],
            "message_count": 0,
            "token_count": 0,
            "status": "active",
            "is_pinned": False,
            "created_at": now,
            "updated_at": now,
            "last_message_at": now
        }

        await self.conversations.insert_one(conversation)

        # 如果有初始消息,创建第一条消息
        if initial_message:
            await self._add_user_message(conversation_id, initial_message)

        # 缓存到 Redis
        await self._cache_conversation(conversation_id, conversation)

        return conversation

    async def get_conversation(
        self,
        conversation_id: str,
        user_id: UUID
    ) -> Optional[Dict[str, Any]]:
        """
        获取对话详情

        Args:
            conversation_id: 对话 ID
            user_id: 用户 ID (用于权限检查)

        Returns:
            对话对象或 None
        """
        # 先从 Redis 缓存获取
        cached = await self._get_cached_conversation(conversation_id)
        if cached:
            return cached

        # 从 MongoDB 查询
        conversation = await self.conversations.find_one({
            "conversation_id": conversation_id,
            "user_id": str(user_id)
        })

        if conversation:
            # 缓存到 Redis
            await self._cache_conversation(conversation_id, conversation)
            # 移除 MongoDB 的 _id 字段
            conversation.pop("_id", None)

        return conversation

    async def list_conversations(
        self,
        user_id: UUID,
        page: int = 1,
        page_size: int = 20,
        status: Optional[str] = None,
        tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        列出用户的对话列表

        Args:
            user_id: 用户 ID
            page: 页码
            page_size: 每页数量
            status: 状态过滤
            tags: 标签过滤

        Returns:
            分页的对话列表
        """
        query = {"user_id": str(user_id)}

        if status:
            query["status"] = status

        if tags:
            query["tags"] = {"$in": tags}

        # 统计总数
        total = await self.conversations.count_documents(query)

        # 查询列表 (按最后消息时间倒序)
        skip = (page - 1) * page_size
        cursor = self.conversations.find(query).sort(
            "last_message_at", -1
        ).skip(skip).limit(page_size)

        conversations = []
        async for conv in cursor:
            conv.pop("_id", None)
            conversations.append(conv)

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "conversations": conversations
        }

    async def update_conversation(
        self,
        conversation_id: str,
        user_id: UUID,
        **updates
    ) -> bool:
        """
        更新对话信息

        Args:
            conversation_id: 对话 ID
            user_id: 用户 ID
            **updates: 要更新的字段

        Returns:
            是否更新成功
        """
        updates["updated_at"] = datetime.utcnow()

        result = await self.conversations.update_one(
            {
                "conversation_id": conversation_id,
                "user_id": str(user_id)
            },
            {"$set": updates}
        )

        if result.modified_count > 0:
            # 清除缓存
            await self._invalidate_cache(conversation_id)
            return True

        return False

    async def delete_conversation(
        self,
        conversation_id: str,
        user_id: UUID,
        hard_delete: bool = False
    ) -> bool:
        """
        删除对话 (软删除或硬删除)

        Args:
            conversation_id: 对话 ID
            user_id: 用户 ID
            hard_delete: 是否硬删除

        Returns:
            是否删除成功
        """
        if hard_delete:
            # 硬删除: 删除对话和所有消息
            await self.messages.delete_many({"conversation_id": conversation_id})
            await self.summaries.delete_many({"conversation_id": conversation_id})
            result = await self.conversations.delete_one({
                "conversation_id": conversation_id,
                "user_id": str(user_id)
            })
        else:
            # 软删除: 修改状态
            result = await self.conversations.update_one(
                {
                    "conversation_id": conversation_id,
                    "user_id": str(user_id)
                },
                {"$set": {"status": "deleted", "updated_at": datetime.utcnow()}}
            )

        if result.modified_count > 0 or result.deleted_count > 0:
            await self._invalidate_cache(conversation_id)
            return True

        return False

    async def switch_agent(
        self,
        conversation_id: str,
        user_id: UUID,
        new_agent_id: str
    ) -> Dict[str, Any]:
        """
        切换对话的 Agent (支持上下文迁移)

        Args:
            conversation_id: 对话 ID
            user_id: 用户 ID
            new_agent_id: 新 Agent ID

        Returns:
            更新后的对话对象
        """
        conversation = await self.get_conversation(conversation_id, user_id)
        if not conversation:
            raise ValueError("Conversation not found")

        # 记录 Agent 切换历史
        agent_history = conversation.get("agent_history", [])
        agent_history.append({
            "agent_id": new_agent_id,
            "switched_at": datetime.utcnow(),
            "message_count": conversation["message_count"]
        })

        # 更新 Agent
        new_agent_name = await self._get_agent_name(new_agent_id)

        await self.conversations.update_one(
            {"conversation_id": conversation_id},
            {
                "$set": {
                    "agent_id": new_agent_id,
                    "agent_name": new_agent_name,
                    "agent_history": agent_history,
                    "updated_at": datetime.utcnow()
                }
            }
        )

        # 添加系统消息标记切换
        await self._add_system_message(
            conversation_id,
            f"已切换到 Agent: {new_agent_name}"
        )

        await self._invalidate_cache(conversation_id)

        return await self.get_conversation(conversation_id, user_id)

    # ========== 私有方法 ==========

    async def _add_user_message(self, conversation_id: str, content: str):
        """添加用户消息"""
        message = {
            "message_id": str(uuid4()),
            "conversation_id": conversation_id,
            "role": "user",
            "content": [{"type": "text", "text": content}],
            "status": "completed",
            "created_at": datetime.utcnow(),
            "completed_at": datetime.utcnow()
        }
        await self.messages.insert_one(message)

        # 更新对话统计
        await self.conversations.update_one(
            {"conversation_id": conversation_id},
            {
                "$inc": {"message_count": 1},
                "$set": {"last_message_at": datetime.utcnow()}
            }
        )

    async def _add_system_message(self, conversation_id: str, content: str):
        """添加系统消息"""
        message = {
            "message_id": str(uuid4()),
            "conversation_id": conversation_id,
            "role": "system",
            "content": [{"type": "text", "text": content}],
            "status": "completed",
            "created_at": datetime.utcnow(),
            "completed_at": datetime.utcnow()
        }
        await self.messages.insert_one(message)

    async def _get_agent_name(self, agent_id: str) -> str:
        """获取 Agent 名称"""
        # 实际实现应从 agent_registry 查询
        return agent_id  # 简化实现

    async def _cache_conversation(self, conversation_id: str, conversation: dict):
        """缓存对话到 Redis"""
        cache_key = f"conversation:active:{conversation_id}"
        cache_data = {
            "user_id": conversation["user_id"],
            "agent_id": conversation["agent_id"],
            "message_count": conversation["message_count"],
            "last_activity": conversation["last_message_at"].isoformat()
        }
        await redis_client.setex(
            cache_key,
            3600,  # 1小时过期
            str(cache_data)
        )

    async def _get_cached_conversation(self, conversation_id: str) -> Optional[dict]:
        """从 Redis 获取缓存的对话"""
        cache_key = f"conversation:active:{conversation_id}"
        cached = await redis_client.get(cache_key)
        # 简化实现,实际应反序列化
        return None

    async def _invalidate_cache(self, conversation_id: str):
        """清除对话缓存"""
        cache_key = f"conversation:active:{conversation_id}"
        await redis_client.delete(cache_key)
```

### 3.2 消息发送与接收

#### 3.2.1 MessageService 类

```python
# app/core/conversation/message_service.py

from typing import List, Dict, Any, Optional, AsyncIterator
from datetime import datetime
from uuid import uuid4
from motor.motor_asyncio import AsyncIOMotorClient
from app.core.agent.runner import AgentRunner
from app.schemas.conversation import MessageCreate, MessageResponse

class MessageService:
    """消息管理服务"""

    def __init__(
        self,
        mongo_client: AsyncIOMotorClient,
        agent_runner: AgentRunner
    ):
        self.db = mongo_client.alice_home
        self.conversations = self.db.conversations
        self.messages = self.db.messages
        self.agent_runner = agent_runner

    async def send_message(
        self,
        conversation_id: str,
        user_id: str,
        content: List[Dict[str, Any]],
        stream: bool = False
    ) -> Dict[str, Any]:
        """
        发送消息并获取 Agent 响应

        Args:
            conversation_id: 对话 ID
            user_id: 用户 ID
            content: 消息内容 (A2A 格式)
            stream: 是否流式输出

        Returns:
            Assistant 响应消息
        """
        # 1. 验证对话存在
        conversation = await self.conversations.find_one({
            "conversation_id": conversation_id,
            "user_id": user_id
        })
        if not conversation:
            raise ValueError("Conversation not found")

        # 2. 创建用户消息
        user_message = await self._create_message(
            conversation_id=conversation_id,
            role="user",
            content=content,
            agent_id=conversation["agent_id"]
        )

        # 3. 获取对话历史上下文
        context_messages = await self._get_context_messages(
            conversation_id,
            limit=20  # 最近 20 条消息
        )

        # 4. 调用 Agent 执行
        agent_id = conversation["agent_id"]

        if stream:
            # 流式执行
            return await self._execute_stream(
                agent_id,
                conversation_id,
                context_messages
            )
        else:
            # 同步执行
            return await self._execute_blocking(
                agent_id,
                conversation_id,
                context_messages
            )

    async def get_messages(
        self,
        conversation_id: str,
        user_id: str,
        limit: int = 50,
        before_message_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        获取对话消息列表

        Args:
            conversation_id: 对话 ID
            user_id: 用户 ID
            limit: 返回数量
            before_message_id: 分页游标 (返回此消息之前的消息)

        Returns:
            消息列表
        """
        # 验证权限
        conversation = await self.conversations.find_one({
            "conversation_id": conversation_id,
            "user_id": user_id
        })
        if not conversation:
            raise ValueError("Conversation not found")

        query = {"conversation_id": conversation_id}

        # 分页处理
        if before_message_id:
            # 获取该消息的创建时间
            ref_message = await self.messages.find_one(
                {"message_id": before_message_id}
            )
            if ref_message:
                query["created_at"] = {"$lt": ref_message["created_at"]}

        cursor = self.messages.find(query).sort(
            "created_at", -1
        ).limit(limit)

        messages = []
        async for msg in cursor:
            msg.pop("_id", None)
            messages.append(msg)

        # 反转顺序 (最旧的在前)
        messages.reverse()

        return messages

    async def _create_message(
        self,
        conversation_id: str,
        role: str,
        content: List[Dict[str, Any]],
        agent_id: str,
        tool_calls: Optional[List[Dict]] = None,
        tool_call_id: Optional[str] = None,
        tool_name: Optional[str] = None,
        status: str = "completed"
    ) -> Dict[str, Any]:
        """创建消息"""
        message = {
            "message_id": str(uuid4()),
            "conversation_id": conversation_id,
            "role": role,
            "content": content,
            "agent_id": agent_id,
            "status": status,
            "created_at": datetime.utcnow(),
            "completed_at": datetime.utcnow() if status == "completed" else None
        }

        if tool_calls:
            message["tool_calls"] = tool_calls

        if tool_call_id:
            message["tool_call_id"] = tool_call_id
            message["tool_name"] = tool_name

        await self.messages.insert_one(message)

        # 更新对话统计
        await self.conversations.update_one(
            {"conversation_id": conversation_id},
            {
                "$inc": {"message_count": 1},
                "$set": {"last_message_at": datetime.utcnow()}
            }
        )

        message.pop("_id", None)
        return message

    async def _get_context_messages(
        self,
        conversation_id: str,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """获取对话上下文消息 (用于传递给 Agent)"""
        cursor = self.messages.find(
            {"conversation_id": conversation_id}
        ).sort("created_at", -1).limit(limit)

        messages = []
        async for msg in cursor:
            # 转换为 A2A 协议格式
            a2a_message = {
                "role": msg["role"],
                "content": msg["content"]
            }

            if "tool_calls" in msg:
                a2a_message["tool_calls"] = msg["tool_calls"]

            if "tool_call_id" in msg:
                a2a_message["tool_call_id"] = msg["tool_call_id"]
                a2a_message["name"] = msg["tool_name"]

            messages.append(a2a_message)

        # 反转为时间正序
        messages.reverse()

        return messages

    async def _execute_blocking(
        self,
        agent_id: str,
        conversation_id: str,
        context_messages: List[Dict]
    ) -> Dict[str, Any]:
        """同步执行 Agent"""
        result = await self.agent_runner.execute(
            agent_id=agent_id,
            task_type="chat",
            input_data={
                "messages": context_messages,
                "stream": False
            }
        )

        if result.status == "completed":
            # 创建 assistant 消息
            assistant_message = await self._create_message(
                conversation_id=conversation_id,
                role="assistant",
                content=[{
                    "type": "text",
                    "text": result.output_data["message"]["content"]
                }],
                agent_id=agent_id,
                status="completed"
            )

            return assistant_message
        else:
            raise RuntimeError(f"Agent execution failed: {result.error_message}")

    async def _execute_stream(
        self,
        agent_id: str,
        conversation_id: str,
        context_messages: List[Dict]
    ) -> AsyncIterator[Dict[str, Any]]:
        """流式执行 Agent (返回 AsyncIterator)"""
        # 创建待填充的 assistant 消息
        message_id = str(uuid4())
        assistant_message = {
            "message_id": message_id,
            "conversation_id": conversation_id,
            "role": "assistant",
            "content": [{"type": "text", "text": ""}],
            "agent_id": agent_id,
            "status": "streaming",
            "created_at": datetime.utcnow()
        }
        await self.messages.insert_one(assistant_message)

        # 流式调用 Agent
        full_content = ""

        try:
            # 这里需要 AgentRunner 支持流式执行
            # 假设有 execute_stream 方法
            async for chunk in self.agent_runner.execute_stream(
                agent_id=agent_id,
                task_type="chat",
                input_data={
                    "messages": context_messages,
                    "stream": True
                }
            ):
                delta = chunk.get("delta", "")
                full_content += delta

                yield {
                    "message_id": message_id,
                    "delta": delta,
                    "finished": False
                }

            # 更新消息为完成状态
            await self.messages.update_one(
                {"message_id": message_id},
                {
                    "$set": {
                        "content": [{"type": "text", "text": full_content}],
                        "status": "completed",
                        "completed_at": datetime.utcnow()
                    }
                }
            )

            yield {
                "message_id": message_id,
                "delta": "",
                "finished": True
            }

        except Exception as e:
            # 标记消息为失败
            await self.messages.update_one(
                {"message_id": message_id},
                {
                    "$set": {
                        "status": "failed",
                        "error_message": str(e)
                    }
                }
            )
            raise
```

### 3.3 上下文管理 (短期记忆)

#### 3.3.1 ContextManager 类

```python
# app/core/conversation/context_manager.py

from typing import List, Dict, Any, Optional
from motor.motor_asyncio import AsyncIOMotorClient
from app.core.llm.client import LLMClient

class ContextManager:
    """对话上下文管理器 (短期记忆)"""

    def __init__(
        self,
        mongo_client: AsyncIOMotorClient,
        llm_client: LLMClient
    ):
        self.db = mongo_client.alice_home
        self.messages = self.db.messages
        self.summaries = self.db.conversation_summaries
        self.llm_client = llm_client

        # 上下文窗口配置
        self.max_messages = 50  # 最多保留 50 条消息
        self.max_tokens = 100000  # 最大 token 数
        self.summary_threshold = 30  # 超过 30 条消息时生成摘要

    async def get_context(
        self,
        conversation_id: str,
        max_messages: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        获取对话上下文 (智能截断和压缩)

        Args:
            conversation_id: 对话 ID
            max_messages: 最大消息数 (覆盖默认值)

        Returns:
            上下文消息列表
        """
        limit = max_messages or self.max_messages

        # 获取最近的消息
        cursor = self.messages.find(
            {"conversation_id": conversation_id}
        ).sort("created_at", -1).limit(limit)

        messages = []
        total_tokens = 0

        async for msg in cursor:
            # 估算 token 数
            tokens = self._estimate_tokens(msg)

            if total_tokens + tokens > self.max_tokens:
                break

            messages.append(msg)
            total_tokens += tokens

        messages.reverse()

        # 如果消息过多,生成摘要
        if len(messages) > self.summary_threshold:
            summary = await self._get_or_create_summary(
                conversation_id,
                messages[:-20]  # 对前面的消息生成摘要
            )

            if summary:
                # 返回摘要 + 最近 20 条消息
                summary_message = {
                    "role": "system",
                    "content": [{
                        "type": "text",
                        "text": f"[对话摘要]: {summary}"
                    }]
                }
                return [summary_message] + messages[-20:]

        return messages

    async def generate_summary(
        self,
        conversation_id: str,
        message_range: Optional[tuple] = None
    ) -> str:
        """
        生成对话摘要

        Args:
            conversation_id: 对话 ID
            message_range: (start_index, end_index) 消息范围

        Returns:
            摘要文本
        """
        # 获取消息
        if message_range:
            start, end = message_range
            cursor = self.messages.find(
                {"conversation_id": conversation_id}
            ).sort("created_at", 1).skip(start).limit(end - start)
        else:
            cursor = self.messages.find(
                {"conversation_id": conversation_id}
            ).sort("created_at", 1)

        messages = []
        async for msg in cursor:
            if msg["role"] in ["user", "assistant"]:
                content_text = self._extract_text_content(msg["content"])
                messages.append(f"{msg['role']}: {content_text}")

        # 调用 LLM 生成摘要
        conversation_text = "\n".join(messages)

        summary_prompt = f"""请对以下对话生成简洁的摘要,保留关键信息和上下文:

{conversation_text}

摘要 (200字以内):"""

        summary = await self.llm_client.generate(
            prompt=summary_prompt,
            max_tokens=300
        )

        # 保存摘要
        await self.summaries.insert_one({
            "conversation_id": conversation_id,
            "summary_text": summary,
            "message_count": len(messages),
            "summary_type": "auto",
            "created_at": datetime.utcnow()
        })

        return summary

    async def _get_or_create_summary(
        self,
        conversation_id: str,
        messages: List[Dict]
    ) -> Optional[str]:
        """获取或创建摘要"""
        # 查找最近的摘要
        summary_doc = await self.summaries.find_one(
            {"conversation_id": conversation_id},
            sort=[("created_at", -1)]
        )

        if summary_doc:
            return summary_doc["summary_text"]

        # 没有摘要,生成新的
        if len(messages) > 10:
            return await self.generate_summary(conversation_id)

        return None

    def _estimate_tokens(self, message: Dict) -> int:
        """估算消息的 token 数"""
        # 简化实现: 1 个字符 ≈ 0.4 个 token
        text = self._extract_text_content(message.get("content", []))
        return int(len(text) * 0.4)

    def _extract_text_content(self, content: List[Dict]) -> str:
        """提取文本内容"""
        texts = []
        for item in content:
            if item.get("type") == "text":
                texts.append(item.get("text", ""))
        return " ".join(texts)
```

### 3.4 对话摘要生成

#### 3.4.1 SummaryService 类

```python
# app/core/conversation/summary_service.py

from typing import Dict, Any, List, Optional
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient
from app.core.llm.client import LLMClient

class SummaryService:
    """对话摘要服务"""

    def __init__(
        self,
        mongo_client: AsyncIOMotorClient,
        llm_client: LLMClient
    ):
        self.db = mongo_client.alice_home
        self.conversations = self.db.conversations
        self.messages = self.db.messages
        self.summaries = self.db.conversation_summaries
        self.llm_client = llm_client

    async def generate_conversation_title(
        self,
        conversation_id: str
    ) -> str:
        """
        自动生成对话标题 (基于前几条消息)

        Args:
            conversation_id: 对话 ID

        Returns:
            生成的标题
        """
        # 获取前 5 条消息
        cursor = self.messages.find(
            {"conversation_id": conversation_id}
        ).sort("created_at", 1).limit(5)

        messages = []
        async for msg in cursor:
            if msg["role"] in ["user", "assistant"]:
                content_text = self._extract_text(msg["content"])
                messages.append(f"{msg['role']}: {content_text}")

        if not messages:
            return "新对话"

        conversation_text = "\n".join(messages)

        # 调用 LLM 生成标题
        prompt = f"""根据以下对话内容,生成一个简洁的对话标题 (不超过20个字):

{conversation_text}

标题:"""

        title = await self.llm_client.generate(
            prompt=prompt,
            max_tokens=50,
            temperature=0.7
        )

        title = title.strip().strip('"').strip("'")

        # 更新对话标题
        await self.conversations.update_one(
            {"conversation_id": conversation_id},
            {"$set": {"title": title}}
        )

        return title

    async def generate_periodic_summary(
        self,
        conversation_id: str
    ) -> Optional[str]:
        """
        生成定期摘要 (每 20 条消息)

        Args:
            conversation_id: 对话 ID

        Returns:
            摘要文本或 None
        """
        # 获取最后一次摘要
        last_summary = await self.summaries.find_one(
            {"conversation_id": conversation_id},
            sort=[("created_at", -1)]
        )

        # 获取消息数
        total_messages = await self.messages.count_documents({
            "conversation_id": conversation_id
        })

        summarized_count = last_summary["message_count"] if last_summary else 0
        new_messages_count = total_messages - summarized_count

        # 如果新增消息少于 20 条,不生成摘要
        if new_messages_count < 20:
            return None

        # 获取新消息
        cursor = self.messages.find(
            {"conversation_id": conversation_id}
        ).sort("created_at", 1).skip(summarized_count).limit(20)

        messages = []
        start_message_id = None
        end_message_id = None

        async for msg in cursor:
            if not start_message_id:
                start_message_id = msg["message_id"]
            end_message_id = msg["message_id"]

            if msg["role"] in ["user", "assistant"]:
                content_text = self._extract_text(msg["content"])
                messages.append(f"{msg['role']}: {content_text}")

        if not messages:
            return None

        # 生成摘要
        conversation_text = "\n".join(messages)

        prompt = f"""请对以下对话片段生成简洁的摘要:

{conversation_text}

摘要:"""

        summary = await self.llm_client.generate(
            prompt=prompt,
            max_tokens=200
        )

        # 保存摘要
        await self.summaries.insert_one({
            "conversation_id": conversation_id,
            "summary_text": summary,
            "start_message_id": start_message_id,
            "end_message_id": end_message_id,
            "message_count": summarized_count + len(messages),
            "summary_type": "auto",
            "created_at": datetime.utcnow()
        })

        return summary

    def _extract_text(self, content: List[Dict]) -> str:
        """提取文本内容"""
        texts = []
        for item in content:
            if item.get("type") == "text":
                texts.append(item.get("text", ""))
        return " ".join(texts)
```

---

## 4. Agent 集成

### 4.1 Message 格式 (A2A 协议)

Alice Home 的消息格式遵循 A2A 协议标准:

```python
# app/schemas/conversation.py

from typing import List, Dict, Any, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime

class ContentItem(BaseModel):
    """消息内容项"""
    type: Literal["text", "image", "file", "tool_result"]

    # text 类型
    text: Optional[str] = None

    # image 类型
    image_url: Optional[str] = None
    image_data: Optional[str] = None  # base64
    mime_type: Optional[str] = None

    # file 类型
    file_url: Optional[str] = None
    file_name: Optional[str] = None
    file_size: Optional[int] = None

    # tool_result 类型
    tool_call_id: Optional[str] = None
    tool_name: Optional[str] = None
    tool_output: Optional[Any] = None

class ToolCall(BaseModel):
    """工具调用"""
    id: str
    type: Literal["function"] = "function"
    function: Dict[str, Any] = Field(
        ...,
        description="Function call details: {name: str, arguments: str}"
    )

class Message(BaseModel):
    """A2A 协议消息"""
    message_id: str
    conversation_id: str
    role: Literal["user", "assistant", "system", "tool"]
    content: List[ContentItem]

    # 可选字段
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None
    tool_name: Optional[str] = None

    # 元数据
    agent_id: Optional[str] = None
    model_name: Optional[str] = None
    parent_message_id: Optional[str] = None

    # Token 统计
    token_count: Optional[int] = None
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None

    # 状态
    status: Literal["pending", "streaming", "completed", "failed", "cancelled"]
    error_message: Optional[str] = None

    # 时间戳
    created_at: datetime
    completed_at: Optional[datetime] = None

class MessageCreate(BaseModel):
    """创建消息请求"""
    content: List[ContentItem]
    parent_message_id: Optional[str] = None

class MessageResponse(Message):
    """消息响应"""
    pass
```

### 4.2 Task 执行流程

```python
# app/core/conversation/task_executor.py

from typing import Dict, Any, AsyncIterator
from app.core.agent.runner import AgentRunner
from app.schemas.conversation import Message

class ConversationTaskExecutor:
    """对话任务执行器"""

    def __init__(self, agent_runner: AgentRunner):
        self.agent_runner = agent_runner

    async def execute_chat_task(
        self,
        agent_id: str,
        messages: list[Dict[str, Any]],
        stream: bool = False
    ) -> Dict[str, Any] | AsyncIterator[Dict[str, Any]]:
        """
        执行对话任务

        Args:
            agent_id: Agent ID
            messages: 消息历史 (A2A 格式)
            stream: 是否流式输出

        Returns:
            任务结果或流式迭代器
        """
        task_input = {
            "messages": messages,
            "stream": stream
        }

        if stream:
            return self._execute_stream(agent_id, task_input)
        else:
            return await self._execute_blocking(agent_id, task_input)

    async def _execute_blocking(
        self,
        agent_id: str,
        task_input: Dict[str, Any]
    ) -> Dict[str, Any]:
        """同步执行"""
        result = await self.agent_runner.execute(
            agent_id=agent_id,
            task_type="chat",
            input_data=task_input
        )

        return {
            "status": result.status,
            "message": result.output_data.get("message"),
            "usage": result.output_data.get("usage"),
            "error": result.error_message
        }

    async def _execute_stream(
        self,
        agent_id: str,
        task_input: Dict[str, Any]
    ) -> AsyncIterator[Dict[str, Any]]:
        """流式执行"""
        async for chunk in self.agent_runner.execute_stream(
            agent_id=agent_id,
            task_type="chat",
            input_data=task_input
        ):
            yield {
                "delta": chunk.get("delta", ""),
                "finished": chunk.get("finished", False),
                "usage": chunk.get("usage")
            }
```

### 4.3 流式输出 (WebSocket/SSE)

#### 4.3.1 WebSocket 实现

```python
# app/api/conversation/websocket.py

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from uuid import UUID
from app.core.conversation.message_service import MessageService
from app.core.auth import get_current_user_ws

router = APIRouter()

@router.websocket("/ws/conversation/{conversation_id}")
async def conversation_websocket(
    websocket: WebSocket,
    conversation_id: str,
    message_service: MessageService = Depends()
):
    """
    对话 WebSocket 端点 (流式输出)

    消息格式:
    - 客户端发送:
      {
        "type": "message",
        "content": [{"type": "text", "text": "Hello"}]
      }

    - 服务端响应:
      {
        "type": "delta",
        "message_id": "uuid",
        "delta": "Hello",
        "finished": false
      }
    """
    await websocket.accept()

    # TODO: 实现 WebSocket 认证
    # user = await get_current_user_ws(websocket)
    user_id = "test-user-id"

    try:
        while True:
            # 接收客户端消息
            data = await websocket.receive_json()

            if data["type"] == "message":
                # 发送消息并流式接收响应
                async for chunk in message_service._execute_stream(
                    agent_id="alice.chat",  # 从对话获取
                    conversation_id=conversation_id,
                    context_messages=[]  # 实际需要获取上下文
                ):
                    await websocket.send_json({
                        "type": "delta",
                        "message_id": chunk["message_id"],
                        "delta": chunk["delta"],
                        "finished": chunk["finished"]
                    })

            elif data["type"] == "ping":
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        print(f"WebSocket disconnected: {conversation_id}")
    except Exception as e:
        await websocket.send_json({
            "type": "error",
            "error": str(e)
        })
        await websocket.close()
```

#### 4.3.2 SSE 实现

```python
# app/api/conversation/sse.py

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from typing import AsyncIterator
import json
from app.core.conversation.message_service import MessageService
from app.core.auth import get_current_user

router = APIRouter(prefix="/api/v1/conversation", tags=["Conversation - SSE"])

@router.post("/{conversation_id}/messages/stream")
async def send_message_stream(
    conversation_id: str,
    content: list[dict],
    message_service: MessageService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """
    发送消息并流式接收响应 (SSE)

    Response format (text/event-stream):
    data: {"delta": "Hello", "finished": false}
    data: {"delta": " world", "finished": false}
    data: {"delta": "", "finished": true}
    """

    async def event_generator() -> AsyncIterator[str]:
        try:
            async for chunk in message_service.send_message(
                conversation_id=conversation_id,
                user_id=current_user["id"],
                content=content,
                stream=True
            ):
                # SSE 格式
                yield f"data: {json.dumps(chunk)}\n\n"

        except Exception as e:
            error_data = {
                "type": "error",
                "error": str(e),
                "finished": True
            }
            yield f"data: {json.dumps(error_data)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"  # 禁用 Nginx 缓冲
        }
    )
```

---

## 5. API 接口清单

### 5.1 对话管理 API

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/conversations` | 创建对话 | 已登录 |
| GET | `/api/v1/conversations` | 列出对话列表 | 已登录 |
| GET | `/api/v1/conversations/{id}` | 获取对话详情 | 已登录 |
| PUT | `/api/v1/conversations/{id}` | 更新对话 (标题、标签等) | 已登录 |
| DELETE | `/api/v1/conversations/{id}` | 删除对话 | 已登录 |
| POST | `/api/v1/conversations/{id}/switch-agent` | 切换 Agent | 已登录 |
| POST | `/api/v1/conversations/{id}/pin` | 置顶对话 | 已登录 |
| POST | `/api/v1/conversations/{id}/archive` | 归档对话 | 已登录 |

### 5.2 消息 API

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/conversations/{id}/messages` | 发送消息 (同步) | 已登录 |
| POST | `/api/v1/conversations/{id}/messages/stream` | 发送消息 (SSE 流式) | 已登录 |
| GET | `/api/v1/conversations/{id}/messages` | 获取消息列表 | 已登录 |
| GET | `/api/v1/messages/{message_id}` | 获取单条消息 | 已登录 |
| DELETE | `/api/v1/messages/{message_id}` | 删除消息 | 已登录 |

### 5.3 摘要 API

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/api/v1/conversations/{id}/summary` | 生成对话摘要 | 已登录 |
| GET | `/api/v1/conversations/{id}/summaries` | 获取摘要历史 | 已登录 |
| POST | `/api/v1/conversations/{id}/title` | 自动生成标题 | 已登录 |

### 5.4 管理员 API

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/api/v1/admin/conversations` | 查看所有对话 | 管理员 |
| GET | `/api/v1/admin/conversations/{id}` | 查看任意对话详情 | 管理员 |
| DELETE | `/api/v1/admin/conversations/{id}` | 删除任意对话 | 管理员 |
| GET | `/api/v1/admin/stats/conversations` | 对话统计 | 管理员 |

### 5.5 WebSocket API

| 路径 | 说明 | 权限 |
|------|------|------|
| `WS /ws/conversation/{id}` | 对话 WebSocket 连接 | 已登录 |

---

## 6. 完整 API 实现示例

### 6.1 对话管理 API

```python
# app/api/conversation/conversations.py

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional, List
from uuid import UUID
from app.core.conversation.service import ConversationService
from app.core.auth import get_current_user, require_role
from app.schemas.conversation import (
    ConversationCreate,
    ConversationResponse,
    ConversationUpdate,
    ConversationListResponse
)

router = APIRouter(prefix="/api/v1/conversations", tags=["Conversations"])

@router.post("/", response_model=ConversationResponse)
async def create_conversation(
    agent_id: str,
    title: Optional[str] = None,
    initial_message: Optional[str] = None,
    conversation_service: ConversationService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """
    创建新对话

    Body:
        agent_id: 绑定的 Agent ID
        title: 对话标题 (可选)
        initial_message: 初始消息 (可选)
    """
    conversation = await conversation_service.create_conversation(
        user_id=UUID(current_user["id"]),
        agent_id=agent_id,
        title=title,
        initial_message=initial_message
    )

    return conversation

@router.get("/", response_model=ConversationListResponse)
async def list_conversations(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[str] = Query(None),
    tags: Optional[List[str]] = Query(None),
    conversation_service: ConversationService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """
    列出用户的对话列表

    Query:
        page: 页码
        page_size: 每页数量
        status: 状态过滤 (active/archived/deleted)
        tags: 标签过滤
    """
    result = await conversation_service.list_conversations(
        user_id=UUID(current_user["id"]),
        page=page,
        page_size=page_size,
        status=status,
        tags=tags
    )

    return result

@router.get("/{conversation_id}", response_model=ConversationResponse)
async def get_conversation(
    conversation_id: str,
    conversation_service: ConversationService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """获取对话详情"""
    conversation = await conversation_service.get_conversation(
        conversation_id=conversation_id,
        user_id=UUID(current_user["id"])
    )

    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")

    return conversation

@router.put("/{conversation_id}", response_model=ConversationResponse)
async def update_conversation(
    conversation_id: str,
    update: ConversationUpdate,
    conversation_service: ConversationService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """
    更新对话信息

    Body:
        title: 新标题
        tags: 标签列表
        is_pinned: 是否置顶
    """
    success = await conversation_service.update_conversation(
        conversation_id=conversation_id,
        user_id=UUID(current_user["id"]),
        **update.dict(exclude_unset=True)
    )

    if not success:
        raise HTTPException(status_code=404, detail="Conversation not found")

    return await conversation_service.get_conversation(
        conversation_id,
        UUID(current_user["id"])
    )

@router.delete("/{conversation_id}")
async def delete_conversation(
    conversation_id: str,
    hard_delete: bool = Query(False),
    conversation_service: ConversationService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """删除对话 (软删除或硬删除)"""
    success = await conversation_service.delete_conversation(
        conversation_id=conversation_id,
        user_id=UUID(current_user["id"]),
        hard_delete=hard_delete
    )

    if not success:
        raise HTTPException(status_code=404, detail="Conversation not found")

    return {"message": "Conversation deleted successfully"}

@router.post("/{conversation_id}/switch-agent")
async def switch_agent(
    conversation_id: str,
    new_agent_id: str,
    conversation_service: ConversationService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """切换对话的 Agent"""
    try:
        conversation = await conversation_service.switch_agent(
            conversation_id=conversation_id,
            user_id=UUID(current_user["id"]),
            new_agent_id=new_agent_id
        )
        return conversation
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
```

### 6.2 消息 API

```python
# app/api/conversation/messages.py

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional, List
from uuid import UUID
from app.core.conversation.message_service import MessageService
from app.core.auth import get_current_user
from app.schemas.conversation import MessageCreate, MessageResponse

router = APIRouter(prefix="/api/v1/conversations", tags=["Messages"])

@router.post("/{conversation_id}/messages", response_model=MessageResponse)
async def send_message(
    conversation_id: str,
    message: MessageCreate,
    message_service: MessageService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """
    发送消息 (同步)

    Body:
        content: 消息内容 (A2A 格式)
        parent_message_id: 父消息 ID (可选)
    """
    try:
        response = await message_service.send_message(
            conversation_id=conversation_id,
            user_id=current_user["id"],
            content=message.content,
            stream=False
        )
        return response
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{conversation_id}/messages", response_model=List[MessageResponse])
async def get_messages(
    conversation_id: str,
    limit: int = Query(50, ge=1, le=100),
    before_message_id: Optional[str] = Query(None),
    message_service: MessageService = Depends(),
    current_user: dict = Depends(get_current_user)
):
    """
    获取对话消息列表

    Query:
        limit: 返回数量
        before_message_id: 分页游标
    """
    try:
        messages = await message_service.get_messages(
            conversation_id=conversation_id,
            user_id=current_user["id"],
            limit=limit,
            before_message_id=before_message_id
        )
        return messages
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
```

---

## 7. 最小运行配置

### 7.1 MongoDB 配置

```yaml
# config/mongodb.yaml

mongodb:
  uri: "mongodb://localhost:27017"
  database: "alice_home"

  # 连接池配置
  max_pool_size: 50
  min_pool_size: 10

  # 索引配置 (自动创建)
  indexes:
    conversations:
      - keys: { conversation_id: 1 }
        unique: true
      - keys: { user_id: 1, created_at: -1 }
      - keys: { user_id: 1, status: 1, last_message_at: -1 }
      - keys: { tags: 1 }

    messages:
      - keys: { message_id: 1 }
        unique: true
      - keys: { conversation_id: 1, created_at: 1 }
      - keys: { conversation_id: 1, role: 1 }

    conversation_summaries:
      - keys: { conversation_id: 1, created_at: -1 }
```

### 7.2 Redis 配置

```yaml
# config/redis.yaml

redis:
  host: "localhost"
  port: 6379
  db: 0
  password: null

  # 缓存配置
  cache:
    conversation_ttl: 3600  # 1小时
    message_stream_ttl: 300  # 5分钟

  # 速率限制
  rate_limit:
    messages_per_hour: 100
    conversations_per_day: 50
```

### 7.3 初始化脚本

```python
# scripts/init_conversation_db.py

import asyncio
from motor.motor_asyncio import AsyncIOMotorClient

async def init_mongodb():
    """初始化 MongoDB 索引"""
    client = AsyncIOMotorClient("mongodb://localhost:27017")
    db = client.alice_home

    print("Creating MongoDB indexes...")

    # conversations 索引
    await db.conversations.create_index("conversation_id", unique=True)
    await db.conversations.create_index([("user_id", 1), ("created_at", -1)])
    await db.conversations.create_index([
        ("user_id", 1),
        ("status", 1),
        ("last_message_at", -1)
    ])
    await db.conversations.create_index("tags")

    # messages 索引
    await db.messages.create_index("message_id", unique=True)
    await db.messages.create_index([("conversation_id", 1), ("created_at", 1)])
    await db.messages.create_index([("conversation_id", 1), ("role", 1)])

    # conversation_summaries 索引
    await db.conversation_summaries.create_index([
        ("conversation_id", 1),
        ("created_at", -1)
    ])

    print("✅ MongoDB indexes created successfully!")

    client.close()

if __name__ == "__main__":
    asyncio.run(init_mongodb())
```

---

## 8. 开发计划

### 第一阶段: 基础功能 (2周)

**目标**: 实现对话创建、消息收发、基础上下文管理

**任务**:
1. MongoDB 数据库设计和索引创建
2. 实现 ConversationService (创建、查询、更新、删除)
3. 实现 MessageService (发送、接收、列表)
4. 实现基础 API 接口 (对话和消息)
5. 集成 Redis 缓存
6. 编写单元测试

**交付物**:
- 完整的对话管理服务
- 消息收发 API
- 单元测试套件

---

### 第二阶段: 上下文管理 (2周)

**目标**: 实现上下文管理、对话摘要、Agent 切换

**任务**:
1. 实现 ContextManager (上下文获取、压缩)
2. 实现 SummaryService (标题生成、摘要生成)
3. 实现 Agent 切换逻辑和上下文迁移
4. 实现定期摘要生成任务
5. 优化上下文窗口管理
6. 编写集成测试

**交付物**:
- 上下文管理器
- 摘要生成服务
- Agent 切换功能
- 集成测试

---

### 第三阶段: 流式输出 (1周)

**目标**: 实现 WebSocket 和 SSE 流式输出

**任务**:
1. 实现 WebSocket 端点
2. 实现 SSE 端点
3. 优化流式消息缓冲
4. 实现流式消息的持久化
5. 前端集成测试
6. 性能测试和优化

**交付物**:
- WebSocket 流式接口
- SSE 流式接口
- 流式消息持久化
- 性能测试报告

---

### 第四阶段: 管理员功能和优化 (1周)

**目标**: 管理员查看所有对话、性能优化、生产部署

**任务**:
1. 实现管理员对话查看 API
2. 实现对话统计和分析
3. 数据库查询优化
4. 添加监控和日志
5. 编写 API 文档
6. 端到端测试

**交付物**:
- 管理员 API
- 性能优化
- 完整 API 文档
- 生产部署配置

**总计: 6 周**

---

## 9. 测试用例

### 9.1 单元测试

```python
# tests/unit/test_conversation_service.py

import pytest
from uuid import uuid4
from app.core.conversation.service import ConversationService

@pytest.mark.asyncio
async def test_create_conversation(mongo_client):
    """测试创建对话"""
    service = ConversationService(mongo_client)

    user_id = uuid4()
    conversation = await service.create_conversation(
        user_id=user_id,
        agent_id="alice.chat",
        title="Test Conversation"
    )

    assert conversation["user_id"] == str(user_id)
    assert conversation["agent_id"] == "alice.chat"
    assert conversation["title"] == "Test Conversation"
    assert conversation["status"] == "active"

@pytest.mark.asyncio
async def test_switch_agent(mongo_client):
    """测试 Agent 切换"""
    service = ConversationService(mongo_client)

    user_id = uuid4()
    conversation = await service.create_conversation(
        user_id=user_id,
        agent_id="alice.chat"
    )

    # 切换 Agent
    updated = await service.switch_agent(
        conversation_id=conversation["conversation_id"],
        user_id=user_id,
        new_agent_id="another.agent"
    )

    assert updated["agent_id"] == "another.agent"
    assert len(updated["agent_history"]) == 2

@pytest.mark.asyncio
async def test_delete_conversation(mongo_client):
    """测试删除对话"""
    service = ConversationService(mongo_client)

    user_id = uuid4()
    conversation = await service.create_conversation(
        user_id=user_id,
        agent_id="alice.chat"
    )

    # 软删除
    success = await service.delete_conversation(
        conversation_id=conversation["conversation_id"],
        user_id=user_id,
        hard_delete=False
    )

    assert success is True

    # 验证状态改变
    deleted = await service.get_conversation(
        conversation["conversation_id"],
        user_id
    )
    assert deleted["status"] == "deleted"
```

### 9.2 集成测试

```python
# tests/integration/test_message_flow.py

import pytest
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_full_conversation_flow(api_client: AsyncClient, user_token: str):
    """测试完整对话流程"""

    # 1. 创建对话
    response = await api_client.post(
        "/api/v1/conversations",
        json={"agent_id": "alice.chat", "title": "Test Chat"},
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200
    conversation = response.json()
    conversation_id = conversation["conversation_id"]

    # 2. 发送消息
    response = await api_client.post(
        f"/api/v1/conversations/{conversation_id}/messages",
        json={
            "content": [{"type": "text", "text": "Hello, Alice!"}]
        },
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200
    message = response.json()
    assert message["role"] == "assistant"

    # 3. 获取消息列表
    response = await api_client.get(
        f"/api/v1/conversations/{conversation_id}/messages",
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200
    messages = response.json()
    assert len(messages) >= 2  # user + assistant

    # 4. 切换 Agent
    response = await api_client.post(
        f"/api/v1/conversations/{conversation_id}/switch-agent",
        json={"new_agent_id": "another.agent"},
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200

    # 5. 删除对话
    response = await api_client.delete(
        f"/api/v1/conversations/{conversation_id}",
        headers={"Authorization": f"Bearer {user_token}"}
    )
    assert response.status_code == 200
```

### 9.3 流式输出测试

```python
# tests/integration/test_streaming.py

import pytest
import asyncio
from fastapi.testclient import TestClient
from app.main import app

@pytest.mark.asyncio
async def test_sse_streaming():
    """测试 SSE 流式输出"""
    client = TestClient(app)

    with client as c:
        with c.stream(
            "POST",
            "/api/v1/conversations/test-conv-id/messages/stream",
            json={"content": [{"type": "text", "text": "Hello"}]},
            headers={"Authorization": "Bearer test-token"}
        ) as response:
            chunks = []
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = json.loads(line[6:])
                    chunks.append(data)
                    if data.get("finished"):
                        break

            assert len(chunks) > 0
            assert chunks[-1]["finished"] is True
```

---

## 10. 总结

### 10.1 核心价值

本对话管理模块实现方案提供:

1. **完整的对话生命周期管理**
   - 创建、查询、更新、删除对话
   - 多轮对话的上下文连续性
   - Agent 切换和上下文迁移

2. **高效的短期记忆管理**
   - 使用 MongoDB 存储对话历史
   - Redis 缓存活跃会话
   - 智能上下文窗口管理和压缩

3. **流式输出支持**
   - WebSocket 双向通信
   - SSE 单向流式推送
   - 实时消息持久化

4. **权限隔离**
   - 普通用户仅查看自己的对话
   - 管理员可查看所有对话
   - 细粒度的操作权限控制

5. **A2A 协议兼容**
   - 标准化的消息格式
   - 支持多模态内容
   - 工具调用集成

### 10.2 技术亮点

- **MongoDB 文档数据库**: 灵活存储对话和消息,支持复杂查询
- **Redis 缓存**: 加速活跃会话访问,降低数据库压力
- **异步优先**: 全面采用 asyncio,高并发性能
- **流式友好**: WebSocket 和 SSE 双模式支持
- **上下文智能管理**: 自动摘要生成,优化长对话性能

### 10.3 未来扩展方向

1. **长期记忆集成**: 通过 MCP 工具支持向量数据库、知识图谱等
2. **对话分支**: 支持对话的分叉和合并
3. **协作对话**: 多用户共享对话
4. **对话模板**: 预置对话场景和提示词
5. **智能推荐**: 基于对话历史的 Agent 推荐
6. **对话分析**: 情感分析、主题提取、质量评估

### 10.4 开发建议

1. **分阶段迭代**: 按开发计划严格执行,确保每阶段可交付
2. **测试驱动**: TDD 方法,先写测试再实现
3. **性能优化**: 早期引入性能监控,及时发现瓶颈
4. **文档同步**: 代码和文档同步更新
5. **用户反馈**: 及时收集用户反馈,迭代优化体验

---

**文档版本**: v2.0
**最后更新**: 2025-12-03
**作者**: Alice Team
**状态**: 待评审
