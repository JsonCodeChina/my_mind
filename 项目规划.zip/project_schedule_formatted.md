# Alice Home 项目开发进度表（Excel 格式）

## 使用说明
1. 复制下面的表格内容到 Excel
2. 合并同一模块的单元格（A 列）
3. 为不同模块设置背景颜色：
   - 基础架构：深蓝色 (#4472C4)
   - 用户权限：淡蓝色 (#B4C7E7)
   - Agent 核心引擎：淡绿色 (#C6E0B4)
   - Model 管理：淡黄色 (#FFE699)
   - 对话管理：淡粉色 (#F8CBAD)
   - MCP 工具：淡紫色 (#D9D2E9)
   - RAG 知识库：淡橙色 (#FCE4D6)
   - 计费系统：淡灰色 (#D9D9D9)
   - 前端页面：淡青色 (#C9E3F6)
   - 测试：淡红色 (#F4B084)
   - 文档部署：淡绿色 (#A9D08E)
   - 预置数据：淡紫色 (#DDD9C4)
   - 发布：深绿色 (#70AD47)

---

## 项目总览

| **项目名称** | Alice Home |
|------------|-----------|
| **项目周期** | 2025-12-04 ~ 2026-02-04（8周/2个月） |
| **团队配置** | 后端开发 3 人 + 前端开发 1 人 + 测试 1 人（Week 5+）+ PM 1 人（兼职） |
| **开发策略** | 敏捷开发，4个 Sprint，每2周一个迭代 |

---

## 详细任务表（93个任务）

| 模块 | 任务名称 | 工期 | 负责人 | 开始日期 | 结束日期 | 说明 | 依赖 | 产品侧 |
|------|---------|------|--------|---------|---------|------|------|--------|
| **基础架构** | 项目脚手架搭建 | 2天 | Backend-1 | Week1-Mon | Week1-Tue | FastAPI + PostgreSQL + Redis + MongoDB | - | 环境配置 |
| **基础架构** | Docker Compose 开发环境 | 1天 | Backend-1 | Week1-Wed | Week1-Wed | 容器化开发环境 | T1.1.1 | 环境配置 |
| **基础架构** | 数据库 Schema 初始化 | 2天 | Backend-1 | Week1-Thu | Week1-Fri | PostgreSQL/MongoDB 表结构 | T1.1.2 | 数据库设计 |
| **基础架构** | CI/CD Pipeline 配置 | 1天 | Backend-1 | Week2-Mon | Week2-Mon | GitHub Actions 自动化 | T1.1.1 | DevOps |
| **用户权限** | users 表创建 | 1天 | Backend-3 | Week1-Mon | Week1-Mon | 用户表和认证表 | - | 权限设计 |
| **用户权限** | JWT 认证实现 | 3天 | Backend-3 | Week1-Tue | Week1-Thu | 登录/注册/Token API | T1.2.1 | 认证鉴权 |
| **用户权限** | RBAC 权限装饰器 | 2天 | Backend-3 | Week1-Fri | Week2-Mon | 基于角色的访问控制 | T1.2.2 | 权限管理 |
| **用户权限** | 用户 CRUD API | 2天 | Backend-3 | Week2-Tue | Week2-Wed | 管理员用户管理 | T1.2.3 | 用户管理 |
| **用户权限** | 密码重置和登录日志 | 1天 | Backend-3 | Week2-Thu | Week2-Thu | 密码重置和审计 | T1.2.3 | 安全审计 |
| **Agent 核心引擎** | agent_registry 表创建 | 1天 | Backend-1 | Week1-Mon | Week1-Mon | Agent 注册表 | - | Agent 架构 |
| **Agent 核心引擎** | Agent SDK 基础框架 | 3天 | Backend-1 | Week1-Tue | Week1-Thu | AgentExecutor 抽象类 | T1.3.1 | SDK 设计 |
| **Agent 核心引擎** | A2A 协议通信层 | 3天 | Backend-1 | Week1-Fri | Week2-Tue | Task/Message 格式 | T1.3.2 | 协议实现 |
| **Agent 核心引擎** | 元 Agent 注册分配 | 2天 | Backend-1 | Week2-Wed | Week2-Thu | 全局默认 Agent | T1.3.3 | 元 Agent |
| **Agent 核心引擎** | Agent 安装和版本管理 | 2天 | Backend-1 | Week3-Mon | Week3-Tue | .alicepkg 包格式 | T1.3.4 | 包管理 |
| **Agent 核心引擎** | Agent 市场注册发现 | 2天 | Backend-1 | Week3-Wed | Week3-Thu | Agent 市场 API | T2.3.1 | 市场机制 |
| **Agent 核心引擎** | 用户 Agent 安装记录 | 2天 | Backend-1 | Week3-Fri | Week4-Mon | 用户安装关系表 | T2.3.2 | 用户管理 |
| **Agent 核心引擎** | Agent 启用禁用权限 | 2天 | Backend-1 | Week4-Tue | Week4-Wed | 管理员启用控制 | T2.3.3 | 权限控制 |
| **Agent 核心引擎** | Agent 执行器实现 | 2天 | Backend-1 | Week4-Thu | Week4-Fri | 对接 LLM 对话 | T2.3.4 + T2.1.2 | 核心执行 |
| **Agent 核心引擎** | Agent 并发执行队列 | 2天 | Backend-1 | Week5-Mon | Week5-Tue | Celery 异步队列 | T2.3.5 | 性能优化 |
| **Agent 核心引擎** | 错误处理和重试机制 | 2天 | Backend-1 | Week5-Wed | Week5-Thu | 容错和重试 | T3.4.1 | 可靠性 |
| **Agent 核心引擎** | .alicepkg 包格式标准 | 2天 | Backend-1 | Week5-Fri | Week6-Mon | Agent Card 标准 | T2.3.2 | 标准化 |
| **Agent 核心引擎** | Agent 单元测试 | 2天 | Backend-1 | Week6-Tue | Week6-Wed | 测试用例编写 | T3.4.3 | 质量保证 |
| **Agent 核心引擎** | Redis 缓存优化 | 2天 | Backend-1 | Week6-Thu | Week6-Fri | 性能缓存 | T3.4.4 | 性能优化 |
| **Model 管理** | llm_providers 表创建 | 1天 | Backend-2 | Week3-Mon | Week3-Mon | LLM 供应商表 | - | Model 架构 |
| **Model 管理** | LiteLLM 统一调用封装 | 3天 | Backend-2 | Week3-Tue | Week3-Thu | 统一 LLM 接口 | T2.1.1 | LLM 集成 |
| **Model 管理** | 供应商配置 API | 2天 | Backend-2 | Week3-Fri | Week4-Mon | OpenAI/Anthropic 配置 | T2.1.2 | 供应商管理 |
| **Model 管理** | 模型列表启用禁用 | 2天 | Backend-2 | Week4-Tue | Week4-Wed | 模型管理 API | T2.1.3 | 模型管理 |
| **Model 管理** | Agent 模型绑定 | 1天 | Backend-2 | Week4-Thu | Week4-Thu | Agent-Model 绑定 | T2.1.4 | 绑定管理 |
| **Model 管理** | Token 使用量统计 | 1天 | Backend-2 | Week4-Fri | Week4-Fri | 基础使用量 | T2.1.2 | 成本统计 |
| **对话管理** | conversations 集合设计 | 1天 | Backend-3 | Week3-Mon | Week3-Mon | MongoDB 对话集合 | - | 对话架构 |
| **对话管理** | 对话 CRUD API | 2天 | Backend-3 | Week3-Tue | Week3-Wed | 创建/查询/删除 | T2.2.1 | 对话管理 |
| **对话管理** | 消息发送 API | 2天 | Backend-3 | Week3-Thu | Week3-Fri | 同步消息发送 | T2.2.2 + T1.3.3 | 消息通信 |
| **对话管理** | WebSocket 流式输出 | 3天 | Backend-3 | Week4-Mon | Week4-Wed | 实时流式对话 | T2.2.3 | 实时通信 |
| **对话管理** | 上下文窗口管理 | 1天 | Backend-3 | Week4-Thu | Week4-Thu | 最近 20 条管理 | T2.2.4 | 上下文 |
| **对话管理** | Agent 切换功能 | 1天 | Backend-3 | Week4-Fri | Week4-Fri | 用户切换 Agent | T2.2.5 | 切换机制 |
| **MCP 工具** | mcp_registry 表创建 | 1天 | Backend-2 | Week5-Mon | Week5-Mon | MCP 注册表 | - | MCP 架构 |
| **MCP 工具** | MCP 协议客户端 | 3天 | Backend-2 | Week5-Tue | Week5-Thu | stdio/SSE 通信 | T3.1.1 | 协议实现 |
| **MCP 工具** | MCP 工具注册发现 | 2天 | Backend-2 | Week5-Fri | Week6-Mon | MCP 市场 API | T3.1.2 | 市场机制 |
| **MCP 工具** | Agent MCP 绑定 | 2天 | Backend-2 | Week6-Tue | Week6-Wed | Agent 绑定 MCP | T3.1.3 | 绑定管理 |
| **MCP 工具** | MCP 调用集成 | 2天 | Backend-2 | Week6-Thu | Week6-Fri | Agent 集成 MCP | T3.1.4 + T2.3.5 | 执行集成 |
| **RAG 知识库** | knowledge_bases 表创建 | 1天 | Backend-2 | Week5-Mon | Week5-Mon | 知识库表 | - | RAG 架构 |
| **RAG 知识库** | Qdrant 向量库初始化 | 1天 | Backend-2 | Week5-Tue | Week5-Tue | 向量数据库 | T3.2.1 | 向量存储 |
| **RAG 知识库** | 文档上传解析 | 3天 | Backend-2 | Week5-Wed | Week5-Fri | PDF/Word/TXT | T3.2.2 | 文档处理 |
| **RAG 知识库** | 文档分块 Embedding | 2天 | Backend-2 | Week6-Mon | Week6-Tue | 智能分块向量化 | T3.2.3 | Embedding |
| **RAG 知识库** | 混合检索实现 | 2天 | Backend-2 | Week6-Wed | Week6-Thu | BM25 + Vector | T3.2.4 | 检索算法 |
| **RAG 知识库** | RAG 集成到 Agent | 1天 | Backend-2 | Week6-Fri | Week6-Fri | Agent 调用 RAG | T3.2.5 + T2.3.5 | RAG 集成 |
| **计费系统** | billing_plans 表创建 | 1天 | Backend-3 | Week5-Mon | Week5-Mon | 套餐账单表 | - | 计费架构 |
| **计费系统** | 使用量统计中间件 | 2天 | Backend-3 | Week5-Tue | Week5-Wed | Token 统计 | T3.3.1 + T2.1.6 | 使用量统计 |
| **计费系统** | 套餐管理 API | 2天 | Backend-3 | Week5-Thu | Week5-Fri | 创建/编辑套餐 | T3.3.2 | 套餐管理 |
| **计费系统** | 用户配额和限流 | 2天 | Backend-3 | Week6-Mon | Week6-Tue | 配额 Rate Limiting | T3.3.3 | 配额控制 |
| **计费系统** | 账单生成查询 | 2天 | Backend-3 | Week6-Wed | Week6-Thu | 月度账单 | T3.3.4 | 账单管理 |
| **计费系统** | 使用量报表统计 | 1天 | Backend-3 | Week6-Fri | Week6-Fri | 统计报表 | T3.3.5 | 报表统计 |
| **前端页面** | 前端项目脚手架 | 1天 | Frontend-1 | Week1-Mon | Week1-Mon | React/Vue + Vite | - | 前端架构 |
| **前端页面** | 登录注册页面 | 3天 | Frontend-1 | Week1-Tue | Week1-Thu | 认证页面 | T1.4.1 + T1.2.2 | 认证页面 |
| **前端页面** | JWT Token 管理 | 2天 | Frontend-1 | Week1-Fri | Week2-Mon | Token 拦截器 | T1.4.2 | Token 管理 |
| **前端页面** | 基础布局和路由 | 2天 | Frontend-1 | Week2-Tue | Week2-Wed | Admin/User 路由 | T1.4.3 | 页面布局 |
| **前端页面** | 用户管理页面 | 2天 | Frontend-1 | Week2-Thu | Week2-Fri | 管理员用户管理 | T1.4.4 + T1.2.4 | 管理页面 |
| **前端页面** | Model 管理页面 | 3天 | Frontend-1 | Week3-Mon | Week3-Wed | 供应商模型配置 | T2.1.3 + T2.1.4 | Model 管理 |
| **前端页面** | 对话界面基础版 | 3天 | Frontend-1 | Week3-Thu | Week4-Mon | 基础对话界面 | T2.2.3 | 对话界面 |
| **前端页面** | WebSocket 流式渲染 | 2天 | Frontend-1 | Week4-Tue | Week4-Wed | 流式输出 | T2.4.2 + T2.2.4 | 流式渲染 |
| **前端页面** | Agent 市场页面 | 2天 | Frontend-1 | Week4-Thu | Week4-Fri | 双角色市场 | T2.3.2 + T2.3.4 | 市场页面 |
| **前端页面** | MCP 工具市场页面 | 2天 | Frontend-1 | Week5-Mon | Week5-Tue | MCP 市场 | T3.1.3 + T3.1.4 | 市场页面 |
| **前端页面** | RAG 知识库管理 | 3天 | Frontend-1 | Week5-Wed | Week5-Fri | 知识库上传 | T3.2.3 + T3.2.5 | 知识库页面 |
| **前端页面** | 计费使用量统计 | 2天 | Frontend-1 | Week6-Mon | Week6-Tue | 使用量账单 | T3.3.3 + T3.3.6 | 计费页面 |
| **前端页面** | 对话历史搜索 | 2天 | Frontend-1 | Week6-Wed | Week6-Thu | 历史查询 | T2.2.2 | 历史记录 |
| **前端页面** | 个人设置页面 | 1天 | Frontend-1 | Week6-Fri | Week6-Fri | 用户设置 | - | 设置页面 |
| **前端页面** | UI/UX 优化 | 2天 | Frontend-1 | Week7-Mon | Week7-Tue | 响应式优化 | Sprint 3 | UI 优化 |
| **前端页面** | 错误处理完善 | 2天 | Frontend-1 | Week7-Wed | Week7-Thu | 错误提示 | T4.2.1 | 错误处理 |
| **前端页面** | 国际化支持 | 2天 | Frontend-1 | Week7-Fri | Week8-Mon | 中英文 i18n | T4.2.2 | 国际化 |
| **前端页面** | 前端单元测试 | 2天 | Frontend-1 | Week8-Tue | Week8-Wed | Jest/Vitest | T4.2.3 | 测试 |
| **测试** | API 测试用例编写 | 3天 | QA-1 | Week5-Mon | Week5-Wed | 核心 API 测试 | Sprint 2 | 测试用例 |
| **测试** | pytest 自动化脚本 | 3天 | QA-1 | Week5-Thu | Week6-Mon | 自动化测试 | T3.6.1 | 自动化测试 |
| **测试** | 集成测试环境搭建 | 2天 | QA-1 | Week6-Tue | Week6-Wed | 集成测试 | T3.6.2 | 集成测试 |
| **测试** | Bug 跟踪回归测试 | 2天 | QA-1 | Week6-Thu | Week6-Fri | Bug 管理 | T3.6.3 | 质量保证 |
| **测试** | 端到端测试 | 2天 | QA-1 | Week7-Mon | Week7-Tue | E2E 测试 | Sprint 3 | E2E 测试 |
| **测试** | 性能压力测试 | 2天 | QA-1 | Week7-Wed | Week7-Thu | Locust 测试 | T4.1.1 | 性能测试 |
| **测试** | 安全测试 | 2天 | QA-1 | Week7-Fri | Week8-Mon | OWASP Top 10 | T4.1.2 | 安全测试 |
| **测试** | 冒烟测试 | 1天 | QA-1 | Week8-Fri | Week8-Fri | 生产验证 | T4.5.2 | 验收测试 |
| **文档部署** | API 文档完善 | 2天 | Backend-1 | Week7-Mon | Week7-Tue | Swagger/OpenAPI | Sprint 3 | API 文档 |
| **文档部署** | 部署文档编写 | 2天 | Backend-1 | Week7-Wed | Week7-Thu | Docker/K8s | T4.3.1 | 部署文档 |
| **文档部署** | 用户管理员手册 | 3天 | PM-1 | Week7-Mon | Week7-Wed | 使用手册 | Sprint 3 | 用户手册 |
| **文档部署** | 开发者文档 | 2天 | Backend-1 | Week7-Fri | Week8-Mon | SDK/MCP 开发 | T4.3.2 | 开发文档 |
| **文档部署** | K8s 生产环境配置 | 2天 | Backend-1 | Week8-Tue | Week8-Wed | 生产部署 | T4.3.2 | 生产部署 |
| **文档部署** | 监控日志配置 | 1天 | Backend-1 | Week8-Thu | Week8-Thu | Prometheus/ELK | T4.3.5 | 监控运维 |
| **预置数据** | 管理员账号初始化 | 1天 | Backend-2 | Week7-Mon | Week7-Mon | admin 账号 | Sprint 1 | 初始化 |
| **预置数据** | 元 Agent 预置 | 2天 | Backend-2 | Week7-Tue | Week7-Wed | Alice Chat | T4.4.1 + T2.3.5 | 元 Agent |
| **预置数据** | MCP 工具示例 | 2天 | Backend-2 | Week7-Thu | Week7-Fri | 2-3 个示例 | T3.1.5 | 示例数据 |
| **预置数据** | 示例知识库 | 1天 | Backend-2 | Week8-Mon | Week8-Mon | 演示知识库 | T3.2.6 | 示例数据 |
| **发布** | 内部验收测试 | 2天 | PM-1 | Week8-Tue | Week8-Wed | 全员验收 | 所有任务 | 验收 |
| **发布** | 版本打包 Release | 1天 | Backend-1 | Week8-Thu | Week8-Thu | v1.0 发布 | T4.5.1 | 发布 |
| **发布** | 生产部署上线 | 1天 | Backend-1 | Week8-Fri | Week8-Fri | 部署上线 | T4.5.2 | 上线 |

---

## 人员工作量统计

| 角色 | 任务数 | 总工期(人天) | 平均负载 | 备注 |
|------|-------|-------------|---------|------|
| Backend-1 | 18 | 38天 | 95% | 高负载，Agent 核心 + 架构 |
| Backend-2 | 23 | 39天 | 98% | 高负载，MCP + RAG + Model |
| Backend-3 | 19 | 35天 | 88% | 适中，用户 + 对话 + 计费 |
| Frontend-1 | 21 | 39天 | 98% | 高负载，全部前端页面 |
| QA-1 | 10 | 20天 | 100% | Week 5+ 全职测试 |
| PM-1 | 2 | 3天 | 兼职 | 需求和文档 |

**总人天**: 174 人天
**项目周期**: 8 周（2个月）

---

## 4个 Sprint 里程碑

| Sprint | 周期 | 目标 | 主要交付物 |
|--------|------|------|-----------|
| **Sprint 1** | Week 1-2 | 基础设施搭建 | 用户认证、Agent SDK、前端基础 |
| **Sprint 2** | Week 3-4 | 核心功能开发 | 对话功能、Model 管理、Agent 市场 |
| **Sprint 3** | Week 5-6 | 扩展功能开发 | MCP 工具、RAG、计费、测试 |
| **Sprint 4** | Week 7-8 | 集成测试和发布 | 文档、部署、验收、v1.0 发布 |

---

## 关键风险

| 风险 | 影响 | 概率 | 应对措施 |
|-----|------|-----|---------|
| LLM API 不稳定 | 高 | 中 | 重试机制、多供应商备份 |
| Agent 性能不足 | 中 | 中 | Celery 队列、Redis 缓存 |
| RAG 召回率低 | 中 | 低 | 优化分块、调整模型 |
| 前端进度延迟 | 高 | 中 | Mock API、优先 P0 |
| 测试覆盖不足 | 中 | 低 | QA 提前介入、CI/CD |

---

**文档版本**: v1.0
**创建日期**: 2025-12-04
**审核**: PM-1
**状态**: ✅ 已通过
